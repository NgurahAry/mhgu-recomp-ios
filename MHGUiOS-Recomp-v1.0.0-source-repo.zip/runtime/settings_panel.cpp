#include "settings_panel.h"
#include "config.h"
#include "menu_confirm.h"
#include "settings_locale.h"
#include "settings_icons.h"
#include "app_actions.h"
#include "chat/chat.h"
#include "chat/chat_crypto.h"
#include "chat/chat_text.h"
#include "chat_port.h"
#include "cache_clear.h"
#include "cheats.h"
#include "forge.h"
#include "overlay.h"
#include "padmap.h"
#include "keymap.h"
#include "modorder.h"
#include "net/net.h"
#include "platform.h"
#include "textinput.h"
#include "touch.h"
#include "verify.h"
#include "imgui_internal.h"
#ifndef MHGU_VERSION
#define MHGU_VERSION ""  // (the build gives it: native/CMakeLists.txt)
#endif
#include <SDL3/SDL.h>
#include <algorithm>
#include <array>
#include <atomic>
#include <cmath>
#include <cstdarg>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <functional>
#include <memory>
#include <mutex>
#include <string>
#include <strings.h>
#include <thread>
#include <vector>

#ifndef __ANDROID__
// (nvn/vulkan/device.c) the Vulkan devices that can run the game and the one in use, for the GPU row
extern "C" int vk_gpu_list(const char **names, int max, int *in_use);
#endif
extern "C" bool host_input_real_pad(void);  // (runtime/host_input.c)
extern "C" bool host_input_keyboard_mouse(void);  // (runtime/host_input.c: a phone's keyboard and mouse, S14)

namespace {
// (Page: a page one level down from a section's, State::at; MENU.md)
enum class View { Main, Page, Keyboard, CloseChanges, Exit, Restart, Reset, Move, Conflicts, KeyCapture, Keybinds, TouchButtons,
                  ComboEdit, PadList, PadMap, ImportSave, Licenses, Remove, OpenSite, OpenDiscord, Profiles, ProfileSlot,
                  Chat, Friends, ChatOn,  // (the chat's pages and its question: settings_chat.inc)
                  Verify };  // (Verify game files: runtime/verify.c)
enum class Command { None, Save };
struct Row {
    std::string id, title, value;
    std::string key, help;  // its ini key (config.c g_settings; its help: config_help), or a help text of its own
    bool enabled = true, cold = false, action = false, warn = false;
    bool header = false, current = false;  // a section title (not a row to select); the choice a dropdown has now
    bool note = false;                     // (a header) a line of text between the rows: the MH4U port's notes
    float progress = -1;                   // (a note) a bar under its text, 0 to 1 (Verify game files' progress)
    bool bright = false;                   // (a note) in the text's colour, not the dimmer one (a check that passed)
    std::string who;                       // (a note) a chat line's sender, over its text; who_mine: this player's
    bool who_mine = false;
    bool menu = false;                     // Confirm opens a dropdown of its choices
    int toggle = -1;                       // On / Off (1 / 0; -1: not a switch): the phone draws a switch
    bool number = false;                   // a number: left / right step it (the phone: - and + buttons on the row)
    std::function<void(int)> adjust;
    std::function<void()> activate;
    std::function<void()> remove;          // (a picker's remembered choice: the x at its right takes it out of the list)
};
struct Target {
    std::string id;
    ImVec2 center;
    bool enabled;
};
struct Origin {
    View view;
    std::string focus;
    float scroll;
    std::string at;  // (View::Page: which)
};
// A row's choices, listed in a window of their own under it (or above it, near the bottom) while it is open: the
// controller moves in the list, Confirm picks, Back or a click elsewhere closes it
struct Dropdown {
    bool open = false, hovered = false, anchored = false;
    std::string row;  // the row it belongs to
    std::vector<std::string> names;
    int selected = 0;
    std::function<void(int)> set;
    ImRect anchor;  // that row on the screen, this frame (draw_rows)
    std::string title;  // (the phone's picker: its row's title over the choices)
    std::vector<char> removable;      // the choices remembered (the servers and keys typed): an x at the right of each
    std::function<void(int)> remove;  // takes one of them out of its list
    std::string help;                 // (the phone's picker: its row's help, shown over the choices by its "?")
    bool show_help = false;
};
struct Keyboard {
    std::string title, original, buffer;
    size_t cursor = 0, capacity = 255;
    bool upper = false, select_all = false;
    std::function<bool(const std::string &, std::string &)> commit;
    bool phone = false;  // (Android) its Phone keyboard key asked for the phone's own keyboard: up while this view is,
                         // until Back puts it away (the view and its text stay; the key brings it back). Up as the
                         // view opens on a phone played by touch (no controller): the phone's keyboard first
    bool game = false;   // the game's text entry's (SETTINGS_VIEW_GAME_TEXT): leaving the view closes the menu
};
bool g_close_now;  // (the game's text entry's view left: the menu closes at its next frame)
// The phone's sizes (touch_panel, each frame), from the screen's height in its pixels: a row, a tab and a button about
// 0.09 of it, the text 0.034
struct Metrics {
    float H = 720, f = 16, row = 40, pad = 8, line = 2;
};
// A finger dragging a list (a child window: the rows, the picker's choices) and the glide after it lets go
struct Drag {
    ImGuiID window = 0;
    float from = 0, scroll = 0, last = 0, velocity = 0;  // (the finger's height and the scroll as the drag began; px / s)
    bool pressed = false, moving = false;                // (moving: past the threshold, no longer a tap)
};
struct State {
    Config draft = {}, saved = {};
    float chat_panel_size_draft = 1.f, chat_panel_size_saved = 1.f;
    bool editing = false, floating = false, advanced = false, focus_request = true, saved_notice = false;
    int page = 0;           // the section (CONTROLS_PAGE...)
    View view = View::Main;
    std::string at;         // View::Page: the page one level down shown ("graphics/screen")
    std::string help_open;  // the row whose help is open under it (its "?": the phone's layout)
    bool help_scroll = false;  // (it just opened: the list scrolls to show it)
    std::string reset_at;   // the page View::Reset puts back (a section's own: all of its pages)
    Command command = Command::None;
    std::string focus, error;
    std::string help_row, hovered;  // the row whose help shows (the one focused or pointed at last); the one pointed at
    bool pointing = false;          // the mouse pointer is on one of the view's rows (hovered: also the focused one)
    float help_height = 0;          // room for the longest help of the tab (last frame's)
    std::vector<Target> targets;
    std::vector<Origin> origins;
    Dropdown dropdown;
    Keyboard keyboard;
    uint64_t quest_keys[HP_QUESTS_MAX] = {}, next_quest_key = 1;
    bool restore_scroll = false;
    float scroll = 0, guide_height = 0;
    int focus_scroll_frames = 0;
    ImVec2 move_start = {}, move_position = {};
    // The mouse: dragging the top of the menu moves it, the grip at its bottom right corner sizes it (custom_size,
    // 0: as tall as its rows, as wide as it is by default); either one detaches it
    ImVec2 custom_size = {}, drag_mouse = {}, drag_from = {};
    int dragging = 0;  // 1 moving, 2 sizing
    bool dragged = false;  // (the press moved the menu: the tab under it is not chosen when it lets go)
    float header_bottom = 0;  // (the top part that moves the menu, from the window's top: last frame's)
    bool position_override = false;
    int capture_bind = -1;     // the keybind (BIND_*) a key is being chosen for; -1: the chat key
    bool capture_add = false;  // the key chosen is that keybind's second, else its only one
    // A desktop's: the window's close button opened the menu for Exit game alone (leaving that dialog closes the menu);
    // what the player used last, read once a frame (overlay_last_input: the hints, the rows lit under the mouse); when
    // the menu, the view and the dropdown opened (their animation: anim_in)
    bool exit_only = false;
    int input = USED_KEYS;
    double opened_at = -1, view_at = -1, dropdown_at = -1;
    bool dropdown_drawn = false;  // (the dropdown's window was drawn last frame: closed since, it fades out)
    bool dropdown_up = false;     // (it opened above its row)
    // The phone's layout (touch_ui)
    bool touch = false;    // (not Android: the last press on the menu was a finger's - overlay.cpp marks them)
    bool touch_next = false;
    bool swallow = false;  // the press under way does nothing when it lets go (it closed the picker, began a drag)
    ImGuiID list = 0;      // the list of rows (a child window) this frame; 0: the menu itself scrolls (keyboard / mouse)
    Metrics m;
    Drag drag;
    // A remembered choice taken out of a picker (its x): the picker of that row opened again, fresh, at that place
    std::string reopen;
    int reopen_at = 0;
} s;
std::atomic<bool> request_exit, request_back, is_dirty, is_confirming, is_capturing, capture_mouse, capture_wheel;
std::atomic<int> request_view;  // (SETTINGS_VIEW_*: a desktop's dialog answered, settings_panel_request_view)
// (the key pressed while a key is being chosen, or KEY_MOUSE + a mouse button; -1: none yet)
std::atomic<int> captured_key{-1};
// (the draft's language while the menu edits it; before the menu first opens - the credits at the start - the saved one:
// the draft is still empty then, and the credits came out in English on a Spanish system)
const char *tr(const char *text) { return settings_text(s.editing ? s.draft.language : config_language(), text); }
// (a row's own words in English and Spanish, kept beside the row: the 1.0 options' texts live with their rows, so each one
// moves as a whole when the menu is arranged again)
const char *en_es(const char *en, const char *es) { return (s.editing ? s.draft.language : config_language()) == 1 ? es : en; }
std::string fmt(const char *text, ...) {
    char buffer[512];
    va_list args;
    va_start(args, text);
    vsnprintf(buffer, sizeof buffer, tr(text), args);
    va_end(args);
    return buffer;
}
// The phone's layout (touch_panel): rows, tabs and buttons a finger hits, a header with Back / Save / Close, lists that
// a finger drags, a picker for a row's choices, - and + on a number's. On Android always (no hover, wheel or keyboard
// there; a controller still works it as before); elsewhere while fingers work the menu (a mouse click puts it back)
bool touch_ui() {
#ifdef __ANDROID__
    return true;
#else
    return s.touch;
#endif
}
// A touch screen for the touch controls: a phone's, or one SDL lists on a PC (most have none: the menu leaves out the
// rows that only act on one)
bool touch_screen() {
#ifdef __ANDROID__
    return true;
#else
    int n = 0;
    SDL_free(SDL_GetTouchDevices(&n));
    return n > 0;
#endif
}
// The touch controls' rows: with a touch screen, or with the controls shown anyway ([Touch] Controls On, as saved:
// their rows stay, to turn them off)
bool touch_rows() { return touch_screen() || s.saved.touch_controls == TOUCH_ON; }
// The touch settings of the TB_ list with a row of their own elsewhere (MENU.md: the floating stick on Touch controls, the
// Hunter Arts' taps with a controller on Controller), not in Buttons on the screen nor in its count
bool tb_elsewhere(int i) { return i == TB_FLOAT_STICK || i == TB_ARTS_PAD; }
struct Row;
void control_profile_row(std::vector<Row> &r);  // (the Controls page's link to the control profiles: further down)
void button_images_row(std::vector<Row> &r);    // (...and to the buttons' pictures)
// View::TouchButtons opened from the controller's rows: its combined buttons alone (a phone with a controller connected;
// the MH4U port's the same)
bool s_combos_alone = false;
// The menu's colours ([Application] Theme, applied as it is picked): Blue, the original look; Gold, a warm panel
// where rows light up with a gold bar at their left instead of a frame, and tabs that are only their names,
// underlined; and Hunter, after the game's own windows (the item pouch) - a maroon panel with a red and green rule at
// its top and bottom, gold corners, rows split by lines and the focused one filled gold (the one under the mouse a
// lighter gold).
struct Theme {
    ImU32 panel, edge, row, row_hover, row_focus, tab, tab_active, accent, accent_bright, text, text_dim, text_off,
        warn, divider, popup;
    bool bar;         // the focused row: lit with a bar at its left (else framed)
    float rounding;   // of the window, the rows and the tabs
    bool game;        // Hunter: the game's window frame (draw_frame), lines between the rows, a filled header
    ImU32 header;     // (game: the header band's colour)
};
const Theme &theme() {
    static const Theme blue = {IM_COL32(6, 10, 17, 250),     IM_COL32(110, 217, 255, 255), IM_COL32(23, 33, 48, 255),
                               IM_COL32(38, 71, 99, 255),    IM_COL32(41, 82, 117, 255),   IM_COL32(15, 23, 36, 255),
                               IM_COL32(46, 102, 143, 255),  IM_COL32(111, 216, 255, 255), IM_COL32(111, 216, 255, 255),
                               IM_COL32(244, 247, 252, 255), IM_COL32(178, 192, 208, 255), IM_COL32(132, 145, 160, 255),
                               IM_COL32(255, 184, 145, 255), IM_COL32(52, 72, 94, 255),    IM_COL32(13, 20, 31, 255),
                               false,                        3.f};
    static const Theme gold = {IM_COL32(34, 25, 19, 248),    IM_COL32(139, 97, 40, 255),   IM_COL32(251, 236, 206, 10),
                               IM_COL32(229, 195, 126, 28),  IM_COL32(213, 162, 79, 64),   IM_COL32(0, 0, 0, 0),
                               IM_COL32(0, 0, 0, 0),         IM_COL32(213, 162, 79, 255),  IM_COL32(247, 226, 162, 255),
                               IM_COL32(242, 216, 170, 255), IM_COL32(175, 150, 128, 255), IM_COL32(124, 107, 90, 255),
                               IM_COL32(210, 106, 80, 255),  IM_COL32(139, 97, 40, 90),    IM_COL32(42, 31, 23, 252),
                               true,                         6.f};
    static const Theme hunter = {IM_COL32(50, 25, 24, 236),    IM_COL32(0, 0, 0, 255),       IM_COL32(0, 0, 0, 0),
                                 IM_COL32(176, 145, 24, 105),  IM_COL32(176, 145, 24, 235),  IM_COL32(0, 0, 0, 0),
                                 IM_COL32(0, 0, 0, 0),         IM_COL32(236, 212, 44, 255),  IM_COL32(255, 232, 84, 255),
                                 IM_COL32(242, 238, 232, 255), IM_COL32(196, 176, 166, 255), IM_COL32(132, 112, 106, 255),
                                 IM_COL32(255, 96, 72, 255),   IM_COL32(96, 88, 88, 255),    IM_COL32(56, 28, 27, 250),
                                 false,                        0.f,                          true,
                                 IM_COL32(108, 46, 46, 255)};
    return s.draft.menu_theme == THEME_BLUE ? blue : s.draft.menu_theme == THEME_HUNTER ? hunter : gold;
}
ImVec4 vec(ImU32 c) { return ImGui::ColorConvertU32ToFloat4(c); }
bool pressed(ImGuiKey key, bool repeat);
std::string help_text(const Row &r);  // (a row's help: further down)
// A text's paragraphs joined into one line each, for the page to wrap at its own width: files broken at a fixed width (the
// legal notice, the project's license, the GNU licenses) came out with every other line cut short. Joined: a paragraph
// broken at a width (a line before its last one 60 characters or more) whose lines all start at the same indent, kept
// once; and a list whose items start at one indent with "- ", "* ", "1." or "a)" and go on further in, each item with its
// own lines. Anything else stays as it is: centred headings, addresses and signatures (short lines), columns (runs of
// spaces inside a line).
std::string reflow_prose(const std::string &in) {
    std::string out;
    std::vector<std::string> para;
    auto indent_of = [](const std::string &l) { return l.find_first_not_of(" \t"); };
    auto item_start = [](const std::string &l, size_t at) {
        if (at + 1 < l.size() && (l[at] == '-' || l[at] == '*') && l[at + 1] == ' ') return true;
        size_t k = at;
        while (k < l.size() && k - at < 3 && isalnum((unsigned char)l[k])) k++;
        return k > at && k + 1 < l.size() && (l[k] == '.' || l[k] == ')') && l[k + 1] == ' ';
    };
    auto columns = [](const std::string &l, size_t at) { return l.find("   ", at) != std::string::npos; };
    auto join = [](std::string &acc, const std::string &l, size_t from) {
        std::string t = l.substr(from);
        while (!t.empty() && t.back() == ' ') t.pop_back();
        if (!acc.empty() && acc.back() != ' ') acc += ' ';
        acc += t;
    };
    auto flush = [&]() {
        if (para.empty()) return;
        const size_t i0 = indent_of(para[0]), i1 = para.size() > 1 ? indent_of(para[1]) : i0;
        bool same = true, first_in = i1 < i0, wrapped = false, cols = false;
        for (size_t k = 0; k < para.size(); k++) {
            same &= indent_of(para[k]) == i0;
            if (k) first_in &= indent_of(para[k]) == i1;  // (only the first line further in: the GNU texts' paragraphs)
            wrapped |= k + 1 < para.size() && para[k].size() >= 60;
            cols |= columns(para[k], indent_of(para[k]));
        }
        std::vector<std::string> lines;
        if (para.size() > 1 && wrapped && !cols && (same || first_in)) {  // (prose, at the left edge or indented alike)
            lines.push_back(para[0].substr(0, i0));
            for (const auto &l : para) join(lines.back(), l, indent_of(l));
        } else if (para.size() > 1 && !cols && item_start(para[0], i0)) {  // (a list: items at i0, their lines further in)
            for (const auto &l : para) {
                const size_t at = indent_of(l);
                if (at == i0 && item_start(l, at)) lines.push_back(l.substr(0, at)), join(lines.back(), l, at);
                else if (at > i0) join(lines.back(), l, at);
                else { lines = para; break; }
            }
        } else {
            lines = para;
        }
        for (const auto &l : lines) out += l + '\n';
        para.clear();
    };
    size_t i = 0;
    while (i <= in.size()) {
        size_t e = in.find('\n', i);
        if (e == std::string::npos) e = in.size();
        std::string line = in.substr(i, e - i);
        while (!line.empty() && (line.back() == '\r' || line.back() == ' ' || line.back() == '\t')) line.pop_back();
        if (line.empty()) {
            flush();
            if (e < in.size()) out += '\n';
        } else {
            if (line.size() > 64 && line.find_first_not_of('-') == std::string::npos)
                line.resize(64);  // (a rule between the notice's languages: one line on the page, not one and a bit)
            para.push_back(line);
        }
        if (e >= in.size()) break;
        i = e + 1;
    }
    flush();
    return out;
}
// The licenses' page (a desktop; Android: LicensesActivity): every text of the licenses folder beside the executable,
// one after the other, read once. The window scrolls with the wheel; arrows, page keys and the controller scroll it too.
// reserve: room left under it (the menu's guides)
void licenses_text(const Theme &look, float reserve = 0) {
    static std::vector<std::pair<std::string, std::string>> texts;  // (file, text)
    static bool loaded;
    if (!loaded) {
        loaded = true;
        char exe[1100] = "";
        if (plat_exe_path(exe, sizeof exe - 16)) {
            char *b = strrchr(exe, '\\'), *b2 = strrchr(exe, '/');
            if (b2 > b) b = b2;
            if (b) strcpy(b + 1, "licenses");
        }
        char dir[1200];
        if (!plat_path_to_utf8(exe, dir, sizeof dir)) snprintf(dir, sizeof dir, "%s", exe);
        int n = 0;
        char **names = SDL_GlobDirectory(dir, "*.txt", SDL_GLOB_CASEINSENSITIVE, &n);
        std::vector<std::string> sorted(names ? names : nullptr, names ? names + n : nullptr);
        SDL_free(names);
        // (the legal notice first, the project's license after it, then the rest by name)
        auto rank = [](const std::string &n) { return !SDL_strcasecmp(n.c_str(), "LEGAL.txt") ? 0 : !SDL_strcasecmp(n.c_str(), "LICENSE.txt") ? 1 : 2; };
        std::sort(sorted.begin(), sorted.end(), [&](const std::string &a, const std::string &b) {
            return rank(a) != rank(b) ? rank(a) < rank(b) : a < b;
        });
        for (const std::string &name : sorted) {
            size_t len = 0;
            char *text = (char *)SDL_LoadFile((std::string(dir) + "/" + name).c_str(), &len);
            if (text) texts.push_back({name.substr(0, name.size() - 4), reflow_prose(std::string(text, len))}), SDL_free(text);
        }
        if (texts.empty()) texts.push_back({"", tr("The licenses are in the licenses folder beside MHGU.exe.")});
    }
    // (a box of its own: the menu keeps its Close row in sight, the box scrolls on its own)
    float line = ImGui::GetTextLineHeightWithSpacing();
    ImGui::PushStyleColor(ImGuiCol_ChildBg, IM_COL32(0, 0, 0, 0));  // (the menu's own colour behind the text)
    ImGui::BeginChild("##licenses", ImVec2(0, std::max(ImGui::GetContentRegionAvail().y - reserve, line * 20)));
    ImGui::PopStyleColor();
    if (pressed(ImGuiKey_DownArrow, true) || pressed(ImGuiKey_GamepadDpadDown, true) || pressed(ImGuiKey_GamepadLStickDown, true))
        ImGui::SetScrollY(ImGui::GetScrollY() + line * 3);
    if (pressed(ImGuiKey_UpArrow, true) || pressed(ImGuiKey_GamepadDpadUp, true) || pressed(ImGuiKey_GamepadLStickUp, true))
        ImGui::SetScrollY(ImGui::GetScrollY() - line * 3);
    if (pressed(ImGuiKey_PageDown, true) || pressed(ImGuiKey_GamepadR1, true))
        ImGui::SetScrollY(ImGui::GetScrollY() + ImGui::GetWindowHeight() * .8f);
    if (pressed(ImGuiKey_PageUp, true) || pressed(ImGuiKey_GamepadL1, true))
        ImGui::SetScrollY(ImGui::GetScrollY() - ImGui::GetWindowHeight() * .8f);
    for (const auto &t : texts) {
        ImGui::Spacing();
        if (!t.first.empty()) {
            ImGui::PushStyleColor(ImGuiCol_Text, vec(look.accent));
            ImGui::TextUnformatted(t.first.c_str());
            ImGui::PopStyleColor();
        }
        ImGui::PushStyleColor(ImGuiCol_Text, vec(look.text_dim));
        ImGui::TextWrapped("%s", t.second.c_str());
        ImGui::PopStyleColor();
    }
    ImGui::EndChild();
}
ImU32 fade(ImU32 c, float a) {
    return (c & 0x00ffffffu) | ((ImU32)std::clamp(((c >> 24) & 0xff) * a, 0.f, 255.f) << 24);
}
// The phone's colours beside the theme's: Hunter's are the touch controls' (touch.cpp) - dark plates with a bronze edge
// and a gold rule, the picked row and tab lit ochre to gold as the game's cursor
struct Look {
    ImU32 plate, edge, rule, lit, ink, dim, glow, bar0, bar1, band;
};
Look touch_look() {
    const Theme &t = theme();
    if (t.game)
        return {IM_COL32(28, 20, 15, 235),   IM_COL32(112, 76, 34, 255),  IM_COL32(222, 186, 96, 255),
                IM_COL32(92, 62, 22, 255),   IM_COL32(244, 232, 200, 255), IM_COL32(204, 186, 160, 255),
                IM_COL32(255, 214, 92, 255), IM_COL32(206, 158, 42, 240),  IM_COL32(122, 82, 22, 225),
                IM_COL32(74, 34, 31, 255)};
    return {t.popup, t.divider | IM_COL32_A_MASK, t.accent, fade(t.accent, .35f), t.text, t.text_dim, t.accent_bright,
            fade(t.accent, .55f), fade(t.accent, .25f), t.popup};
}
void diamond(ImDrawList *dl, ImVec2 c, float d, ImU32 col) {
    ImVec2 q[4] = {ImVec2(c.x, c.y - d), ImVec2(c.x + d, c.y), ImVec2(c.x, c.y + d), ImVec2(c.x - d, c.y)};
    dl->AddConvexPolyFilled(q, 4, col);
}
// Text with a dark shadow under it (readable on the gold of the picked row, as the game's), in a font of its own
void shadow_text(ImDrawList *dl, ImFont *font, float size, ImVec2 p, ImU32 col, const char *text, float wrap = 0) {
    float o = std::max(1.f, size * .06f);
    dl->AddText(font, size, ImVec2(p.x + o, p.y + o), fade(IM_COL32(0, 0, 0, 170), ((col >> 24) & 0xff) / 255.f), text,
                nullptr, wrap);
    dl->AddText(font, size, p, col, text, nullptr, wrap);
}
void shadow_text(ImDrawList *dl, float size, ImVec2 p, ImU32 col, const char *text, float wrap = 0) {
    shadow_text(dl, ImGui::GetFont(), size, p, col, text, wrap);
}
// The titles' font: a serif, as the game's own titles and the MH4U port's (overlay.cpp loads the phone's Noto Serif as
// the second font), else the main one: the menu's title, its sections, the picked row's help, a list's title, the
// credits' and the thank-you's
ImFont *title_font() {
    ImGuiIO &io = ImGui::GetIO();
    return io.Fonts->Fonts.Size > 1 ? io.Fonts->Fonts[1] : ImGui::GetFont();
}
// A finger's button: a dark square plate with an edge and a rule inside (the touch controls' discs, made square), gold
// studs on its corners (Hunter); lit while held, faded while it does nothing
void plate(ImDrawList *dl, const ImRect &r, float line, bool held, bool enabled) {
    const Look k = touch_look();
    float a = enabled ? 1.f : .45f, in = line * 1.8f;
    dl->AddRectFilled(ImVec2(r.Min.x, r.Min.y + line), ImVec2(r.Max.x, r.Max.y + line), fade(IM_COL32(0, 0, 0, 110), a));
    dl->AddRectFilled(r.Min, r.Max, fade(held ? k.lit : k.plate, a));
    dl->AddRect(r.Min, r.Max, fade(k.edge, a), 0, 0, line);
    dl->AddRect(ImVec2(r.Min.x + in, r.Min.y + in), ImVec2(r.Max.x - in, r.Max.y - in), fade(k.rule, a * .7f), 0, 0,
                std::max(1.f, line * .45f));
    if (theme().game)
        for (ImVec2 c : {r.Min, ImVec2(r.Max.x, r.Min.y), ImVec2(r.Min.x, r.Max.y), r.Max})
            diamond(dl, c, line * 1.5f, fade(k.rule, a));
    if (held)
        dl->AddRect(ImVec2(r.Min.x - line, r.Min.y - line), ImVec2(r.Max.x + line, r.Max.y + line), fade(k.glow, .7f), 0,
                    0, line);
}
// The glyphs on the phone's buttons: an arrow (dir -1: back), a cross (close), - and +
void chevron(ImDrawList *dl, ImVec2 c, float r, int dir, ImU32 col, float thick) {
    dl->PathLineTo(ImVec2(c.x - dir * r * .5f, c.y - r));
    dl->PathLineTo(ImVec2(c.x + dir * r * .5f, c.y));
    dl->PathLineTo(ImVec2(c.x - dir * r * .5f, c.y + r));
    dl->PathStroke(col, 0, thick);
}
void cross(ImDrawList *dl, ImVec2 c, float r, ImU32 col, float thick) {
    dl->AddLine(ImVec2(c.x - r, c.y - r), ImVec2(c.x + r, c.y + r), col, thick);
    dl->AddLine(ImVec2(c.x - r, c.y + r), ImVec2(c.x + r, c.y - r), col, thick);
}
void sign(ImDrawList *dl, ImVec2 c, float r, bool plus, ImU32 col, float thick) {
    dl->AddRectFilled(ImVec2(c.x - r, c.y - thick * .5f), ImVec2(c.x + r, c.y + thick * .5f), col);
    if (plus)
        dl->AddRectFilled(ImVec2(c.x - thick * .5f, c.y - r), ImVec2(c.x + thick * .5f, c.y + r), col);
}
// The header's button to the project's page: GitHub's mark, a disc with the cat cut out of it, drawn here in the
// glyphs' colour (no artwork, no brand colours; the same in the MH4U port). r: the disc's radius
void github_mark(ImDrawList *dl, ImVec2 c, float r, ImU32 col) {
    // (the cat's outline in the disc's radius, y down: from the right of its body, where it leaves the disc at the
    // bottom, up over the head and the ears and down the left with its arm; the disc's edge closes it from the left of
    // the body round to the right, clockwise as ImGui fills: one shape, its edges smoothed)
    static const float cat[][2] = {
        {.25f, .72f}, {.244f, .575f}, {.22f, .5f}, {.18f, .44f}, {.263f, .428f}, {.345f, .405f},
        {.422f, .375f}, {.49f, .33f}, {.55f, .265f}, {.595f, .18f}, {.625f, .077f}, {.635f, -.05f},
        {.61f, -.2f}, {.53f, -.32f}, {.552f, -.411f}, {.549f, -.49f}, {.52f, -.585f}, {.457f, -.583f},
        {.371f, -.554f}, {.245f, -.485f}, {.125f, -.51f}, {0, -.52f}, {-.125f, -.51f}, {-.245f, -.485f},
        {-.371f, -.554f}, {-.457f, -.583f}, {-.52f, -.585f}, {-.549f, -.49f}, {-.552f, -.411f}, {-.53f, -.32f},
        {-.61f, -.2f}, {-.635f, -.05f}, {-.625f, .077f}, {-.595f, .18f}, {-.55f, .265f}, {-.49f, .33f},
        {-.422f, .375f}, {-.345f, .405f}, {-.263f, .428f}, {-.18f, .44f}, {-.22f, .5f}, {-.244f, .575f},
        {-.3f, .594f}, {-.377f, .6f}, {-.46f, .573f}, {-.535f, .49f}, {-.59f, .43f}, {-.69f, .39f},
        {-.733f, .416f}, {-.6875f, .456f}, {-.624f, .525f}, {-.585f, .598f}, {-.56f, .646f}, {-.5f, .695f},
        {-.4f, .724f}, {-.25f, .715f}};
    const float bx = .25f, by = std::sqrt(1 - bx * bx);  // (where the body leaves the disc)
    dl->PathArcTo(c, r, std::atan2(by, -bx), std::atan2(by, bx) + 2 * IM_PI, 40);
    for (const auto &p : cat)
        dl->PathLineTo(ImVec2(c.x + p[0] * r, c.y + p[1] * r));
    dl->PathFillConcave(col);
}
// The header's button to the community's Discord: Discord's mark, the controller-shaped face with its two eyes, drawn
// like GitHub's in the glyphs' colour (no artwork, no brand colours; the same in the MH4U port). r: as GitHub's disc's
// radius; the face a little wider than that disc and shorter
void discord_mark(ImDrawList *dl, ImVec2 c, float r, ImU32 col) {
    // (the face's left half in its half-width, y down: from the middle of its top along the top and down the left side
    // to the eyes' line (upper), then on round the left horn and along the mouth to the middle of its bottom (lower); the
    // right half mirrors it. ImGui fills no holes, so the face is two shapes, above and below the eyes' line, each with
    // its halves of the eyes cut out of that edge, clockwise as ImGui fills; the upper one reaches a pixel below the
    // line, so no seam shows between them)
    static const float upper[][2] = {{0, -.668f},    {-.229f, -.65f},  {-.282f, -.758f}, {-.493f, -.708f}, {-.695f, -.631f},
                                     {-.8f, -.457f}, {-.881f, -.285f}, {-.94f, -.115f},  {-.981f, .076f}};
    static const float lower[][2] = {{-.981f, .076f}, {-.999f, .28f},  {-.992f, .504f}, {-.882f, .578f}, {-.766f, .644f},
                                     {-.628f, .707f}, {-.485f, .758f}, {-.377f, .583f}, {-.548f, .502f}, {-.506f, .47f},
                                     {-.393f, .516f}, {-.259f, .555f}, {-.122f, .577f}, {0, .583f}};
    const int nu = IM_ARRAYSIZE(upper), nl = IM_ARRAYSIZE(lower);
    const float w = r * 1.08f, ex = .332f * w, ey = .076f * w, rx = .18f * w, ry = .2f * w, under = 1;
    auto at = [&](float x, float y) { return ImVec2(c.x + x * w, c.y + y * w); };
    for (int i = nu - 1; i >= 0; i--)  // (up the left side and along the top, then down the right side)
        dl->PathLineTo(at(upper[i][0], upper[i][1]));
    for (int i = 1; i < nu; i++)
        dl->PathLineTo(at(-upper[i][0], upper[i][1]));
    dl->PathLineTo(ImVec2(c.x - upper[nu - 1][0] * w, c.y + ey + under));
    for (float x : {ex, -ex}) {  // (back along the line, over the top of each eye)
        dl->PathLineTo(ImVec2(c.x + x + rx, c.y + ey + under));
        dl->PathEllipticalArcTo(ImVec2(c.x + x, c.y + ey), ImVec2(rx, ry), 0, 0, -IM_PI);
        dl->PathLineTo(ImVec2(c.x + x - rx, c.y + ey + under));
    }
    dl->PathLineTo(ImVec2(c.x + upper[nu - 1][0] * w, c.y + ey + under));
    dl->PathFillConcave(col);
    for (float x : {-ex, ex})  // (along the line, under each eye, then down the right side and back round the left)
        dl->PathEllipticalArcTo(ImVec2(c.x + x, c.y + ey), ImVec2(rx, ry), 0, IM_PI, 0);
    for (int i = 0; i < nl; i++)
        dl->PathLineTo(at(-lower[i][0], lower[i][1]));
    for (int i = nl - 2; i >= 0; i--)
        dl->PathLineTo(at(lower[i][0], lower[i][1]));
    dl->PathFillConcave(col);
}
// The project's official page and its community's Discord, the only links the project gives: in the phone's browser
// (SDL_OpenURL: an Android VIEW intent, which the Discord app takes if it is there; a desktop's own browser), from the
// header's GitHub and Discord buttons once View::OpenSite's or View::OpenDiscord's Open says so (the browser can make
// Android close the game on a phone with little memory). With nothing to open it (a handheld or a TV box with no
// browser) the menu says so, as in the MH4U port
constexpr const char *OFFICIAL_PAGE = "https://github.com/khorne-hub/gu-native";
constexpr const char *DISCORD_INVITE = "https://discord.gg/sk5xEjEMwF";  // (an invite that never expires)
constexpr const char *NO_BROWSER = "No app here can open web pages.";
void open_link(const char *what, const char *url) {
    if (SDL_OpenURL(url)) {
        fprintf(stderr, "[settings] the %s went to the browser (%s)\n", what, url);
        if (s.error == tr(NO_BROWSER))
            s.error.clear();
    } else {
        fprintf(stderr, "[settings] the %s could not be opened (%s): %s\n", what, url, SDL_GetError());
        s.error = tr(NO_BROWSER);
    }
}
void open_official_page() {
    open_link("official page", OFFICIAL_PAGE);
}
void open_discord() {
    open_link("community's Discord", DISCORD_INVITE);
}
// On / Off: a slot whose stud slides to the right and lights it green when on
void switch_mark(ImDrawList *dl, const ImRect &r, bool on) {
    const Look k = touch_look();
    float line = s.m.line, in = line * 1.3f, side = r.GetHeight() - in * 2;
    dl->AddRectFilled(r.Min, r.Max, on ? IM_COL32(58, 112, 40, 255) : IM_COL32(18, 12, 10, 230));
    dl->AddRect(r.Min, r.Max, on ? k.rule : k.edge, 0, 0, line * .7f);
    float x = on ? r.Max.x - in - side : r.Min.x + in;
    ImRect knob(x, r.Min.y + in, x + side, r.Max.y - in);
    dl->AddRectFilled(knob.Min, knob.Max, on ? k.glow : IM_COL32(128, 108, 92, 255));
    dl->AddRect(knob.Min, knob.Max, IM_COL32(0, 0, 0, 170), 0, 0, std::max(1.f, line * .4f));
    diamond(dl, knob.GetCenter(), side * .2f, on ? IM_COL32(28, 20, 15, 255) : IM_COL32(60, 48, 40, 255));
}
// The sections' marks in the column at the left (the MH4U port's the same), drawn as lines in col at c, about size
// across: a controller, an eye, two crossed swords, two hunters, the smithy's hammer, a cog and a scroll
void section_icon(ImDrawList *dl, int section, ImVec2 c, float size, ImU32 col) {
    const float w = std::max(1.5f, size * .085f), h = size * .5f;
    auto at = [&](float x, float y) { return ImVec2(c.x + x * h, c.y + y * h); };
    switch (section) {
    case 0: {  // (Controls: a controller, its d-pad and two buttons)
        dl->AddRect(at(-1, -.56f), at(1, .6f), col, h * .42f, 0, w);
        dl->AddLine(at(-.66f, 0), at(-.26f, 0), col, w);
        dl->AddLine(at(-.46f, -.2f), at(-.46f, .2f), col, w);
        dl->AddCircleFilled(at(.36f, -.1f), w * .95f, col);
        dl->AddCircleFilled(at(.6f, .12f), w * .95f, col);
        break;
    }
    case 1: {  // (Graphics & Audio: an eye)
        const float a0 = IM_PI * 1.17f, a1 = IM_PI * 1.83f;
        dl->PathArcTo(at(0, .7f), h * 1.08f, a0, a1, 16);
        dl->PathStroke(col, 0, w);
        dl->PathArcTo(at(0, -.7f), h * 1.08f, IM_PI - a1 + IM_PI, IM_PI - a0 + IM_PI, 16);
        dl->PathStroke(col, 0, w);
        dl->AddCircle(c, h * .3f, col, 0, w);
        diamond(dl, c, h * .12f, col);
        break;
    }
    case 2:  // (Gameplay: two swords crossed, their guards and pommels)
        for (int side = -1; side <= 1; side += 2) {
            dl->AddLine(at(-.8f * side, -.8f), at(.56f * side, .56f), col, w);
            dl->AddLine(at(.3f * side, .74f), at(.74f * side, .3f), col, w);
            dl->AddCircleFilled(at(.76f * side, .76f), w * 1.1f, col);
        }
        break;
    case 3:  // (Multiplayer: two hunters side by side)
        for (float x : {-.42f, .42f}) {
            dl->AddCircle(at(x, -.42f), h * .24f, col, 0, w);
            dl->PathArcTo(at(x, .62f), h * .48f, IM_PI, IM_PI * 2, 12);
            dl->PathStroke(col, 0, w);
        }
        break;
    case 4: {  // (Mods & Cheats: the smithy's hammer)
        ImVec2 head[5] = {at(-.86f, -.78f), at(.2f, -.78f), at(.42f, -.52f), at(.2f, -.26f), at(-.86f, -.26f)};
        dl->AddPolyline(head, 5, col, ImDrawFlags_Closed, w);
        dl->AddLine(at(-.3f, -.26f), at(.5f, .86f), col, w * 1.5f);
        break;
    }
    case 5: {  // (System: a cog)
        ImVec2 teeth[32];
        for (int i = 0; i < 32; i++) {
            float a = (i + .5f) / 32 * IM_PI * 2, r = ((i / 2) % 2 == 0) ? .82f : .58f;
            teeth[i] = at(std::cos(a) * r, std::sin(a) * r);
        }
        dl->AddPolyline(teeth, 32, col, ImDrawFlags_Closed, w);
        dl->AddCircle(c, h * .22f, col, 0, w);
        break;
    }
    default:  // (Credits & Licenses: a scroll, rolled at two corners, its lines)
        dl->AddRect(at(-.6f, -.66f), at(.6f, .66f), col, 0, 0, w);
        dl->AddCircle(at(-.6f, -.66f), h * .16f, col, 0, w);
        dl->AddCircle(at(.6f, .66f), h * .16f, col, 0, w);
        for (int i = 0; i < 3; i++)
            dl->AddLine(at(-.34f, -.3f + i * .3f), at(.34f, -.3f + i * .3f), col, std::max(1.f, w * .7f));
        break;
    }
}
// A row's help, the "?" at its right: a small seal, a dark disc with a bronze rim and a gold ring, its mark in the
// titles' serif; lit while its help is open
void help_seal(ImDrawList *dl, ImVec2 c, float r, bool open, bool held) {
    const Look k = touch_look();
    float line = std::max(1.5f, s.m.line * .8f);
    dl->AddCircleFilled(ImVec2(c.x, c.y + line), r, IM_COL32(0, 0, 0, 110));
    dl->AddCircleFilled(c, r, held || open ? k.lit : k.plate);
    dl->AddCircle(c, r, k.edge, 0, line);
    dl->AddCircle(c, r - line * 1.7f, fade(k.rule, open ? .9f : .55f), 0, std::max(1.f, line * .5f));
    ImFont *tf = title_font();
    float size = std::floor(r * 1.25f);
    ImVec2 ts = tf->CalcTextSizeA(size, FLT_MAX, 0, "?");
    shadow_text(dl, tf, size, ImVec2(c.x - ts.x * .5f, c.y - ts.y * .52f), open || held ? k.glow : k.rule, "?");
}
// A controller's button in the guide strip at the foot of the phone's menu, as the touch controls draw theirs (the MH4U
// port's): a dark disc with a bronze rim and the controller's own letter or shape (physical: 0 south, 1 east, 2 west,
// 3 north; [Application] ButtonIcons' layout); the shoulders as small tabs, the d-pad as a cross. Its width
void guide_button(ImDrawList *dl, ImVec2 p, float size, int physical, bool shoulder = false, bool right = false) {
    const Look k = touch_look();
    const float line = size > 24 ? 2.f : 1.5f;
    ImFont *font = ImGui::GetFont();
    const float text = std::floor(size * .58f);
    if (physical < 0) {  // (the d-pad)
        ImVec2 c(p.x + size * .5f, p.y + size * .5f);
        const float a = size * .44f, b = size * .15f;
        dl->AddRectFilled(ImVec2(c.x - a, c.y - b), ImVec2(c.x + a, c.y + b), k.edge, b * .5f);
        dl->AddRectFilled(ImVec2(c.x - b, c.y - a), ImVec2(c.x + b, c.y + a), k.edge, b * .5f);
        dl->AddRectFilled(ImVec2(c.x - a + line, c.y - b + line), ImVec2(c.x + a - line, c.y + b - line), k.ink, b * .4f);
        dl->AddRectFilled(ImVec2(c.x - b + line, c.y - a + line), ImVec2(c.x + b - line, c.y + a - line), k.ink, b * .4f);
        return;
    }
    const int layout = s.draft.button_icons;
    if (shoulder) {
        const char *name = layout == 0 ? (right ? "RB" : "LB") : layout == 1 ? (right ? "R" : "L") : (right ? "R1" : "L1");
        ImVec2 a(p.x, p.y + size * .14f), b(p.x + size * 1.5f, p.y + size * .86f);
        dl->AddRectFilled(a, b, k.plate, size * .3f);
        dl->AddRect(a, b, k.edge, size * .3f, 0, line);
        ImVec2 ts = font->CalcTextSizeA(text, FLT_MAX, 0, name);
        shadow_text(dl, font, text, ImVec2((a.x + b.x - ts.x) * .5f, (a.y + b.y - ts.y) * .5f), k.ink, name);
        return;
    }
    ImVec2 c(p.x + size * .5f, p.y + size * .5f);
    dl->AddCircleFilled(c, size * .48f, k.plate);
    dl->AddCircle(c, size * .48f, k.edge, 0, line);
    dl->AddCircle(c, size * .48f - line * 1.6f, fade(k.rule, .5f), 0, line * .6f);
    if (layout == 2) {  // (PlayStation: its shapes, in the rule's gold)
        float r = size * .2f, t = std::max(1.5f, line * .9f);
        if (physical == 0) dl->AddLine(ImVec2(c.x - r, c.y - r), ImVec2(c.x + r, c.y + r), k.rule, t), dl->AddLine(ImVec2(c.x - r, c.y + r), ImVec2(c.x + r, c.y - r), k.rule, t);
        else if (physical == 1) dl->AddCircle(c, r, k.rule, 0, t);
        else if (physical == 2) dl->AddRect(ImVec2(c.x - r, c.y - r), ImVec2(c.x + r, c.y + r), k.rule, 0, 0, t);
        else dl->AddTriangle(ImVec2(c.x, c.y - r), ImVec2(c.x + r, c.y + r * .8f), ImVec2(c.x - r, c.y + r * .8f), k.rule, t);
        return;
    }
    static const char *const abxy[4] = {"A", "B", "X", "Y"}, *const bayx[4] = {"B", "A", "Y", "X"};
    const char *name = (layout == 1 ? bayx : abxy)[physical & 3];
    ImVec2 ts = font->CalcTextSizeA(text, FLT_MAX, 0, name);
    shadow_text(dl, font, text, ImVec2(c.x - ts.x * .5f, c.y - ts.y * .5f), k.ink, name);
}
// ---------------------------------------------------------------- the menu's places (MENU.md; the MH4U port's the same)
// Six sections in the column at the left, and Credits & Licenses as a smaller plate under them; each section a page of
// its own with its basic rows, and pages one level down (View::Page) for the rest, each opened by a row with an arrow.
// The rows come from entries placed on a page (MENU_ENTRY: the page, an order, a function that adds the rows, one that
// puts their options back as they come for Reset, and when they show), so an option is added, or moved, in one place
constexpr int PAGES = 7, ABOUT_PAGE = 6;  // (Controls, Graphics & Audio, Gameplay, Multiplayer, Mods & Cheats, System, Credits & Licenses)
const char *const page_names[PAGES] = {"Controls", "Graphics & Audio", "Gameplay", "Multiplayer", "Mods & Cheats", "System",
                                       "Credits & Licenses"};
const char *const page_ids[PAGES] = {"controls", "graphics", "gameplay", "multiplayer", "mods", "system", "about"};
// A page one level down: its id ("graphics/screen"), its title (English: tr), the page its row is on and where among
// that page's entries; shown (none: always) hides its row, link fills it in (a summary as its value, a help)
struct MenuPage {
    const char *id, *title, *parent;
    int order;
    std::function<bool()> shown;
    std::function<void(Row &)> link;
};
// An entry: rows on a page at an order; reset puts their options back as they come (Reset, whether they show or not);
// shown (none: always; cheap, nothing else) leaves them out, and a page with nothing else on it
struct MenuEntry {
    const char *page;
    int order;
    std::function<void(std::vector<Row> &)> rows;
    std::function<void()> reset;
    std::function<bool()> shown;
};
std::vector<MenuPage> &menu_pages() {
    static std::vector<MenuPage> pages;
    return pages;
}
std::vector<MenuEntry> &menu_entries() {
    static std::vector<MenuEntry> entries;
    return entries;
}
bool menu_page(const char *id, const char *title, const char *parent, int order, std::function<bool()> shown = {},
               std::function<void(Row &)> link = {}) {
    menu_pages().push_back({id, title, parent, order, std::move(shown), std::move(link)});
    return true;
}
bool menu_entry(const char *page, int order, std::function<void(std::vector<Row> &)> rows, std::function<void()> reset = {},
                std::function<bool()> shown = {}) {
    menu_entries().push_back({page, order, std::move(rows), std::move(reset), std::move(shown)});
    return true;
}
#define MENU_CAT2(a, b) a##b
#define MENU_CAT(a, b) MENU_CAT2(a, b)
#define MENU_PAGE(...) [[maybe_unused]] const bool MENU_CAT(menu_page_, __LINE__) = menu_page(__VA_ARGS__)
#define MENU_ENTRY(...) [[maybe_unused]] const bool MENU_CAT(menu_entry_, __LINE__) = menu_entry(__VA_ARGS__)
// The thank-you shown once, after the credits of the first start (draw_thanks, further down), and on Credits & Licenses
constexpr const char *THANKS_TEXT =
    "To everyone who created this game, and to everyone who kept it alive over the years: thank you. This work is a love "
    "letter to the Monster Hunter series, with my deepest respect to the people who develop it.";
// The notice about playing online (the card's, below; the same text in MH4U for Android): %s the server
constexpr const char *ONLINE_TEXT =
    "Playing online connects this device to %s. As with any server on the internet, the servers it connects to can see "
    "your IP address. You can choose another server, or none, in the menu's Multiplayer section.";
void thanks_show();
void online_then(const char *server, std::function<void()> fn);  // (the notice about playing online: the card's, below)
const char *thanks_signature();
bool thanks_on(double now);
void credits_show();  // (the credits shown when the app opens: draw_credits, further down)
// The program's name in the credits and on their page, for each host platform.
const char *app_title() {
#ifdef __ANDROID__
    return "MHGU for Android";
#elif defined(MHGU_IOS)
    return "MHGU for iOS";
#else
    return tr("MHGU for PC");
#endif
}
struct ScanResult {
    std::vector<std::string> names;  // (the order ModConflict's indexes are in)
    ModScan scan = {};
    std::atomic<bool> done{false};
    ~ScanResult() { modscan_free(&scan); }
};
// The Mods page: the mods folder's state (modorder.h), which is saved with the rest of the settings
struct Mods {
    std::vector<ModEntry> draft, saved, boot;
    bool boot_set = false;
    std::shared_ptr<ScanResult> scan;
} mods;
bool same_mods(const std::vector<ModEntry> &a, const std::vector<ModEntry> &b) {
    if (a.size() != b.size())
        return false;
    for (size_t i = 0; i < a.size(); ++i)
        if (a[i].on != b[i].on || strcmp(a[i].name, b[i].name))
            return false;
    return true;
}
bool mods_dirty() { return !same_mods(mods.draft, mods.saved); }
// The Cheats tab: each cheat on or off (cheats.h), applied while the game runs when the settings are saved
struct Cheats {
    std::vector<char> draft, saved;
} cheat_tab;
bool cheats_dirty() { return cheat_tab.draft != cheat_tab.saved; }
void load_cheats() {
    cheat_tab.draft.assign(cheats_count(), 0);
    for (int i = 0; i < cheats_count(); ++i)
        cheat_tab.draft[i] = cheats_on(i);
    cheat_tab.saved = cheat_tab.draft;
}
bool mods_restart() { return !same_mods(mods.saved, mods.boot); }
void load_mods() {
    ModEntry all[MODS_MAX];
    int n = mods_installed(all, MODS_MAX);
    mods.draft.assign(all, all + n);
    mods.saved = mods.draft;
    if (!mods.boot_set) {
        mods.boot = mods.draft;
        mods.boot_set = true;
    }
    mods.scan.reset();
}
void start_scan() {
    auto result = std::make_shared<ScanResult>();
    for (const auto &m : mods.draft)
        result->names.push_back(m.name);
    std::sort(result->names.begin(), result->names.end(),
              [](const std::string &a, const std::string &b) { return strcasecmp(a.c_str(), b.c_str()) < 0; });
    mods.scan = result;
    std::thread([result]() {
        std::vector<std::array<char, 128>> names;
        for (const auto &n : result->names) {
            names.emplace_back();
            snprintf(names.back().data(), 128, "%s", n.c_str());
        }
        modscan_run(reinterpret_cast<const char(*)[128]>(names.data()), (int)names.size(), &result->scan);
        result->done = true;
    }).detach();
}
int mod_index(const std::string &name) {
    for (int i = 0; i < (int)mods.draft.size(); ++i)
        if (name == mods.draft[i].name)
            return i;
    return -1;
}
bool dirty();
// The guides at the menu's bottom: Navigation, Confirm, Back and Save (items: which of them, bit i). A controller's
// buttons only after a controller's press ([Application] ButtonIcons); else the keys - with the mouse used last, its
// wheel for Navigation and its click for Confirm
enum { GUIDE_NAV = 1, GUIDE_CONFIRM = 2, GUIDE_BACK = 4, GUIDE_SAVE = 8, GUIDE_ALL = 15 };
const char *const guide_labels[4] = {"Navigation", "Confirm", "Back", "Save"};
// (the Save guide says Remove while the dropdown's focused choice is a remembered one: the same button takes it out, or
// Delete - picker_keys)
bool guide_remove() {
    if (!s.dropdown.open || s.focus.compare(0, 7, "choice."))
        return false;
    int i = atoi(s.focus.c_str() + 7);
    return i >= 0 && i < (int)s.dropdown.removable.size() && s.dropdown.removable[i] && s.dropdown.remove;
}
const char *guide_label(int i) { return i == 3 && guide_remove() ? "Remove" : guide_labels[i]; }
struct GuideLayout {
    ImVec2 offset[4];
    float height = 0;
    int items = GUIDE_ALL;
};
// Guide i's glyph at p (d: nullptr, only measured); its width
float guide_glyph(ImDrawList *d, ImVec2 p, float f, int i) {
    if (s.input == USED_PAD) {
        // (Save: the top face button, Y / X / triangle - greyed while there is nothing to save)
        const int icons[] = {SettingsIcons::Dpad, SettingsIcons::Confirm, SettingsIcons::Back, SettingsIcons::Save};
        if (d)
            SettingsIcons::draw(d, p, f, s.draft.button_icons, icons[i],
                                i == 3 ? 3
                                       : menu_confirm_position(config_live_menu_confirm(), overlay_face_position(0),
                                                               overlay_face_position(1), i == 2));
        return f;
    }
    if (i < 2 && s.input == USED_MOUSE)
        return d ? SettingsIcons::mouse(d, p, f, i == 0) : f;
    const char *key = i == 0 ? "" : i == 1 ? "Enter" : i == 2 ? "Esc" : guide_remove() ? "Del" : "Ctrl+S";  // ("": the arrows)
    return d ? SettingsIcons::key(d, p, f, key) : SettingsIcons::key_width(f, key);
}
GuideLayout guide_layout(float width, int items = GUIDE_ALL) {
    GuideLayout layout;
    layout.items = items;
    float f = ImGui::GetFontSize(), x = 0, y = 0;
    for (int i = 0; i < 4; i++) {
        if (!(items >> i & 1))
            continue;
        float item_width = guide_glyph(nullptr, ImVec2(0, 0), f, i) + f * .4f + ImGui::CalcTextSize(tr(guide_label(i))).x;
        if (x && x + item_width > width) {
            x = 0;
            y += f + ImGui::GetStyle().ItemSpacing.y;
        }
        layout.offset[i] = ImVec2(x, y);
        x += item_width + f;
    }
    layout.height = y + f;
    return layout;
}
void draw_guides(ImGuiWindow *window, const GuideLayout &layout, float top) {
    auto *draw = window->DrawList;
    ImVec2 start(window->InnerRect.Min.x + ImGui::GetStyle().WindowPadding.x, top);
    ImU32 background = ImGui::GetColorU32(ImGuiCol_WindowBg) | IM_COL32_A_MASK;
    draw->AddRectFilled(ImVec2(window->InnerRect.Min.x, top - ImGui::GetStyle().ItemSpacing.y),
                        ImVec2(window->InnerRect.Max.x, top + layout.height), background);
    float f = ImGui::GetFontSize();
    for (int i = 0; i < 4; i++) {
        if (!(layout.items >> i & 1))
            continue;
        ImVec2 pos(start.x + layout.offset[i].x, start.y + layout.offset[i].y);
        float glyph = guide_glyph(draw, pos, f, i);
        draw->AddText(ImVec2(pos.x + glyph + f * .4f, pos.y),
                      i == 3 && !dirty() && !guide_remove() ? theme().text_off : ImGui::GetColorU32(ImGuiCol_Text),
                      tr(guide_label(i)));
    }
}
bool confirmation() {
    return s.view == View::CloseChanges || s.view == View::Exit || s.view == View::Restart ||
           s.view == View::Reset || s.view == View::ImportSave || s.view == View::Remove || s.view == View::OpenSite ||
           s.view == View::OpenDiscord || s.view == View::ChatOn;
}
// The guides a desktop's view shows at its bottom (0: none): all four on the tabs, Confirm and Back on a dialog, and
// Navigation too on a page of rows (the licenses' scroll: no Confirm there). None while a key is being chosen, text
// typed, the menu moved or a controller mapped, where those keys and buttons do something else
int view_guides() {
    switch (s.view) {
    case View::Main: case View::Page: return GUIDE_ALL;
    case View::KeyCapture: case View::Keyboard: case View::Move: case View::PadMap: return 0;
    case View::Licenses: return GUIDE_NAV | GUIDE_BACK;
    default: return confirmation() ? GUIDE_CONFIRM | GUIDE_BACK : GUIDE_NAV | GUIDE_CONFIRM | GUIDE_BACK;
    }
}
bool equal(const Config &a, const Config &b) {
#define SAME(f)                                                                                              \
    if (a.f != b.f)                                                                                          \
    return false
    SAME(display_mode);
    SAME(width);
    SAME(height);
    SAME(render_w);
    SAME(render_h);
    SAME(render_scale);
    SAME(low_end);
    SAME(shadows);
    SAME(bloom);
    SAME(grass);
    SAME(effects);
    SAME(reverb);
    SAME(adreno_fix);
    SAME(fps);
    SAME(town_fps_saver);
    SAME(fsr);
    SAME(fsr_upscaler);
    SAME(fsr_quality);
    SAME(fsr_sharpness);
    SAME(fsr_objmotion);
    SAME(fsr_reactive);
    SAME(fsr_animsurf);
    SAME(vsync);
    SAME(shader_prewarm);
    SAME(draw_distance);
    SAME(smooth_gradients);
    SAME(msaa);
    SAME(fxaa);
    SAME(fxaa_mode);
    SAME(face_buttons);
    SAME(ldn_port);
    SAME(sync_small_monsters);
    SAME(bonus_content);
    SAME(village_in_hub);
    SAME(send_all_rewards);
    SAME(mouse_sensitivity);
    SAME(touch_controls);
    SAME(touch_hud);
    SAME(touch_camera);
    SAME(touch_opacity);
    SAME(aspect_ratio);
    SAME(fov);
    SAME(ui_anchor);
    SAME(fill_screen);
    SAME(background_input);
    SAME(combo_window);
    SAME(volume);
    SAME(mute_in_background);
    SAME(touch_vibration);
    SAME(phone_rumble);
    SAME(gyro_aim);
    SAME(gyro_sensitivity);
    SAME(mouse_menus);
    SAME(show_stats);
    SAME(pause_background);
    SAME(pause_menu);
    SAME(button_icons);
    SAME(menu_theme);
    SAME(discord);
    SAME(discord_hunter);
    SAME(language);
    SAME(menu_scale);
    SAME(menu_confirm);
    SAME(confirm_exit);
    SAME(updates);
    SAME(hp.village);
    SAME(hp.quests);
#undef SAME
    if (a.lock_on != b.lock_on)
        return false;
    if (memcmp(a.touch_show, b.touch_show, sizeof a.touch_show) || memcmp(a.touch_combo, b.touch_combo, sizeof a.touch_combo) ||
        memcmp(a.touch_combo_pad, b.touch_combo_pad, sizeof a.touch_combo_pad))
        return false;
    if (memcmp(a.binds, b.binds, sizeof a.binds))
        return false;
    if (strcmp(a.ldn_join, b.ldn_join) || strcmp(a.ldn_server, b.ldn_server) || strcmp(a.ldn_key, b.ldn_key) ||
        strcmp(a.chat_key, b.chat_key) || strcmp(a.gpu, b.gpu))
        return false;
    for (int n = 0; n < 4; ++n)
        if (a.hp.scale[n] != b.hp.scale[n])
            return false;
    for (int i = 0; i < a.hp.quests; ++i) {
        if (a.hp.quest[i].quest != b.hp.quest[i].quest)
            return false;
        for (int n = 0; n < 4; ++n)
            if (a.hp.quest[i].scale[n] != b.hp.quest[i].scale[n])
                return false;
    }
    return true;
}
bool dirty() { return !equal(s.draft, s.saved) || std::lround(s.chat_panel_size_draft * 100.f) != std::lround(s.chat_panel_size_saved * 100.f) || mods_dirty() || cheats_dirty(); }
bool pending_text() {
    bool editing = s.view == View::Keyboard;
    for (const auto &o : s.origins)
        editing |= o.view == View::Keyboard;
    return editing && !s.keyboard.game && s.keyboard.buffer != s.keyboard.original;
}
std::string quest_id(int index) { return "quest." + std::to_string(s.quest_keys[index]); }
void quest_keys() {
    for (int i = 0; i < s.draft.hp.quests; ++i)
        s.quest_keys[i] = s.next_quest_key++;
}
void focus(const std::string &id) {
    s.focus = id;
    s.focus_request = true;
}
void close_dropdown() {
    if (!s.dropdown.open)
        return;
    s.dropdown.open = false;
    focus(s.dropdown.row);
}
// The scroll of the rows: the phone's list, or the menu itself
float list_scroll() {
    auto *w = s.list ? ImGui::FindWindowByID(s.list) : ImGui::FindWindowByName("Settings##main");
    return w ? w->Scroll.y : 0;
}
double anim_now() { return SDL_GetTicksNS() / 1e9; }
void push(View view, const std::string &first) {
    s.dropdown.open = false;
    s.drag = {};
    s.origins.push_back({s.view, s.focus, list_scroll(), s.at});
    s.view = view;
    s.help_open.clear();
    focus(first);
    s.error.clear();
    s.restore_scroll = true;
    s.scroll = 0;
    s.view_at = anim_now();
    ImGui::ClearActiveID();
}
void pop() {
    s.dropdown.open = false;
    s.drag = {};
    if (s.origins.empty()) {
        s.view = View::Main;
        s.focus.clear();
    } else {
        auto o = s.origins.back();
        s.origins.pop_back();
        s.view = o.view;
        s.at = o.at;
        focus(o.focus);
        s.scroll = o.scroll;
    }
    s.help_open.clear();
    s.restore_scroll = true;
    s.error.clear();
    s.view_at = anim_now();
    ImGui::ClearActiveID();
}
void first_page(int page) {
    s.dropdown.open = false;
    s.drag = {};
    s.page = page;
    s.view = View::Main;
    s.at.clear();
    s.help_open.clear();
    s.origins.clear();
    s.focus.clear();
    s.focus_request = true;
    s.restore_scroll = true;
    s.scroll = 0;
    s.error.clear();
}
void discard() {
    s.draft = s.saved;
    s.chat_panel_size_draft = s.chat_panel_size_saved;
    chat_panel_preview_size(s.chat_panel_size_saved);
    mods.draft = mods.saved;
    cheat_tab.draft = cheat_tab.saved;
    quest_keys();
    s.error.clear();
    s.saved_notice = false;
}
// A view left without doing what it asks (Back: B, Esc, a click outside the menu; a dialog's Cancel or Close): each
// leaves things as they were, then the view before it shows. A desktop's Exit game that the window's close button asked
// for, the menu closed before: back to the game
void leave_view(bool *open) {
    if (s.view == View::Move) {
        s.move_position = s.move_start;
        s.position_override = true;
    }
    if (s.view == View::CloseChanges) touch_edit_cancel();  // (B / Esc / the chord: the menu stays, no editor)
    if (s.view == View::Keyboard && s.keyboard.game) g_close_now = true;  // (the game's entry stays as it was)
#ifndef __ANDROID__
    if (s.view == View::ImportSave) pc_import_save_cancel();
    if (s.view == View::PadMap) padmap_cancel();  // (as its Cancel: or the controller stayed in the mapping, unread)
    bool to_game = s.view == View::Exit && s.exit_only;
#endif
    pop();
#ifndef __ANDROID__
    if (to_game)
        *open = false;
#endif
}
void ask_back(bool *open) {
    if (s.dropdown.open)
        close_dropdown();
    else if (s.view != View::Main)
        leave_view(open);
    else if (dirty())
        push(View::CloseChanges, "dialog.cancel");
    else
        *open = false;
}
// The phone's Close (X), from any view: asks first when something is unsaved, as Back does from the tabs
void ask_close(bool *open) {
    s.dropdown.open = false;
    if (dirty() || pending_text())
        push(View::CloseChanges, "dialog.cancel");
    else
        *open = false;
}
void keyboard(const std::string &title, const std::string &initial, size_t cap,
              std::function<bool(const std::string &, std::string &)> commit) {
    s.keyboard = {title, initial, initial, initial.size(), cap, false, false, std::move(commit)};
    push(View::Keyboard, "key.0");
#ifdef __ANDROID__  // (played by touch: the phone's own keyboard comes up at once, the view's keys under it - a
    // controller's player keeps the view's keys first. Up to 0.1.9.2 its key had to be found first: "the phone's keyboard
    // was taken out". The MH4U port's the same)
    if (!host_input_real_pad()) {
        s.keyboard.phone = true;
        textinput_menu_keyboard_show();
    }
#endif
}
// The keyboard view for the game's text entry (the hunter's name...): its text now, confirmed into it with Accept
void game_text_keyboard() {
    char text[2048];
    textinput_peek(text, sizeof text);
    keyboard(tr("Text"), text, 500, [](const std::string &t, std::string &) {
        textinput_set(t.c_str());
        textinput_key(TI_ENTER);
        g_close_now = true;
        return true;
    });
    s.keyboard.game = true;
}
void insert(const std::string &text) {
    if (s.keyboard.select_all) {
        s.keyboard.buffer.clear();
        s.keyboard.cursor = 0;
        s.keyboard.select_all = false;
    }
    if (s.keyboard.buffer.size() + text.size() > s.keyboard.capacity)
        return;
    s.keyboard.buffer.insert(s.keyboard.cursor, text);
    s.keyboard.cursor += text.size();
    s.error.clear();
}
void erase_previous() {
    if (s.keyboard.select_all) {
        s.keyboard.buffer.clear();
        s.keyboard.cursor = 0;
        s.keyboard.select_all = false;
        return;
    }
    if (!s.keyboard.cursor)
        return;
    size_t begin = s.keyboard.cursor - 1;
    while (begin && (static_cast<unsigned char>(s.keyboard.buffer[begin]) & 0xc0) == 0x80)
        --begin;
    s.keyboard.buffer.erase(begin, s.keyboard.cursor - begin);
    s.keyboard.cursor = begin;
    s.error.clear();
}
bool accept_keyboard() {
    if (!s.keyboard.commit(s.keyboard.buffer, s.error))
        return false;
    pop();
    return true;
}
// The row's choices in a dropdown under it; selected: the one it has now (-1: none of them). removable: those remembered,
// which remove takes out of their list (an x beside each)
void choices(const Row &row, std::vector<std::string> names, int selected, std::function<void(int)> set,
             std::vector<char> removable = {}, std::function<void(int)> remove = {}) {
    int first = std::clamp(selected, 0, (int)names.size() - 1);
    s.dropdown = {true, false, false, row.id, std::move(names), selected, std::move(set), {}, row.title, std::move(removable),
                  std::move(remove)};
    s.dropdown.help = help_text(row);  // (and as the page's row has it: picker_help)
    s.dropdown_at = anim_now();
    focus("choice." + std::to_string(first));
}
// What the settings table (config.c g_settings) says of a setting: does it need a restart, a number's range. ini():
// the key a row is for (its restart mark and its help)
const char *ini(const char *key) { return key; }
bool cold(const char *key) { return key && config_restart_key(key); }
float lo(const char *key) { float a = 0, b = 0; config_range(key, &a, &b); return a; }
float hi(const char *key) { float a = 0, b = 0; config_range(key, &a, &b); return b; }
void keyed(Row &r, const char *key) {
    r.key = key ? key : "";
    r.cold = cold(key);
}
void add_bool(std::vector<Row> &rows, const char *id, const char *name, int *value, const char *key = nullptr) {
    Row r;
    r.id = id;
    r.title = tr(name);
    keyed(r, key);
    r.value = tr(*value ? "On" : "Off");
    r.toggle = *value ? 1 : 0;
    r.adjust = [value](int d) { *value = d > 0 ? 1 : 0; };
    r.activate = [value]() { *value = !*value; };
    rows.push_back(std::move(r));
}
void add_choice(std::vector<Row> &rows, const char *id, const char *name, int selected,
                const std::vector<std::string> &names, std::function<void(int)> set, const char *key = nullptr) {
    Row r;
    r.id = id;
    r.title = tr(name);
    r.value = names[std::clamp(selected, 0, (int)names.size() - 1)];
    keyed(r, key);
    r.adjust = [selected, names, set](int d) { set((selected + d + (int)names.size()) % (int)names.size()); };
    Row copy = r;
    r.menu = true;
    r.activate = [copy, names, selected, set]() { choices(copy, names, selected, set); };
    rows.push_back(std::move(r));
}
void add_number(std::vector<Row> &rows, const std::string &id, const std::string &name,
                std::function<double()> get, std::function<void(double)> set, double low, double high,
                double step, bool integral, const char *key = nullptr,
                std::function<bool(double, std::string &)> check = {}) {
    char text[64];
    snprintf(text, sizeof text, integral ? "%.0f" : "%.2f", get());
    Row r;
    r.id = id;
    r.title = name;
    r.value = text;
    r.number = true;
    keyed(r, key);
    r.adjust = [get, set, low, high, step, check](int d) {
        double v = std::clamp(get() + d * step, low, high);
        std::string error;
        for (int attempts = 0; attempts <= HP_QUESTS_MAX; ++attempts) {
            if (!check || check(v, error)) {
                set(v);
                break;
            }
            double next = std::clamp(v + d * step, low, high);
            if (next == v)
                break;
            v = next;
        }
    };
    rows.push_back(std::move(r));
}
void number(std::vector<Row> &r, const char *id, const char *name, int *p, int low, int high, int step = 1,
            const char *key = nullptr) {
    add_number(
        r, id, tr(name), [p]() { return (double)*p; }, [p](double v) { *p = (int)v; }, low, high, step, true,
        key);
}
void number(std::vector<Row> &r, const std::string &id, const std::string &name, float *p, float low,
            float high, float step, const char *key = nullptr) {
    add_number(
        r, id, name, [p]() { return (double)*p; }, [p](double v) { *p = (float)v; }, low, high, step, false,
        key);
}
// A line of text between the rows (not selectable), after a small diamond, wrapped: Credits & Licenses' (the MH4U port's)
void note(std::vector<Row> &rows, const std::string &id, const std::string &text) {
    Row r;
    r.id = id;
    r.title = text;
    r.header = r.note = true;
    r.enabled = false;
    rows.push_back(std::move(r));
}
// A section's title between the rows (not selectable)
void header(std::vector<Row> &rows, const std::string &id, const std::string &title) {
    Row r;
    r.id = id;
    r.title = title;
    r.header = true;
    r.enabled = false;
    rows.push_back(std::move(r));
}
void action(std::vector<Row> &rows, const std::string &id, const std::string &name, std::function<void()> fn,
            bool enabled = true) {
    Row r;
    r.id = id;
    r.title = name;
    r.action = true;
    r.activate = std::move(fn);
    r.enabled = enabled;
    rows.push_back(std::move(r));
}
// A text setting (a char array of the draft, size bytes) typed on the on-screen keyboard; shown: its row's value
void text(std::vector<Row> &rows, const char *id, const char *name, char *field, size_t size, const std::string &shown,
          const char *key) {
    size_t at = (size_t)(field - (char *)&s.draft);
    Row r;
    r.id = id;
    r.title = tr(name);
    r.value = shown;
    keyed(r, key);
    r.activate = [name, at, size]() {
        keyboard(tr(name), (char *)&s.draft + at, size - 1, [at, size](const std::string &typed, std::string &error) {
            Config temp = s.draft;
            SDL_strlcpy((char *)&temp + at, typed.c_str(), size);
            char why[512];
            if (!config_validate(&temp, why, sizeof why)) {
                error = settings_text(s.draft.language, why);
                return false;
            }
            s.draft = temp;
            return true;
        });
    };
    rows.push_back(std::move(r));
}
// The hub server row: the short list (config.h LDN_SERVERS, the default first), the servers typed and saved (the last
// first: [Multiplayer] RecentServer1..; an x takes one out), Custom... (typed on the keyboard; the last one typed is
// offered again) and Off. Empty in the file is the default, so a later default reaches everyone who kept it; a typed one
// is kept as it is
std::string g_custom_server;  // (Custom... starts from it: the typed one in use, else the last one typed this session)
std::string g_custom_key;     // (and the matchmaking key's)
bool server_off(const char *server) {
    char name[sizeof s.draft.ldn_server];
    return !ldn_server_name(server, name, sizeof name);
}
bool server_preset(const char *server) {
    static const char *const presets[] = LDN_SERVERS;
    for (const char *p : presets)
        if (!strcasecmp(server, p))
            return true;
    return false;
}
// A server the player typed: not the default (empty), not Off, none of the short list's
bool typed_server(const char *server) { return *server && !server_off(server) && !server_preset(server); }
// The remembered ones the rows list: the servers (without the short list's, should a later version add one of them to
// it) or the keys, the last first
std::vector<std::string> remembered(bool servers) {
    std::vector<std::string> out;
    for (int i = 0; i < LDN_RECENT; i++) {
        const char *v = servers ? s.draft.ldn_recent_server[i] : s.draft.ldn_recent_key[i];
        if (servers ? typed_server(v) : *v != 0)
            out.push_back(v);
    }
    return out;
}
// Save applies a hub server or a key: one the player typed (or picked from the list) goes to the front of its list, only
// when it changes. The one it replaces is never put back: one taken out of the list stays out, in use or not (the one
// typed in an older version went in once, at this version's first start: config_load)
void remember_typed(Config &c, const Config &before) {
    if (strcmp(c.ldn_server, before.ldn_server) && typed_server(c.ldn_server))
        config_recent_add(c.ldn_recent_server[0], LDN_RECENT, sizeof c.ldn_recent_server[0], c.ldn_server, true);
    if (strcmp(c.ldn_key, before.ldn_key) && *c.ldn_key)
        config_recent_add(c.ldn_recent_key[0], LDN_RECENT, sizeof c.ldn_recent_key[0], c.ldn_key, false);
}
// A remembered server or key out of its list (its x in the picker), at once and in the file too: it is no setting, so
// Save and Discard have nothing to do with it. Then the row's picker again, as the list is now (reopen_picker)
void forget(bool server, const std::string &value, const char *row, int at) {
    auto out = [server, &value](Config &c) {
        if (server)
            config_recent_remove(c.ldn_recent_server[0], LDN_RECENT, sizeof c.ldn_recent_server[0], value.c_str(), true);
        else
            config_recent_remove(c.ldn_recent_key[0], LDN_RECENT, sizeof c.ldn_recent_key[0], value.c_str(), false);
    };
    Config c = s.saved;
    out(c);
    char error[512];
    if (!config_save(&c, error, sizeof error)) {
        s.error = settings_text(s.draft.language, error);
        return;
    }
    out(s.saved);
    out(s.draft);
    s.reopen = row, s.reopen_at = at;
}
// A remembered choice was taken out: the row's picker opens again with the list as it is now, at the same place
void reopen_picker(std::vector<Row> &rows) {
    if (s.reopen.empty())
        return;
    const std::string id = s.reopen;
    s.reopen.clear();
    auto it = std::find_if(rows.begin(), rows.end(), [&](const Row &r) { return r.id == id; });
    if (it == rows.end() || !it->activate) {
        close_dropdown();
        return;
    }
    double at = s.dropdown_at;
    auto fn = it->activate;
    fn();
    s.dropdown_at = at;  // (the same picker: it doesn't come in again)
    if (s.dropdown.open && !s.dropdown.names.empty())
        focus("choice." + std::to_string(std::clamp(s.reopen_at, 0, (int)s.dropdown.names.size() - 1)));
}
#include "settings_chat.inc"  // (S32, S35: the chat's pages, the key's generator)
void server_row(std::vector<Row> &rows) {
    static const char *const presets[] = LDN_SERVERS;
    const std::vector<std::string> used = remembered(true);
    const int n = (int)std::size(presets), m = (int)used.size(), custom = n + m, off = custom + 1;
    const char *now = s.draft.ldn_server;
    int selected = !*now ? 0 : server_off(now) ? off : custom;
    for (int i = 0; i < n; i++)  // (one typed as it is in the list: that one)
        if (!strcasecmp(now, presets[i]))
            selected = i;
    for (int i = 0; i < m && selected == custom; i++)  // (or as one remembered)
        if (!strcasecmp(now, used[i].c_str()))
            selected = n + i;
    if (selected >= n && selected <= custom)  // (a typed one in use, remembered or not: Custom... starts from it)
        g_custom_server = now;
    std::vector<std::string> names;
    std::vector<char> removable(n, 0);
    for (int i = 0; i < n; i++)
        names.push_back(i ? std::string(presets[i]) : std::string(presets[i]) + "  (" + tr("Default") + ")");
    for (const auto &v : used)
        names.push_back(v), removable.push_back(1);
    names.push_back(selected == custom ? fmt("Custom: %s", now) : std::string(tr("Custom...")));
    names.push_back(tr("Off: only your local network"));
    removable.resize(names.size(), 0);
    Row r;
    r.id = "server";
    r.title = tr("Hub server");
    r.value = selected < n ? std::string(presets[selected]) : selected == off ? std::string(tr("Only your local network")) : std::string(now);
    keyed(r, ini("Server"));
    auto set = [n, used, custom, off](int i) {
        if (i == custom) {
            const size_t size = sizeof s.draft.ldn_server;
            keyboard(tr("Hub server"), g_custom_server, size - 1, [size](const std::string &typed, std::string &error) {
                Config temp = s.draft;
                SDL_strlcpy(temp.ldn_server, typed.c_str(), size);
                char why[512];
                if (!config_validate(&temp, why, sizeof why)) {
                    error = settings_text(s.draft.language, why);
                    return false;
                }
                s.draft = temp;
                if (*temp.ldn_server && !server_off(temp.ldn_server))
                    g_custom_server = temp.ldn_server;
                return true;
            });
            return;
        }
        const char *v = i == off ? "Off" : i >= n ? used[i - n].c_str() : i ? presets[i] : "";
        SDL_strlcpy(s.draft.ldn_server, v, sizeof s.draft.ldn_server);
    };
    // (left / right go through the list, the remembered ones and Off, not Custom..., which opens the keyboard)
    r.adjust = [selected, custom, off, set](int d) {
        int at = selected >= custom ? custom : selected;  // (Off, or a custom one, is Custom...'s place here)
        at = (at + d + custom + 1) % (custom + 1);
        set(at == custom ? off : at);
    };
    r.menu = true;
    Row copy = r;
    auto remove = [n, used](int i) {
        if (i >= n && i - n < (int)used.size())
            forget(true, used[i - n], "server", i);
    };
    r.activate = [copy, names, selected, set, removable, remove]() { choices(copy, names, selected, set, removable, remove); };
    rows.push_back(std::move(r));
}
// The matchmaking key's row, as the hub server's: Public (no key, the default), the keys typed and saved (the last first:
// [Multiplayer] RecentKey1..; an x takes one out) and Custom... (typed on the keyboard)
void key_row(std::vector<Row> &rows) {
    const std::vector<std::string> used = remembered(false);
    const int m = (int)used.size(), custom = 1 + m;
    const char *now = s.draft.ldn_key;
    int selected = !*now ? 0 : custom;
    for (int i = 0; i < m && selected == custom; i++)
        if (now == used[i])
            selected = 1 + i;
    if (selected)  // (the key in use, remembered or not: Custom... starts from it, as the typed row did)
        g_custom_key = now;
    std::vector<std::string> names = {std::string(tr("Public")) + "  (" + tr("Default") + ")"};
    std::vector<char> removable = {0};
    for (const auto &v : used)
        names.push_back(v), removable.push_back(1);
    names.push_back(selected == custom ? fmt("Custom: %s", now) : std::string(tr("Custom...")));
    removable.push_back(0);
    names.push_back(cs("Generate a key", "Generar una clave"));  // (S35: settings_chat.inc)
    removable.push_back(0);
    Row r;
    r.id = "key";
    r.title = tr("Matchmaking key");
    r.value = *now ? std::string(now) : std::string(tr("Public"));
    keyed(r, ini("Key"));
    auto set = [used, custom](int i) {
        if (i == custom + 1) {
            chat_new_key();
            return;
        }
        if (i == custom) {
            const size_t size = sizeof s.draft.ldn_key;
            keyboard(tr("Matchmaking key"), g_custom_key, size - 1, [size](const std::string &typed, std::string &error) {
                Config temp = s.draft;
                SDL_strlcpy(temp.ldn_key, typed.c_str(), size);
                char why[512];
                if (!config_validate(&temp, why, sizeof why)) {
                    error = settings_text(s.draft.language, why);
                    return false;
                }
                s.draft = temp;
                if (*temp.ldn_key)
                    g_custom_key = temp.ldn_key;
                return true;
            });
            return;
        }
        SDL_strlcpy(s.draft.ldn_key, i ? used[i - 1].c_str() : "", sizeof s.draft.ldn_key);
    };
    // (left / right go through Public and the remembered ones, not Custom...: from a typed one, to either end)
    r.adjust = [selected, custom, set](int d) {
        int at = selected == custom ? (d > 0 ? custom - 1 : 0) : selected;
        set((at + d + custom) % custom);
    };
    r.menu = true;
    Row copy = r;
    auto remove = [used](int i) {
        if (i >= 1 && i - 1 < (int)used.size())
            forget(false, used[i - 1], "key", i);
    };
    r.activate = [copy, names, selected, set, removable, remove]() { choices(copy, names, selected, set, removable, remove); };
    rows.push_back(std::move(r));
}
// ---- Crossplay with emulators (runtime/net/net.h: xroom.c, ryuldn.c): its own section of the Multiplayer page, every
// text in English and Spanish side by side. Off, the page is as before; on, the port's own hubs (server, key, LAN) give
// way to the emulators' room or server.
const char *xl(const char *en, const char *es) { return (s.editing ? s.draft.language : config_language()) == 1 ? es : en; }
// A text row of the crossplay section (a field of the draft), with its title and help in both languages
void crossplay_text(std::vector<Row> &rows, const char *id, const char *title, char *field, size_t size,
                    const std::string &shown, const char *key, const char *help) {
    text(rows, id, title, field, size, shown, key);
    rows.back().help = help;
}
// Saved: a room or server no longer used is left (not while the game plays in a network through it: then the next
// search or hub uses the new settings, as a changed room does)
void crossplay_saved(const Config &before, const Config &now) {
    if (ldn_net_up()) return;
    bool rooms_now = now.crossplay == XPLAY_ROOMS;
    if (before.crossplay == XPLAY_ROOMS && (!rooms_now || strcmp(before.xroom, now.xroom) ||
                                            strcmp(before.xroom_password, now.xroom_password) ||
                                            strcmp(before.xnick, now.xnick) || before.xroom_host != now.xroom_host ||
                                            before.xroom_host_port != now.xroom_host_port))
        xroom_leave();
    if (!rooms_now || !now.xroom_host) xroomhost_stop();
    if (before.crossplay == XPLAY_RYUJINX && now.crossplay != XPLAY_RYUJINX) ryuldn_leave();
}
void crossplay_rows(std::vector<Row> &r) {
    Config &c = s.draft;
    add_choice(r, "xplay", xl("Play online with", "Jugar en línea con"), c.crossplay,
               {xl("This app's hubs", "Las salas de esta app"),
                xl("Emulator rooms (Eden, Citron, Sudachi, yuzu)", "Salas de emuladores (Eden, Citron, Sudachi, yuzu)"),
                xl("Ryujinx (LDN)", "Ryujinx (LDN)")},
               [](int v) { s.draft.crossplay = v; }, ini("Crossplay"));
    r.back().title = xl("Play online with", "Jugar en línea con");
    r.back().help = xl("This app's hubs: players of this app, on phones and PCs (the hub server and key below). Emulator rooms: "
                       "the multiplayer rooms of Eden, Citron, Sudachi, Suyu and yuzu, with the players of those emulators "
                       "and of this app. Ryujinx: the LDN servers of Ryujinx (and Ryubing). Everyone needs version "
                       XPLAY_GAME_VERSION " of the game. Then Create Hub and Search Hubs work as usual.",
                       "Las salas de esta app: jugadores de esta app, en teléfonos y PC (el servidor de salas y la clave de "
                       "abajo). Salas de emuladores: las salas multijugador de Eden, Citron, Sudachi, Suyu y yuzu, con los "
                       "jugadores de esos emuladores y de esta app. Ryujinx: los servidores LDN de Ryujinx (y Ryubing). Todos "
                       "necesitan la versión " XPLAY_GAME_VERSION " del juego. Después, Crear sala y Buscar salas funcionan "
                       "como siempre.");
    if (!c.crossplay) return;
    XStatus st;
    bool rooms = c.crossplay == XPLAY_ROOMS;
    if (rooms) {
        add_bool(r, "xplay.host", xl("Host the room on this device", "Crear la sala en este dispositivo"), &c.xroom_host,
                 ini("RoomHost"));
        r.back().title = xl("Host the room on this device", "Crear la sala en este dispositivo");
        r.back().help = xl("This app opens a room of the same kind as the emulators' (their Create Room) and joins it: players "
                           "of Eden, Citron, Sudachi, yuzu and of this app join it at this device's address. On the same "
                           "Wi-Fi that's all; from the internet, the room's UDP port must be forwarded to this device in the "
                           "router. The room closes with the app.",
                           "Esta app abre una sala del mismo tipo que las de los emuladores (su Crear sala) y entra en ella: "
                           "los jugadores de Eden, Citron, Sudachi, yuzu y de esta app entran con la dirección de este "
                           "dispositivo. En el mismo Wi-Fi no hace falta nada más; desde internet, hay que redirigir el puerto "
                           "UDP de la sala a este dispositivo en el router. La sala se cierra con la app.");
    }
    if (rooms && c.xroom_host) {
        number(r, "xplay.hostport", xl("Room port (UDP)", "Puerto de la sala (UDP)"), &c.xroom_host_port, 0, 65535, 1,
               ini("RoomHostPort"));
        r.back().title = xl("Room port (UDP)", "Puerto de la sala (UDP)");
        r.back().value = c.xroom_host_port ? std::to_string(c.xroom_host_port) : std::string("24872");
        r.back().help = xl("0: 24872, the rooms' usual port.", "0: 24872, el puerto habitual de las salas.");
        char ips[4][48];
        int n = xroomhost_addresses(ips, 4);
        std::string where;
        for (int i = 0; i < n; i++)
            where += (i ? ", " : "") + std::string(ips[i]) + ":" + std::to_string(c.xroom_host_port ? c.xroom_host_port : 24872);
        note(r, "xplay.where", fmt(xl("Others join this room at: %s", "Los demás entran a esta sala en: %s"),
                                   n ? where.c_str() : xl("(no network)", "(sin red)")));
    }
    if (rooms && !c.xroom_host) {
        crossplay_text(r, "xplay.room", xl("Room", "Sala"), c.xroom, sizeof c.xroom,
                       *c.xroom ? c.xroom : xl("Not set", "Sin elegir"), ini("Room"),
                       xl("The room's address, as its host gives it: a name or an IP, and :port if it isn't 24872. Rooms are "
                          "made with an emulator's Create Room, or its dedicated room program.",
                          "La dirección de la sala, como la da su anfitrión: un nombre o una IP, y :puerto si no es 24872. Las "
                          "salas se crean con Crear sala de un emulador, o con su programa de sala dedicada."));
        // the public rooms where this game is played (runtime/net/xlobby.c): picked, one becomes the Room above
        {
            static std::vector<XLobbyRoom> listed;
            static bool asked;  // (the list opens by itself when the answer comes after a tap)
            XLobbyRoom found[XLOBBY_MAX];
            int lstate = XL_NONE, n = xlobby_rooms(found, XLOBBY_MAX, &lstate);
            Row row;
            row.id = "xplay.lobby";
            row.title = xl("Public rooms", "Salas públicas");
            row.value = lstate == XL_BUSY ? xl("Searching...", "Buscando...")
                        : lstate == XL_FAILED ? xl("The list didn't come: try again", "La lista no llegó: prueba otra vez")
                        : lstate == XL_DONE ? fmt(xl("%d with this game", "%d con este juego"), n)
                                            : xl("Tap to see them", "Toca para verlas");
            row.help = xl("The public rooms of the yuzu family's lobby (" XLOBBY_HOST ", run by players, not by this project) "
                          "where this game is played: pick one to make it the Room. Those marked \"password\" need theirs.",
                          "Las salas públicas del lobby de la familia de yuzu (" XLOBBY_HOST ", lo mantienen jugadores, no "
                          "este proyecto) donde se juega este juego: elige una para que sea la Sala. Las marcadas "
                          "\"contraseña\" necesitan la suya.");
            Row copy = row;
            auto open_list = [copy]() {
                XLobbyRoom all[XLOBBY_MAX];
                int st = XL_NONE, k = xlobby_rooms(all, XLOBBY_MAX, &st);
                listed.assign(all, all + k);
                if (!k) return;
                std::vector<std::string> names;
                for (const XLobbyRoom &x : listed)
                    names.push_back(fmt("%s - %d/%d (%d %s)%s", x.name, x.players, x.slots, x.this_game,
                                        xl("in this game", "en este juego"), x.password ? xl(", password", ", contraseña") : ""));
                choices(copy, names, -1, [](int i) {
                    if (i < 0 || i >= (int)listed.size()) return;
                    snprintf(s.draft.xroom, sizeof s.draft.xroom, "%s:%d", listed[i].address, listed[i].port);
                });
            };
            if (asked && lstate == XL_DONE && n) {
                asked = false;
                open_list();
            }
            row.activate = [lstate, n, open_list]() {
                if (lstate == XL_DONE && n) {
                    open_list();
                    xlobby_fetch();  // (and fresher for the next time)
                    return;
                }
                online_then(XLOBBY_HOST, []() {
                    asked = true;
                    xlobby_fetch();
                });
            };
            r.push_back(std::move(row));
        }
    }
    if (rooms) {
        crossplay_text(r, "xplay.password", xl("Room password", "Contraseña de la sala"), c.xroom_password,
                       sizeof c.xroom_password, *c.xroom_password ? "****" : xl("None", "Ninguna"), ini("RoomPassword"),
                       c.xroom_host ? xl("The room's password, for those who join it (empty: none).",
                                         "La contraseña de la sala, para quienes entran (vacía: ninguna).")
                                    : xl("Only if the room has one.", "Solo si la sala tiene una."));
        crossplay_text(r, "xplay.nick", xl("Nickname", "Apodo"), c.xnick, sizeof c.xnick,
                       *c.xnick ? c.xnick : xl("Made up (Hunter-1234)", "Inventado (Hunter-1234)"), ini("Nickname"),
                       xl("Your name in the room: 4 to 20 letters, digits, spaces, '.', '_' or '-'. It must be free there.",
                          "Tu nombre en la sala: de 4 a 20 letras, números, espacios, '.', '_' o '-'. Tiene que estar libre allí."));
        xroom_status(&st);
    } else {
        crossplay_text(r, "xplay.ryuserver", xl("Ryujinx server", "Servidor de Ryujinx"), c.ryu_server, sizeof c.ryu_server,
                       *c.ryu_server ? c.ryu_server : xl("None (type one)", "Ninguno (escribe uno)"), ini("RyujinxServer"),
                       xl("The LDN server the Ryujinx players use (Ryujinx's Multiplayer settings show it): a name or an IP, "
                          "and :port if it isn't 30456. None is set: you choose. The rules of Ryujinx's official server say "
                          "it is meant for Ryujinx players only, and that other programs may get their IP address banned "
                          "there. A server of your own (the public ldn-server program) works for Ryujinx and this app alike. "
                          "Which server you join is your own decision and your own responsibility.",
                          "El servidor LDN que usan los jugadores de Ryujinx (lo muestra la configuración Multijugador de "
                          "Ryujinx): un nombre o una IP, y :puerto si no es 30456. No viene ninguno: lo eliges tú. Las reglas "
                          "del servidor oficial de Ryujinx dicen que es solo para jugadores de Ryujinx, y que otros programas "
                          "pueden recibir allí una prohibición de su dirección IP. Un servidor propio (el programa público "
                          "ldn-server) sirve igual para Ryujinx y para esta app. A qué servidor entras es decisión tuya y "
                          "responsabilidad tuya."));
        crossplay_text(r, "xplay.passphrase", xl("Passphrase", "Frase de acceso"), c.ryu_passphrase, sizeof c.ryu_passphrase,
                       *c.ryu_passphrase ? c.ryu_passphrase : xl("None (public)", "Ninguna (público)"),
                       ini("RyujinxPassphrase"),
                       xl("Ryujinx's private games: only players with the same passphrase see your hubs and you theirs. "
                          "It is \"Ryujinx-\" and 8 characters from 0-9 and a-f, as Ryujinx makes it. Empty: public.",
                          "Las partidas privadas de Ryujinx: solo los jugadores con la misma frase ven tus salas y tú las "
                          "suyas. Es \"Ryujinx-\" y 8 caracteres de 0-9 y a-f, como la crea Ryujinx. Vacía: público."));
        ryuldn_status(&st);
    }
    // the state of the room / server as saved (a change is used once saved)
    const Config &saved = s.saved;
    bool unsaved = c.crossplay != saved.crossplay || strcmp(c.xroom, saved.xroom) ||
                   strcmp(c.xroom_password, saved.xroom_password) || strcmp(c.xnick, saved.xnick) ||
                   strcmp(c.ryu_server, saved.ryu_server) || strcmp(c.ryu_passphrase, saved.ryu_passphrase) ||
                   c.xroom_host != saved.xroom_host || c.xroom_host_port != saved.xroom_host_port;
    std::string state;
    if (unsaved) state = xl("Save to use these settings", "Guarda para usar estos ajustes");
    else switch (st.state) {
    case XS_CONNECTING: state = xl("Connecting...", "Conectando..."); break;
    case XS_IN:
        state = st.members >= 0 ? fmt(xl("In %s: %d of %d", "En %s: %d de %d"), st.room, st.members, st.slots)
                                : fmt(xl("Connected to %s", "Conectado a %s"), st.room);
        break;
    case XS_FAILED: state = st.error; break;
    default: state = xl("Not connected (tap to connect)", "Sin conectar (toca para conectar)"); break;
    }
    Row row;
    row.id = "xplay.state";
    row.title = rooms ? xl("Room", "Sala") : xl("Server", "Servidor");
    row.title += xl(": state", ": estado");
    row.value = state;
    row.warn = st.state == XS_FAILED && !unsaved;
    row.help = xl("Connects to the room or server above (as saved) and shows what it answers. Creating or searching for "
                  "hubs in the game connects too.",
                  "Se conecta a la sala o al servidor de arriba (como están guardados) y muestra lo que responde. Crear o "
                  "buscar salas en el juego también conecta.");
    row.activate = [rooms]() {
        XplayLive x;
        config_live_crossplay(&x);
        std::string where = rooms ? x.room : (*x.ryu_server ? x.ryu_server : "Ryujinx");
        online_then(where.c_str(), [rooms]() {
            if (rooms) g_xroom.ready(0);
            else g_ryuldn.ready(0);
        });
    };
    r.push_back(std::move(row));
    if (st.other_version)
        note(r, "xplay.version",
             fmt(xl("%s plays another version of the game: only " XPLAY_GAME_VERSION " plays with this app.",
                    "%s juega otra versión del juego: solo la " XPLAY_GAME_VERSION " juega con esta app."),
                 st.other_detail));
    note(r, "xplay.note",
         xl("Everyone needs version " XPLAY_GAME_VERSION " of the game. While crossplay is on the game plays as the original: "
            "small monster sync, the monster HP settings and Village quests in the Hub stay off.",
            "Todos necesitan la versión " XPLAY_GAME_VERSION " del juego. Con el juego cruzado el juego funciona como el "
            "original: la sincronización de monstruos pequeños, los ajustes de vida de los monstruos y las misiones de la "
            "Aldea en la sala quedan apagados."));
}
void reset_crossplay() {
    Config f = config_defaults(), &c = s.draft;
    c.crossplay = f.crossplay, c.xroom_host = f.xroom_host, c.xroom_host_port = f.xroom_host_port;
    SDL_strlcpy(c.xroom, f.xroom, sizeof c.xroom);
    SDL_strlcpy(c.xroom_password, f.xroom_password, sizeof c.xroom_password);
    SDL_strlcpy(c.xnick, f.xnick, sizeof c.xnick);
    SDL_strlcpy(c.ryu_server, f.ryu_server, sizeof c.ryu_server);
    SDL_strlcpy(c.ryu_passphrase, f.ryu_passphrase, sizeof c.ryu_passphrase);
}
MENU_ENTRY("multiplayer/crossplay", 10, crossplay_rows, reset_crossplay);
// The hub server and key being edited: checked as the page shows them (once the notice about playing online was
// closed: settings_panel_online_ok) and on request (runtime/net/ldn.c); the value: the server's last known state, from
// the check or from the game's own searches and hubs
std::string g_hub_checked;  // (the server and key checked by themselves since the menu opened)
void hub_check(std::vector<Row> &rows) {
    int ms = -1, hubs = -1;
    std::string state;
    const int status = ldn_hub_status(s.draft.ldn_server, s.draft.ldn_key, &ms, &hubs);
    const std::string pair = std::string(s.draft.ldn_server) + "\n" + s.draft.ldn_key;
    if (status == HUB_UNKNOWN && g_hub_checked != pair && settings_panel_online_ok(nullptr)) {
        g_hub_checked = pair;
        ldn_hub_check(s.draft.ldn_server, s.draft.ldn_key);
    }
    switch (status) {
    case HUB_CHECKING: state = tr("Checking..."); break;
    case HUB_OFF: state = tr("Off"); break;
    case HUB_ONLINE:
        state = hubs >= 0 ? fmt("Online, %d ms, %d hub(s)", ms, hubs) : ms >= 0 ? fmt("Online, %d ms", ms) : tr("Online");
        break;
    case HUB_NOT_FOUND: state = tr("Not found"); break;
    case HUB_UNREACHABLE: state = tr("Unreachable"); break;
    case HUB_LOST: state = tr("Connection lost"); break;
    case HUB_NO_ANSWER: state = tr("No answer"); break;
    case HUB_BUSY: state = tr("Busy"); break;
    case HUB_VERSION: state = tr("Other version"); break;
    case HUB_REFUSED: state = tr("Refused"); break;
    default: state = tr("Not checked"); break;
    }
    Row r;
    r.id = "server.check";
    r.title = tr("Check hub server");
    r.help = tr("Asks the hub server above whether it answers, with the matchmaking key above: how long it takes, and how many hubs it lists.");
    r.value = state;
    r.activate = []() {
        char server[sizeof s.draft.ldn_server];
        ldn_server_name(s.draft.ldn_server, server, sizeof server);
        online_then(server, []() { ldn_hub_check(s.draft.ldn_server, s.draft.ldn_key); });
    };
    rows.push_back(std::move(r));
}
// The keybinds' rows (config.h BIND_*): what each is called
const char *const bind_titles[] = {"Move forward", "Move back", "Move left", "Move right", "Walk", "Camera up",
                                   "Camera down", "Camera left", "Camera right", "A", "B", "X", "Y", "L", "R", "ZL",
                                   "ZR", "Plus", "Minus", "D-pad up", "D-pad down", "D-pad left", "D-pad right",
                                   "Left stick click", "Right stick click", "Item left", "Item right",
                                   "Combined button 1", "Combined button 2", "Combined button 3", "Combined button 4",
                                   "Combined button 5", "Combined button 6"};
static_assert(std::size(bind_titles) == BINDS, "a title for each keybind");
// What else a key (or KEY_MOUSE + a mouse button) does: one of the recomp's own keys (keymap.h), a keybind other than
// skip, or (for a keybind's) the chat key; nullptr: nothing
const char *key_use(int code, int skip) {
    if (const char *use = code < KEY_MOUSE ? key_reserved(code) : nullptr)
        return tr(use);
    for (int i = 0; i < BINDS; i++)
        for (int k = 0; k < BIND_KEYS; k++)
            if (i != skip && s.draft.binds[i][k] == code)
                return tr(bind_titles[i]);
    if (skip >= 0 && code == (int)SDL_GetScancodeFromName(s.draft.chat_key))
        return tr("Chat key");
    return nullptr;
}
// Choosing a key: for a keybind (BIND_*, add: its second key) or the chat key (-1)
void capture(int bind, bool add) {
    s.capture_bind = bind;
    s.capture_add = add;
    captured_key = -1;
    push(View::KeyCapture, "capture.cancel");
}
// The key that opens a line of chat; red when something else already uses it
void chat_key_row(std::vector<Row> &rows) {
    Row r;
    r.id = "chat.key";
    r.title = tr("Chat key");
    keyed(r, ini("ChatKey"));
    SDL_Scancode key = SDL_GetScancodeFromName(s.draft.chat_key);
    r.value = key != SDL_SCANCODE_UNKNOWN ? s.draft.chat_key : tr("None");
    if (const char *use = key != SDL_SCANCODE_UNKNOWN ? key_use((int)key, -1) : nullptr) {
        r.value += std::string(" (") + tr("in use:") + " " + use + ")";
        r.warn = true;
    }
    r.activate = []() { capture(-1, false); };
    rows.push_back(std::move(r));
}
// A keybind's row: its keys (red where one does something else too); Confirm sets a key, adds a second one or clears them.
// what: its help, instead of what the Keybinds view says of it
Row bind_row(int i, const char *what = nullptr) {
    Row row;
    row.id = "bind." + std::to_string(i);
    row.title = tr(bind_titles[i]);
    bool modifier = false;
    for (int k = 0; k < BIND_KEYS; k++) {
        int code = s.draft.binds[i][k];
        if (!code)
            continue;
        modifier |= code >= SDL_SCANCODE_LCTRL && code <= SDL_SCANCODE_RGUI && code != SDL_SCANCODE_LSHIFT &&
                    code != SDL_SCANCODE_RSHIFT;  // (host_input.c is_tap_mod: Shift is held, as for running)
        row.value += (row.value.empty() ? "" : ", ") + std::string(config_key_name(code));
        if (const char *use = key_use(code, i)) {
            row.value += std::string(" (") + tr("in use:") + " " + use + ")";
            row.warn = true;
        }
    }
    if (row.value.empty())
        row.value = tr("None");
    bool stick = i <= BIND_WALK || (i >= BIND_CAM_UP && i <= BIND_CAM_RIGHT);  // (held; the rest press something)
    if (i >= BIND_CAM_UP && i <= BIND_CAM_RIGHT)
        row.help = tr("Turns the camera as the right stick does, all the way. In the game's menus it is the right stick.");
#ifndef __ANDROID__  // (host_input.c mouse_a_ok; a phone's keyboard and mouse as before)
    if (i == BIND_A)
        row.help = tr("A mouse button here presses A outside the game's menus and talks only with the weapon out: it attacks, and never talks, opens, gathers or picks up - a key does that (F by default).");
#endif
    if (i >= BIND_COMBO1) {  // (host_input.c: the buttons of [Touch] Combo<n>)
        const char *combo = s.draft.touch_combo[i - BIND_COMBO1];
        row.help = *combo ? fmt("Presses %s together while held: the buttons of combined button %d, chosen in Combined buttons.",
                                combo, i - BIND_COMBO1 + 1)
                          : fmt("Combined button %d has no buttons yet: choose them in Combined buttons.", i - BIND_COMBO1 + 1);
    }
    if (what)
        row.help = what;
    if (modifier && !stick)  // (host_input.c mod_spent)
        row.help += (row.help.empty() ? "" : "\n") +
                    std::string(tr("Ctrl, Alt and the Windows key press it when tapped on their own: with another key, as in Alt+Tab or Alt+Enter, they press nothing."));
    Row copy = row;
    row.menu = true;
    row.activate = [copy, i]() {
        bool one = s.draft.binds[i][0] && !s.draft.binds[i][1];
        std::vector<std::string> names = {tr("Set key")};
        if (one)
            names.push_back(tr("Add a second key"));
        names.push_back(tr("None"));
        choices(copy, names, -1, [i, one](int v) {
            if (v == (one ? 2 : 1))
                s.draft.binds[i][0] = s.draft.binds[i][1] = 0;
            else
                capture(i, v == 1);
        });
    };
    return row;
}
#ifdef __ANDROID__
// (S14) A keyboard and a mouse connected to the phone (host_input_keyboard_mouse): the PC's Keybinds and the mouse's
// speed, on Controls > Keyboard and mouse; none of it (nor the page's row) shows without both. The keys and the mouse work as they
// did either way: a click in the game captures the mouse for the camera, Esc lets it go. The MH4U port's the same rows
void keyboard_mouse_rows(std::vector<Row> &r) {
    if (!host_input_keyboard_mouse())
        return;
    action(r, "keybinds", tr("Keybinds"), []() { push(View::Keybinds, "bind.0"); });
    r.back().help = tr("The keys and mouse buttons for the game's buttons, for moving, the camera, the item bar and the combined buttons. A click in the game captures the mouse: it turns the camera until Esc lets it go. These rows show while a keyboard and a mouse are connected.");
    number(r, "mouse", tr("Mouse sensitivity"), &s.draft.mouse_sensitivity, lo("MouseSensitivity"), hi("MouseSensitivity"), .05f, ini("MouseSensitivity"));
    r.back().value = fmt("%.2fx", s.draft.mouse_sensitivity);
}
#endif
// The Keybinds submenu: a row per keybind, the chat key
void keybind_rows(std::vector<Row> &r) {
    for (int i = 0; i < BINDS; i++) {
        if (i == BIND_MOVE_UP)
            header(r, "bind.movement", tr("Movement"));
        if (i == BIND_CAM_UP)
            header(r, "bind.camera", tr("Camera"));
        if (i == BIND_A)
            header(r, "bind.buttons", tr("Buttons"));
        if (i == BIND_ITEM_LEFT)
            header(r, "bind.items", tr("Item bar"));
        if (i == BIND_COMBO1)
            header(r, "bind.combos", tr("Combined buttons"));
        r.push_back(bind_row(i));
    }
    header(r, "bind.other", tr("Chat"));
    chat_key_row(r);
    action(r, "bind.reset", tr("Reset keybinds"), []() {
        Config f = config_defaults();
        memcpy(s.draft.binds, f.binds, sizeof f.binds);
        SDL_strlcpy(s.draft.chat_key, f.chat_key, sizeof s.draft.chat_key);
    });
    action(r, "bind.back", tr("Back"), []() { pop(); });
}
// A page's entries, and the pages under it (a section's own page: all of its pages)
bool in_page(const char *page, const std::string &prefix) {
    size_t n = prefix.size();
    return !strncmp(page, prefix.c_str(), n) && (page[n] == 0 || page[n] == '/');
}
// Reset: every entry of the page (a section's: of each of its pages) puts its options back as they come, shown or not
void reset_section() {
    for (const MenuEntry &e : menu_entries())
        if (e.reset && in_page(e.page, s.reset_at))
            e.reset();
    pop();
}
// Suggested order: the mods that replace each other's files keep their places among the mods that are on, with the
// ones that change the most files first and the small tweaks last, so a tweak wins over an overhaul.
std::vector<ModEntry> suggested_mods() {
    std::vector<ModEntry> order = mods.draft;
    auto result = mods.scan;
    if (!result || !result->done)
        return order;
    std::vector<int> slots;
    std::vector<std::string> involved;
    for (int i = 0; i < (int)order.size(); ++i) {
        if (!order[i].on)
            continue;
        for (int k = 0; k < result->scan.nconflicts; ++k) {
            const ModConflict &c = result->scan.conflicts[k];
            if (!c.replaced)
                continue;
            const std::string &a = result->names[c.a], &b = result->names[c.b];
            int ia = mod_index(a), ib = mod_index(b);
            if (ia >= 0 && ib >= 0 && mods.draft[ia].on && mods.draft[ib].on && (order[i].name == a || order[i].name == b)) {
                slots.push_back(i);
                involved.push_back(order[i].name);
                break;
            }
        }
    }
    auto files = [&](const std::string &name) {
        auto at = std::find(result->names.begin(), result->names.end(), name);
        return at == result->names.end() ? 0 : result->scan.files[at - result->names.begin()];
    };
    std::stable_sort(involved.begin(), involved.end(),
                     [&](const std::string &a, const std::string &b) { return files(a) > files(b); });
    for (size_t k = 0; k < slots.size(); ++k)
        snprintf(order[slots[k]].name, sizeof order[slots[k]].name, "%s", involved[k].c_str());
    return order;
}
// One row per pair of mods that are on and change the same file or archive entry; selecting it picks the one used
void conflict_rows(std::vector<Row> &r) {
    auto result = mods.scan;
    if (!result || !result->done)
        return;
    for (int k = 0; k < result->scan.nconflicts; ++k) {
        const ModConflict &c = result->scan.conflicts[k];
        if (!c.replaced)  // (archives whose changes are combined are not a problem)
            continue;
        int ia = mod_index(result->names[c.a]), ib = mod_index(result->names[c.b]);
        if (ia < 0 || ib < 0 || !mods.draft[ia].on || !mods.draft[ib].on)
            continue;
        if (ia > ib)
            std::swap(ia, ib);
        const char *first = mods.draft[ia].name, *second = mods.draft[ib].name;
        std::string text = fmt("%s and %s both change %d file(s); %s is used", first, second, c.replaced, second);
        std::string a = first, b = second;
        action(r, "mods.conflict." + std::to_string(k), text, []() {});
        {  // select it to choose which of the two is used: that one moves below the other
            Row &row = r.back();
            Row copy = row;
            copy.title = tr("Which mod is used?");
            row.menu = true;
            row.activate = [copy, a, b]() {
                choices(copy, {fmt("Use %s", a.c_str()), fmt("Use %s", b.c_str())}, 1, [a, b](int v) {
                    int ia = mod_index(a), ib = mod_index(b), win = v ? ib : ia, lose = v ? ia : ib;
                    if (ia < 0 || ib < 0 || win > lose)
                        return;
                    ModEntry moved = mods.draft[win];
                    mods.draft.erase(mods.draft.begin() + win);
                    mods.draft.insert(mods.draft.begin() + lose, moved);  // (the loser is now one place earlier)
                    s.saved_notice = false;
                });
            };
        }
    }
}
#ifndef __ANDROID__
// A desktop's Cheats tab: the cheat files - what the cheats folders hold, and what the game loaded from them - each one
// with its cheats under its name and a Remove, as Android's import screen lists them; one added since the start has its
// cheats read at the next one
struct CheatFile {
    std::string name;    // on disk (UTF-8; "" once it is gone)
    std::string loaded;  // the game's name for it (cheats_file; "": not loaded)
};
std::vector<CheatFile> cheat_files;
std::string utf8(const char *native) {
    char out[600];
    return plat_path_to_utf8(native, out, sizeof out) ? out : native;
}
void load_cheat_files() {
    cheat_files.clear();
    std::vector<std::array<char, 256>> disk(256);
    int n = pc_cheat_files(reinterpret_cast<char(*)[256]>(disk.data()), (int)disk.size());
    std::vector<bool> used(n, false);
    for (int i = 0; i < cheats_count(); ++i) {  // (the loaded ones first, in the order the game read them)
        std::string loaded = cheats_file(i);
        bool known = cheats_dropped(i);
        for (const auto &f : cheat_files)
            known |= f.loaded == loaded;
        if (known)
            continue;
        CheatFile file{"", loaded};
        std::string name = utf8(loaded.c_str());
        for (int k = 0; k < n && file.name.empty(); ++k)  // (the game keeps 63 bytes of a longer name)
            if (!used[k] && (name == disk[k].data() || (loaded.size() == 63 && !strncmp(disk[k].data(), name.c_str(), name.size()))))
                file.name = disk[k].data(), used[k] = true;
        cheat_files.push_back(file);
    }
    for (int k = 0; k < n; ++k)
        if (!used[k])
            cheat_files.push_back({disk[k].data(), ""});
}
// The mods folder read again (a mod added): the list as it is now, the tab's unsaved order and switches kept for the
// mods still there, a new one joining at the end as it loads
void refresh_mods() {
    std::vector<ModEntry> now(MODS_MAX);
    now.resize(mods_installed(now.data(), MODS_MAX));
    if (mods_dirty()) {
        std::vector<ModEntry> next;
        for (const auto &m : mods.draft)
            for (const auto &k : now)
                if (!strcmp(k.name, m.name)) {
                    next.push_back(m);
                    break;
                }
        for (const auto &k : now) {
            bool known = false;
            for (const auto &m : next)
                known |= !strcmp(m.name, k.name);
            if (!known)
                next.push_back(k);
        }
        mods.draft = next;
    } else
        mods.draft = now;
    mods.saved = now;
    mods.scan.reset();
}
// What View::Remove asks about: a mod (mods_installed's name), or a cheat file (its name on disk and the game's)
struct Removal {
    bool mod = false;
    std::string name, loaded, shown;
    bool link = false;  // (a mod linked in from elsewhere: the link alone is deleted)
} removal;
void ask_remove(bool mod, const std::string &name, const std::string &loaded, const std::string &shown) {
    removal = {mod, name, loaded, shown, mod && pc_mod_is_link(name.c_str())};
    push(View::Remove, "dialog.cancel");
}
std::string removal_question() {
    const char *shown = removal.shown.c_str();
    bool used = removal.mod && mods_loaded(removal.name.c_str());
    if (removal.link)
        return fmt(used ? "Remove the mod %s? It is a link, and the game is using it: the link is deleted when the game "
                          "restarts, and the folder it points to is kept."
                        : "Remove the mod %s? It is a link: only the link is deleted from the mods folder, and the folder it "
                          "points to is kept.",
                   shown);
    if (removal.mod)
        return fmt(used ? "Remove the mod %s? The game is using it: its folder is deleted when the game restarts."
                        : "Remove the mod %s? Its folder is deleted from the mods folder.",
                   shown);
    return fmt(removal.loaded.empty() ? "Remove the cheat file %s? It is deleted from the cheats folder."
                                      : "Remove the cheat file %s? It is deleted from the cheats folder, and its cheats stop now.",
               shown);
}
// Remove, in View::Remove (runtime/pc_actions.c): the tabs drop it; a mod the game is using asks to restart
void remove_confirmed() {
    char error[700];
    if (removal.mod) {
        std::string name = removal.name;
        int done = pc_remove_mod(name.c_str(), error, sizeof error);
        if (!done) {
            s.error = error;
            return;
        }
        auto drop = [&name](std::vector<ModEntry> &list) {
            list.erase(std::remove_if(list.begin(), list.end(), [&name](const ModEntry &m) { return name == m.name; }),
                       list.end());
        };
        drop(mods.draft);
        drop(mods.saved);
        if (done == 1)
            drop(mods.boot);  // (not loaded: no restart waits for it)
        mods.scan.reset();
        pop();
        focus("mods.add");
        if (done == 2)  // (the game still has it: the restart takes it out)
            push(View::Restart, "dialog.cancel");
        return;
    }
    if (!pc_remove_cheat_file(removal.name.c_str(), removal.loaded.c_str(), error, sizeof error)) {
        s.error = error;
        return;
    }
    for (int i = 0; i < (int)cheat_tab.draft.size(); ++i)
        if (cheats_dropped(i))
            cheat_tab.draft[i] = cheat_tab.saved[i] = 0;
    load_cheat_files();
    pop();
    focus("cheats.add");
}
#endif
// Cheat files the game left out whole (runtime/cheats.c): those made for another version of the game, by their build id
bool cheat_file_left_out(const std::string &file) {
    const char *f = nullptr;
    for (int i = 0, n = cheats_left_out(0, nullptr, nullptr); i < n; ++i)
        if (cheats_left_out(i, &f, nullptr) && file == f)
            return true;
    return false;
}
void cheat_left_rows_one(std::vector<Row> &r, const std::string &file) {
    const char *f = "", *id = "";
    for (int i = 0, n = cheats_left_out(0, nullptr, nullptr); i < n; ++i)
        if (cheats_left_out(i, &f, &id) && file == f) {
            action(r, "cheatleft." + file, tr("For another version of the game: not loaded"),
                   []() {}, false);
            r.back().value = "!";
            r.back().help = fmt("These cheats are for another version of the game (build id %s). The port plays version 1.4.0, build id FB08F1D20FD1204F: their addresses would change other things there, so they are left out. Use the file named FB08F1D20FD1204F.txt of the same list.",
                                id);
            return;
        }
}
void cheat_left_rows(std::vector<Row> &r) {
    for (int i = 0, n = cheats_left_out(0, nullptr, nullptr); i < n; ++i) {
        const char *file = "", *id = "";
        cheats_left_out(i, &file, &id);
        action(r, std::string("cheatleft.") + file, fmt("%s: not loaded", file), []() {}, false);
        r.back().value = "!";
        r.back().help = fmt("These cheats are for another version of the game (build id %s). The port plays version 1.4.0, build id FB08F1D20FD1204F: their addresses would change other things there, so they are left out. Use the file named FB08F1D20FD1204F.txt of the same list.",
                            id);
    }
}
// A cheat's row: On / Off, or Always on (a master code)
Row cheat_row(int i) {
    Row row;
    row.id = "cheat." + std::to_string(i);
    row.title = cheats_name(i);
    row.help = cheats_file(i);
    if (cheats_master(i)) {
        row.value = tr("Always on");
        row.enabled = false;
    } else {
        row.value = tr(cheat_tab.draft[i] ? "On" : "Off");
        row.toggle = cheat_tab.draft[i] ? 1 : 0;
        row.adjust = [i](int d) {
            cheat_tab.draft[i] = d > 0;
            s.saved_notice = false;
        };
        row.activate = [i]() {
            cheat_tab.draft[i] = !cheat_tab.draft[i];
            s.saved_notice = false;
        };
    }
    return row;
}
void cheat_rows(std::vector<Row> &r) {
#ifdef __ANDROID__  // (the app's cheats folder is in Android/data, out of a file manager's reach: copied in by ImportActivity)
    action(r, "cheats.add", tr("Add cheats"), []() { ui_request_import(0); });
    r.back().help = tr("Copies cheat .txt files (Atmosphere's format, for 1.4.0: in a list's folder, the file named FB08F1D20FD1204F.txt) from your phone's storage. You can also put them yourself in the cheats folder inside your game folder. The game restarts to read them.");
    for (int i = 0; i < (int)cheat_tab.draft.size(); ++i)
        r.push_back(cheat_row(i));
    cheat_left_rows(r);
#else  // (a desktop: the system's file dialog, runtime/pc_actions.c; each file under its name, with its Remove)
    action(r, "cheats.add", tr("Add cheats"), []() { ui_request_import(0); });
    r.back().help = tr("Copies cheat .txt files (Atmosphere's format, for 1.4.0) into the cheats folder inside your game folder, where you can also put them yourself. They start off: turn them on here. The game restarts to read them.");
    if (cheat_files.empty())
        action(r, "cheats.none", tr("No cheats found in the cheats folder"), []() {});
    for (const auto &f : cheat_files) {
        std::string shown = f.name.empty() ? utf8(f.loaded.c_str()) : f.name;
        header(r, "cheatfile." + shown, shown);
        for (int i = 0; i < (int)cheat_tab.draft.size(); ++i)
            if (!f.loaded.empty() && f.loaded == cheats_file(i) && !cheats_dropped(i))
                r.push_back(cheat_row(i));
        if (f.loaded.empty() && cheat_file_left_out(f.name))
            cheat_left_rows_one(r, f.name);
        else if (f.loaded.empty())
            action(r, "cheatnew." + shown, tr("Its cheats show up after a restart"), []() {}, false);
        if (f.loaded.find('/') != std::string::npos)  // (a mod's cheats/ file: it goes with its mod)
            continue;
        action(r, "cheatrm." + shown, fmt("Remove %s", shown.c_str()), [f, shown]() { ask_remove(false, f.name, f.loaded, shown); });
        r.back().help = tr(f.loaded.empty() ? "Deletes this file from the cheats folder."
                                            : "Deletes this file from the cheats folder. Its cheats stop at once, no restart needed.");
    }
#endif
}
// Forge's menu: the settings of the Forge plugins the mods bring (Damage Numbers' size...), which a PC opens with the
// Insert key. Shown when a plugin started; it opens once this menu has closed (overlay.cpp overlay_open_forge), bigger
// and scrolled by dragging when opened by touch
void forge_menu_row(std::vector<Row> &r) {
    const char *names[16];
    if (forge_plugin_titles(names, 16) <= 0 && !getenv("MHGU_FORGE_MENU"))  // (MHGU_FORGE_MENU=1: without plugins, a test)
        return;
    action(r, "mods.forge", tr("Forge menu (plugins)"), []() {
        overlay_open_forge();
        request_back.store(true);
    });
    r.back().help = tr("Opens Forge's menu, where the Forge plugins of your mods keep their settings (under Plugin UI). Drag a finger to scroll it; its x or the Back key closes it. On a PC the Insert key opens it too. Plugins are other people's work: you use them at your own risk.");
}
void mods_rows(std::vector<Row> &r) {
    if (!mods.scan)
        start_scan();
    auto result = mods.scan;  // (the scan thread fills it; `done` says when)
#ifdef __ANDROID__  // (as the cheats: copied into the app's folders by ImportActivity)
    action(r, "mods.add", tr("Add a mod"), []() { ui_request_import(1); });
    r.back().help = tr("Copies a mod's folder (with romfs or exefs in it) or its .zip from your phone's storage. You can also put it yourself in the mods folder inside your game folder. The game restarts to load it.");
    // (DLC: the game takes them only in its Download menu, which needs its online services, and stops with an error
    // without them, even with a connection said to be there. The rest is in place - services/dlc.c, ImportActivity -
    // and the row shows in a test run with MHGU_DLC=1)
    if (getenv("MHGU_DLC"))
        action(r, "dlc.add", tr("Add DLC"), []() { ui_request_import(2); });
    if (getenv("MHGU_DLC"))
        r.back().help = tr("Your own DLC of the game: each one's folder holds a DLC.dlcp. You can also put them yourself in the dlc folder inside your game folder. Then, in the game's main menu: Download. Experimental.");
#else  // (a desktop: the system's dialog for the mod's folder or its .zip, runtime/pc_actions.c)
    action(r, "mods.add", tr("Add a mod"), []() {});
    {
        Row &row = r.back();
        row.help = tr("Copies a mod's folder (with romfs or exefs in it), or unpacks its .zip, into the mods folder inside your game folder, where you can also put it yourself. The game restarts to load it.");
        Row copy = row;
        row.menu = true;
        row.activate = [copy]() {
            choices(copy, {tr("The mod's folder"), tr("The mod's .zip")}, -1, [](int v) {
                pc_mod_dialog(v == 1);
                ui_request_import(1);
            });
        };
    }
    if (mods.draft.empty())
        action(r, "mods.none", tr("No mods found in the mods folder"), []() {});
#endif
    for (int i = 0; i < (int)mods.draft.size(); ++i) {
        std::string name = mods.draft[i].name;
        bool on = mods.draft[i].on, clash = false;
        if (on && result->done)
            for (int k = 0; k < result->scan.nconflicts && !clash; ++k) {
                const ModConflict &c = result->scan.conflicts[k];
                if (!c.replaced || (result->names[c.a] != name && result->names[c.b] != name))
                    continue;
                int other = mod_index(result->names[result->names[c.a] == name ? c.b : c.a]);
                clash = other >= 0 && mods.draft[other].on;
            }
        Row row;
        row.id = "mod." + name;
        row.title = name;
        row.value = std::string(tr(on ? "On" : "Off")) + (clash ? " !" : "");
        row.cold = true;
        if (const char *part = mods_refused_part(name.c_str())) {  // (runtime/loader.c replace_from_mod)
            row.value += clash ? "" : " !";
            row.help = fmt("Its %s is not laid out as the game's 1.4.0 (another version, or rebuilt), so the port can't use it: the rest of the mod loads. The log says more.",
                           part);
        }
        auto set_on = [name](bool v) {
            int at = mod_index(name);
            if (at >= 0 && mods.draft[at].on != v) {
                mods.draft[at].on = v;
                s.saved_notice = false;
            }
        };
        row.adjust = [set_on](int d) { set_on(d > 0); };
        Row copy = row;
        row.menu = true;
        row.activate = [copy, name, on, set_on]() {
            auto move = [name](int d) {
                int at = mod_index(name), to = at + d;
                if (at >= 0 && to >= 0 && to < (int)mods.draft.size()) {
                    std::swap(mods.draft[at], mods.draft[to]);
                    s.saved_notice = false;
                }
            };
            std::vector<std::string> names = {tr(on ? "Turn off" : "Turn on"), tr("Move up"), tr("Move down")};
#ifndef __ANDROID__  // (a desktop removes it here, as Android's import screen does)
            names.push_back(tr("Remove"));
#endif
            choices(copy, names, -1, [set_on, move, on, name](int v) {
                if (v == 0)
                    set_on(!on);
                else if (v < 3)
                    move(v == 1 ? -1 : 1);
#ifndef __ANDROID__
                else
                    ask_remove(true, name, "", utf8(name.c_str()));
#endif
            });
        };
        r.push_back(std::move(row));
    }
    if (!result->done) {
        action(r, "mods.scanning", tr("Checking for conflicts..."), []() {});
    } else {
        std::vector<Row> found;
        conflict_rows(found);
        if (found.empty())
            action(r, "mods.clear", tr("No conflicts found"), []() {});
        else {
            action(r, "mods.conflicts", fmt("Mods change the same files (%d): select to review", (int)found.size()),
                   []() { push(View::Conflicts, ""); });
            r.back().value = "!";
        }
    }
    auto order = suggested_mods();
    action(
        r, "mods.suggest", tr("Apply suggested order"),
        [order]() {
            mods.draft = order;
            s.saved_notice = false;
        },
        !same_mods(order, mods.draft));
    action(r, "mods.rescan", tr("Rescan mods"), []() {
        std::vector<ModEntry> now(MODS_MAX);
        int n = mods_installed(now.data(), MODS_MAX);
        // new folders join the end (on), gone ones leave; the order and the switches of the rest stay
        std::vector<ModEntry> next;
        for (const auto &m : mods.draft)
            for (int i = 0; i < n; ++i)
                if (!strcmp(now[i].name, m.name)) {
                    next.push_back(m);
                    break;
                }
        mods.draft = next;
        for (int i = 0; i < n; ++i)
            if (mod_index(now[i].name) < 0) {
                now[i].on = true;  // (as at start: a mod added later loads)
                mods.draft.push_back(now[i]);
            }
        mods.scan.reset();
    });
}
// The 3D resolution (RenderScale, Auto: the 3D picture in percent of the screen's; with FSR its quality sets the 3D size). A
// phone's is in Graphics & Audio by Low-end mode and the frame rate, as in the MH4U port; a desktop's in Display, by its
// Render resolution. Any percent from RENDER_SCALE_MIN to 100: left / right one percent, a tap the usual ones (gu-native
// #204, 4u-native #51: 20 %, 55-60 %); a phone's list also has an exact size (RenderResolution, its Width and Height rows
// under this one; a desktop has them as Render resolution Custom). A percent not among them, as the file may have it, shows
// as it is
void scale_row(std::vector<Row> &r) {
    Config &c = s.draft;
    if (c.fsr && !c.low_end)
        return;
#ifndef __ANDROID__
    if (c.render_w)
        return;
#endif
    static const int presets[] = {100, 90, 80, 75, 66, 60, 55, 50, 40, 33, 25, 20};
    const int n = (int)std::size(presets);
    // (the screen held landscape: the size a percent comes to, about, before the picture's shape; config.c has the exact one)
    const int sw = std::max(g_config.width, g_config.height), sh = std::min(g_config.width, g_config.height);
    Row row;
    row.id = "render.scale";
    row.title = tr("3D resolution");
    keyed(row, ini("RenderScale"));
    if (c.render_w) {  // (a phone's exact size)
        row.value = std::string(en_es("Exact", "Exacta")) + " (" + std::to_string(c.render_w) + "x" + std::to_string(c.render_h) + ")";
    } else {
        row.value = std::to_string(c.render_scale) + "%";
        if (sw > 0 && c.render_scale < 100)
            row.value += " (" + std::to_string(sw * c.render_scale / 100 & ~1) + "x" + std::to_string(sh * c.render_scale / 100 & ~1) + ")";
        row.number = true;
        row.adjust = [](int d) { s.draft.render_scale = std::clamp(s.draft.render_scale + d, RENDER_SCALE_MIN, 100); };
    }
    Row copy = row;
    row.menu = true;
    row.activate = [copy, n, sw, sh]() {
        std::vector<std::string> names;
        int now = -1;
        for (int i = 0; i < n; i++) {
            names.push_back(std::to_string(presets[i]) + "%");
            if (!s.draft.render_w && presets[i] == s.draft.render_scale) now = i;
        }
#ifdef __ANDROID__
        names.push_back(en_es("Exact size", "Tamaño exacto"));
        if (s.draft.render_w) now = n;
#endif
        choices(copy, names, now, [n, sw, sh](int v) {
            Config &d = s.draft;
            if (v < n) {
                d.render_scale = presets[v], d.render_w = d.render_h = 0;
            } else if (!d.render_w) {  // (an exact size: from the percent's size, then its own rows)
                d.render_w = std::max(320, sw * d.render_scale / 100 & ~1);
                d.render_h = std::max(180, sh * d.render_scale / 100 & ~1);
            }
        });
        if (now < 0) {  // (another percent: the list starts at the one below it)
            int below = n - 1;
            for (int i = 0; i < n; i++)
                if (presets[i] <= s.draft.render_scale) { below = i; break; }
            focus("choice." + std::to_string(below));
        }
    };
#ifdef __ANDROID__  // (S22: why the HUD softens with it; config.c, fsr.c: Low-end mode's and FSR's HUD at the screen's size)
    row.help = en_es(
        "The size of the 3D picture, in percent of the screen's: left and right change it one percent at a time, a tap offers "
        "the usual ones and an exact size. Lower is faster and softer. The HUD and the text are drawn at this size too, so "
        "they soften with it, unless Low-end mode or FSR is on: drawing them at the screen's full size over a smaller 3D "
        "picture costs a weak phone's GPU more than it gains.",
        "El tamaño de la imagen 3D, en porcentaje del de la pantalla: izquierda y derecha lo cambian de a un punto, un toque "
        "ofrece los habituales y un tamaño exacto. Más bajo es más rápido y más suave. El HUD y los textos se dibujan a este "
        "tamaño también, así que se suavizan con él, salvo con el modo gama baja o FSR: dibujarlos al tamaño completo de la "
        "pantalla sobre una imagen 3D más chica le cuesta a la GPU de un teléfono débil más de lo que gana.");
#else  // (config.c: below 100, the HUD at the screen's size over the smaller picture, fsr.c's plain scaling; the menus'
       // models drawn after its start get none of the anti-aliasing, as with FSR: nvn/vulkan/exec.c models_aa)
    row.help = en_es(
        "The size of the 3D picture, in percent of the screen's: left and right change it one percent at a time, a click "
        "offers the usual ones (Render resolution Custom sets an exact size). Lower is faster and softer; the HUD and the "
        "text stay sharp at full resolution. On a weak GPU this is what speeds the game up the most. Below 100%, the 3D "
        "models in the menus get no anti-aliasing.",
        "El tamaño de la imagen 3D, en porcentaje del de la pantalla: izquierda y derecha lo cambian de a un punto, un clic "
        "ofrece los habituales (Resolución de renderizado Personalizada fija un tamaño exacto). Más bajo es más rápido y más "
        "suave; el HUD y los textos siguen nítidos a resolución completa. En una GPU débil es lo que más acelera el juego. "
        "Por debajo de 100%, los modelos 3D de los menús no tienen antialiasing.");
#endif
    r.push_back(std::move(row));
#ifdef __ANDROID__
    if (c.render_w) {  // (RenderResolution: config.c fits it to the picture's shape, at most the screen's)
        number(r, "render.width", en_es("Width", "Ancho"), &c.render_w, 320, std::max(320, sw), 16, ini("RenderResolution"));
        number(r, "render.height", en_es("Height", "Alto"), &c.render_h, 180, std::max(180, sh), 8, ini("RenderResolution"));
    }
#endif
}
// S46 (group build): the game code made on the phone (android/.../BuilderActivity.java), Android only. Its row, its help
// and its words (settings_locale.h): MENU.md puts it in System, Game code (system/code, 10).
void game_code_rows(std::vector<Row>& r) {
#ifdef __ANDROID__
    action(r, "game.build", tr("Build the game code"), []() { ui_request_builder(); });
    r.back().help = tr("Makes the game code (libmhgugame.so) on this phone, from your own exefs in the game folder. No PC needed. The first time it downloads the tools (about 100 MB). It takes 10 minutes to about 2 hours depending on the phone and goes on in the background; the game starts again to use it.");
#else
    (void)r;
#endif
}
// ...and its credit, among Credits & Licenses' notes (about).
void builder_credit_rows(std::vector<Row>& r) {
#ifdef __ANDROID__
    note(r, "about.builder", tr("Building the game code on the phone was Klark231's idea (github.com/klark231/mh4u-builder)."));
#else
    (void)r;
#endif
}
MENU_ENTRY("system/code", 10, game_code_rows);  // (Android: a desktop's game code is made with the PC's tools)
// Clear shader cache (runtime/cache_clear.c, 1.0's S30): a tap leaves the mark the next start deletes the shader cache
// by, before anything reads it; another tap takes it back. Nothing to Save: the mark is the setting. The size is read
// again at most every 5 s (the SPIR-V folder holds thousands of files)
void cache_clear_row(std::vector<Row> &r) {
    static uint64_t bytes;
    static Uint64 read_at;
    const Uint64 now = SDL_GetTicks();
    if (!read_at || now - read_at > 5000) bytes = cache_clear_bytes(), read_at = now;
    action(r, "cache.clear", en_es("Clear shader cache", "Borrar la caché de shaders"), []() {
        cache_clear_request(!cache_clear_pending());
        read_at = 0;
    });
    char mb[32];
    snprintf(mb, sizeof mb, "%.0f MB", bytes / 1048576.0);
    r.back().value = cache_clear_pending() ? en_es("At the next start", "Al próximo inicio") : mb;
    r.back().help = en_es(
        "Deletes the shaders the game built and kept (its program, pipeline and SPIR-V caches and the GPU driver's own) at "
        "the next start, before the game reads them: for a picture that shows something wrong after a GPU driver update "
        "or a crash. That start builds every shader again: it takes longer, and the first areas may stutter or show models "
        "late until they are built. A second tap, before the game starts again, keeps the cache.",
        "Borra los shaders que el juego armó y guardó (sus cachés de programas, de pipelines y de SPIR-V, y la del driver "
        "de la GPU) en el próximo inicio, antes de que el juego los lea: para una imagen que muestra algo mal después de "
        "actualizar el driver de la GPU o de un cierre. Ese inicio vuelve a armar todos los shaders: tarda más, y las "
        "primeras zonas pueden tironear o mostrar modelos tarde hasta que estén armados. Un segundo toque, antes de que "
        "el juego vuelva a empezar, conserva la caché.");
}
// [Performance] Effects (runtime/hle/effects.c): the game's particle effects, drawn or not, at once
void effects_row(std::vector<Row> &r) {
    Config &c = s.draft;
    add_bool(r, "effects", en_es("Effects", "Efectos"), &c.effects, ini("Effects"));
    r.back().help = en_es(
        "The game's particle effects: hits, sparks, fire, breath, dust, rain, the glow of the Hunter Arts. Off: faster where "
        "there are many of them on a weak phone or GPU, but the effects that warn of a monster's attack go too. It applies at once.",
        "Los efectos de partículas del juego: golpes, chispas, fuego, alientos, polvo, lluvia, el brillo de las Artes de caza. "
        "Apagados: más rápido donde hay muchos, en un teléfono o una GPU débil, pero también desaparecen los efectos que avisan "
        "del ataque de un monstruo. Se aplica al momento.");
}
void reset_effects() { s.draft.effects = config_defaults().effects; }
// The gfx group's places (MENU.md 3.2): Effects on Graphics & Audio, Clear shader cache on Advanced (an action: the mark
// is the setting, nothing to put back); the 3D resolution (scale_row) stays where it was, at 30
MENU_ENTRY("graphics", 55, effects_row, reset_effects);
MENU_ENTRY("graphics/advanced", 50, cache_clear_row);
// S43, Alfonso's idea: "Send to the Item Box" on the quest's rewards sends every reward at once (runtime/hle/rewards.c;
// MH4U for Android has the same option, name and texts). Off: one reward an A, as the game does.
void rewards_rows(std::vector<Row> &r) {
    header(r, "rewards.header", en_es("After a quest", "Al terminar una misión"));
    add_bool(r, "rewards.all", en_es("Send all to the box", "Enviar todo a la caja"),
             &s.draft.send_all_rewards, ini("SendAllRewards"));
    r.back().help = en_es("At the end of a quest, the game's Send to the Item Box sends every reward at once, as in the newer "
                          "games. What doesn't fit in the box stays in the list. Off: one at a time, as the game does it. "
                          "Alfonso's idea.",
                          "Al terminar una misión, la opción del juego de enviar a la caja de objetos manda todas las "
                          "recompensas de una vez, como en los juegos más nuevos. Lo que no entra en la caja queda en la "
                          "lista. Apagado: de a una, como lo hace el juego. Idea de Alfonso.");
}

// S37: the player's own DLC and event quests (Android: android/.../ExtraImportActivity.java, a save with downloads as the
// bonus content; MH4U for Android has the same row and screen)
void extra_import_row(std::vector<Row> &r) {
    action(r, "save.extra", en_es("Import DLC and event quests", "Importar DLC y misiones de evento"),
           []() { ui_request_activity("showExtraImport"); });
    r.back().help = en_es("Brings the event quests and downloads you already have, inside a save from an emulator or a "
                          "backup of your console. Your hunters stay. The app includes none: you bring your own, at your "
                          "own risk.",
                          "Trae las misiones de evento y descargas que ya tienes, dentro de una partida de un emulador o de "
                          "una copia de tu consola. Tus cazadores quedan. La app no incluye ninguna: las traes tú, bajo tu "
                          "responsabilidad.");
}

// S56: a shortcut on the phone's home screen with an image the player picks (android/.../ShortcutActivity.java; the
// same row and screen in MH4U for Android)
void shortcut_row(std::vector<Row> &r) {
    action(r, "app.shortcut", en_es("Home screen shortcut", "Acceso directo en el inicio"),
           []() { ui_request_activity("showShortcut"); });
    r.back().help = en_es("Puts a shortcut to the game on your home screen, with a picture you choose from your phone and "
                          "the name you want. The app's own icon stays as it is.",
                          "Pone un acceso directo al juego en la pantalla de inicio, con una imagen que elijas de tu teléfono "
                          "y el nombre que quieras. El ícono propio de la app queda como está.");
}
void reset_rewards() { s.draft.send_all_rewards = config_defaults().send_all_rewards; }
// The qol group's places (MENU.md 3.3, 3.5, 3.6): Send all under After a quest on Gameplay; the import on DLC and event
// quests and the shortcut on System (Android: a desktop's has no such screens, its README says where the files go)
MENU_ENTRY("gameplay", 70, rewards_rows, reset_rewards);
#ifdef __ANDROID__
MENU_ENTRY("mods/dlc", 10, extra_import_row);
MENU_ENTRY("system", 75, shortcut_row);
#endif
// ---------------------------------------------------------------- the pages and their entries (MENU.md)
// Each option of the menu, as an entry on its page; the pages one level down, each with its row's place on the page
// above. Other options join with a MENU_ENTRY of their own (MENU.md: the places kept for 1.0's)
MENU_PAGE("controls/profiles", "Control profiles", "controls", 20);  // (1.0, the layout group's: S12, S09)
MENU_PAGE("controls/touch", "Touch controls", "controls", 80, touch_rows);
MENU_PAGE("controls/pad", "Controller", "controls", 90);
MENU_PAGE("controls/keys", "Keyboard and mouse", "controls", 100);
MENU_PAGE("graphics/picture", "Picture and sound", "graphics", 80);
MENU_PAGE("graphics/screen", "Screen and HUD", "graphics", 90);
MENU_PAGE("graphics/advanced", "Advanced", "graphics", 100);
MENU_PAGE("gameplay/health", "Monster health", "gameplay", 50);
MENU_PAGE("gameplay/comforts", "Comforts", "gameplay", 90);
MENU_PAGE("multiplayer/chat", "Chat", "multiplayer", 40);  // (1.0: the chat group's, S32)
MENU_PAGE("multiplayer/friends", "Friends", "multiplayer", 50);
// (1.0: the cross group's, S36; its row's value says what online play goes through now)
bool no_crossplay() { return !s.draft.crossplay; }  // (crossplay on: the port's own hubs' rows and the LAN's go)
MENU_PAGE("multiplayer/crossplay", "Play with emulators", "multiplayer", 60, {}, [](Row &row) {
    row.value = s.draft.crossplay == XPLAY_ROOMS ? xl("Emulator rooms", "Salas de emuladores")
                : s.draft.crossplay            ? "Ryujinx"
                                               : xl("Off", "No");
});
MENU_PAGE("multiplayer/lan", "Local network", "multiplayer", 70, no_crossplay);
MENU_PAGE("multiplayer/hub", "In the hub", "multiplayer", 80);
MENU_PAGE("multiplayer/guide", "How to play online", "multiplayer", 90);  // (1.0: S34)
MENU_PAGE("multiplayer/discord", "Discord", "multiplayer", 100);
MENU_PAGE("mods/list", "Mods", "mods", 10, {}, [](Row &r) {
    int on = 0;
    for (const auto &m : mods.draft)
        on += m.on;
    r.value = mods.draft.empty() ? std::string(tr("No mods")) : fmt("%d of %d on", on, (int)mods.draft.size());
    r.help = tr("Mods load from top to bottom: a later mod wins. Select a conflict to choose which mod is used. Press Save, then restart.");
});
MENU_PAGE("mods/cheats", "Cheats", "mods", 20, {}, [](Row &r) {
    int on = 0;
    for (char c : cheat_tab.draft)
        on += c != 0;
    r.value = cheat_tab.draft.empty() ? std::string(tr("No cheats")) : fmt("%d on", on);
    r.help = tr("Cheats turn on and off when you press Save, no restart needed. Turning one off undoes its changes to the game's code; values it already changed (money, items) stay. New cheat files show up after a restart.");
});
MENU_PAGE("mods/dlc", "DLC and event quests", "mods", 30);  // (1.0: the qol group's, S37)
MENU_PAGE("mods/forge", "Forge", "mods", 40);               // (1.0: the mods group's, S44)
MENU_PAGE("mods/textures", "Texture packs", "mods", 50);    // (1.0: S26)
MENU_PAGE("system/menu", "This menu", "system", 20);
MENU_PAGE("system/game", "Your game", "system", 30);
MENU_PAGE("system/code", "Game code", "system", 40);  // (1.0: the build group's, S46)

// ---- Controls (a phone's: the touch controls first, with the MH4U port's names; their rows where there is a touch
// screen to work them)
void rows_controls_10(std::vector<Row> &r) {
    add_choice(r, "touch", "Show the touch controls", s.draft.touch_controls, {tr("Auto"), tr("Always"), tr("Never")},
               [](int v) { s.draft.touch_controls = v; }, ini("Controls"));
}
void reset_controls_10() { s.draft.touch_controls = config_defaults().touch_controls; }
MENU_ENTRY("controls", 10, rows_controls_10, reset_controls_10, touch_rows);
void rows_controls_30(std::vector<Row> &r) {
    action(r, "touch.edit", tr("Customize controls and HUD"), []() {
        touch_edit_begin();  // (the editor starts once the menu is closed: one back, or the unsaved-changes dialog)
        request_back.store(true);
    });
    r.back().help = tr("Move and resize each button on the screen and each part of the game's HUD: drag it, pinch or use - / + for its size, hide a part, then Save. HUD: controller edits the HUD shown without the touch controls.");
}
MENU_ENTRY("controls", 30, rows_controls_30, {}, touch_screen);  // (the layout editor is worked by fingers)
void rows_controls_40(std::vector<Row> &r) {
    action(r, "touch.buttons", tr("Buttons on the screen"), []() {
        s_combos_alone = false;
        push(View::TouchButtons, "tb.0");
    });
    r.back().help = tr("Choose which of the game's buttons show on the screen, and add buttons of your own that press several at once.");
    int shown = 0, all = 0;
    for (int i = 0; i < TB_COUNT; i++)
        if (!tb_elsewhere(i)) shown += s.draft.touch_show[i] != 0, all++;
    r.back().value = std::to_string(shown) + " / " + std::to_string(all);
}
void reset_controls_40() {  // (and the combined buttons, which its view edits too)
    Config f = config_defaults();
    memcpy(s.draft.touch_show, f.touch_show, sizeof f.touch_show);
    memcpy(s.draft.touch_combo, f.touch_combo, sizeof f.touch_combo);
    memcpy(s.draft.touch_combo_pad, f.touch_combo_pad, sizeof f.touch_combo_pad);
}
MENU_ENTRY("controls", 40, rows_controls_40, reset_controls_40, touch_rows);
void rows_controls_50(std::vector<Row> &r) {
    Config &c = s.draft;
    number(r, "touch.camera", tr("Camera speed"), &c.touch_camera, lo("CameraSpeed"), hi("CameraSpeed"), .05f, ini("CameraSpeed"));
    r.back().value = fmt("%.2fx", c.touch_camera);
}
void reset_controls_50() { s.draft.touch_camera = config_defaults().touch_camera; }
MENU_ENTRY("controls", 50, rows_controls_50, reset_controls_50, touch_rows);
void rows_controls_60(std::vector<Row> &r) {
#ifdef __ANDROID__
    add_bool(r, "lock.on", "Lock-on", &s.draft.lock_on, ini("LockOn"));  // (the MH4U port's name)
    r.back().help = tr("Tap the Lock-on button on the screen (a controller: click the right stick; hold it with Control Type 3, where the click changes the target) and the camera keeps turning to the monster, the one the Target Cam chose or the nearest large one, until you tap it again. The target button changes the monster. Bows and bowguns fire at it from a normal stance; your own aim, crouching fire and the styles' moves are left to you. Turning the camera yourself pauses it for a moment.");
#else
    add_bool(r, "lock.on", "Lock-on", &s.draft.lock_on, ini("LockOn"));
    r.back().help = tr("The right stick's click (R3) keeps the camera turning to the monster, the one the Target Cam chose or the nearest large one, until you click it again (hold it with Control Type 3, where the click changes the target). The target button changes the monster. Bows and bowguns fire at it from a normal stance; your own aim, crouching fire and the styles' moves are left to you. Turning the camera yourself pauses it for a moment.");
#endif
}
void reset_controls_60() { s.draft.lock_on = config_defaults().lock_on; }
MENU_ENTRY("controls", 60, rows_controls_60, reset_controls_60);
void rows_controls_70(std::vector<Row> &r) {  // (the MH4U port's the same: names, range, default)
    Config &c = s.draft;
    add_bool(r, "gyro.aim", "Aim with the gyro", &c.gyro_aim, ini("GyroAim"));
    r.back().help = tr("Aiming a bow or a bowgun (a gun's aim, its scope, crouching fire; a bow's aiming mode), turning the phone turns the aim too, from where it was as the aim began, with what your fingers or the sticks do. A controller with a gyro is read instead of the phone. The gyroscope is read only while you aim.");
    if (c.gyro_aim) {
        number(r, "gyro.sens", tr("Gyro sensitivity"), &c.gyro_sensitivity, lo("GyroSensitivity"), hi("GyroSensitivity"), .1f, ini("GyroSensitivity"));
        r.back().value = fmt("%.1fx", c.gyro_sensitivity);
        r.back().help = tr("How far the aim turns for a turn of the phone or the controller: 1.0x the same angle.");
    }
}
void reset_controls_70() {
    Config f = config_defaults();
    s.draft.gyro_aim = f.gyro_aim;
    s.draft.gyro_sensitivity = f.gyro_sensitivity;
}
MENU_ENTRY("controls", 70, rows_controls_70, reset_controls_70);
// Controls > Touch controls
void rows_controls_touch_10(std::vector<Row> &r) {
    Config &c = s.draft;
    number(r, "touch.opacity", tr("Opacity"), &c.touch_opacity, lo("Opacity"), hi("Opacity"), .05f, ini("Opacity"));
    r.back().value = std::to_string((int)std::lround(c.touch_opacity * 100)) + "%";
}
void reset_controls_touch_10() { s.draft.touch_opacity = config_defaults().touch_opacity; }
MENU_ENTRY("controls/touch", 10, rows_controls_touch_10, reset_controls_touch_10);
void rows_controls_touch_30(std::vector<Row> &r) {
    add_bool(r, "touch.hud", "Move the HUD for touch", &s.draft.touch_hud, ini("MoveHUD"));
}
void reset_controls_touch_30() { s.draft.touch_hud = config_defaults().touch_hud; }
MENU_ENTRY("controls/touch", 30, rows_controls_touch_30, reset_controls_touch_30);
void rows_controls_touch_40(std::vector<Row> &r) {
#ifdef __ANDROID__  // (the phone's vibrator: elsewhere runtime/haptics.c does nothing)
    add_bool(r, "touch.vibration", "Vibrate on touch", &s.draft.touch_vibration, ini("Vibration"));
    add_bool(r, "phone.rumble", "Game rumble on the phone", &s.draft.phone_rumble, ini("PhoneRumble"));
#else
    (void)r;
#endif
}
void reset_controls_touch_40() {
    Config f = config_defaults();
    s.draft.touch_vibration = f.touch_vibration;
    s.draft.phone_rumble = f.phone_rumble;
}
MENU_ENTRY("controls/touch", 40, rows_controls_touch_40, reset_controls_touch_40);
void rows_controls_touch_50(std::vector<Row> &r) {
    add_number(r, "touch.chat.size", cs("Chat panel size", "Tamaño del panel de chat"),
               []() { return std::round(s.chat_panel_size_draft * 100.0); },
               [](double v) {
                   s.chat_panel_size_draft = std::clamp((float)(v / 100.0), .65f, 1.35f);
                   chat_panel_preview_size(s.chat_panel_size_draft);
               }, 65, 135, 5, true);
    r.back().value += " %";
    r.back().help = cs("Changes the in-game chat panel size. Press Save to keep it; Cancel restores the saved size.",
                       "Cambia el tamaño del panel de chat. Pulsa Guardar para conservarlo; Cancelar restaura el tamaño guardado.");
    action(r, "touch.chat.reset", cs("Reset chat panel position", "Restablecer posición del panel de chat"),
           []() {
               chat_panel_reset();
               s.chat_panel_size_draft = s.chat_panel_size_saved = chat_panel_scale();
           });
}
MENU_ENTRY("controls/touch", 50, rows_controls_touch_50);
// Controls > Controller
void rows_controls_pad_10(std::vector<Row> &r) {
    add_choice(r, "face", "Face buttons", s.draft.face_buttons, {tr("Position"), tr("Label")},
               [](int v) { s.draft.face_buttons = v; }, ini("FaceButtons"));
}
void reset_controls_pad_10() { s.draft.face_buttons = config_defaults().face_buttons; }
MENU_ENTRY("controls/pad", 10, rows_controls_pad_10, reset_controls_pad_10);
void rows_controls_pad_20(std::vector<Row> &r) {
    if (!touch_rows()) {  // (a controller's button or a key presses them: that view's combined buttons alone)
        action(r, "touch.combos", tr("Combined buttons"), []() {
            s_combos_alone = true;
            push(View::TouchButtons, "tc.0");
        });
        r.back().help = tr("Buttons of your own that press several of the game's at once: on a controller's button, or on a key in Keybinds.");
    }
#ifdef __ANDROID__  // (a phone while a controller is connected: Buttons on the screen's combined buttons alone, as the MH4U port's)
    else if (host_input_real_pad()) {
        action(r, "pad.combos", tr("Combined buttons"), []() {
            s_combos_alone = true;
            push(View::TouchButtons, "tc.0");
        });
        r.back().help = tr("Buttons of your own that press several of the game's at once, on a controller's button.");
    }
#endif
}
void reset_controls_pad_20() {
    Config f = config_defaults();
    memcpy(s.draft.touch_combo, f.touch_combo, sizeof f.touch_combo);
    memcpy(s.draft.touch_combo_pad, f.touch_combo_pad, sizeof f.touch_combo_pad);
}
MENU_ENTRY("controls/pad", 20, rows_controls_pad_20, reset_controls_pad_20);
void rows_controls_pad_30(std::vector<Row> &r) {
    action(r, "pad.map", tr("Map a controller"), []() { push(View::PadList, "pad.0"); });
    r.back().help = tr("For a controller the game does not read well: press each button once and it works from then on.");
}
MENU_ENTRY("controls/pad", 30, rows_controls_pad_30);
#ifndef __ANDROID__  // (a phone: not worth a row)
void rows_controls_pad_110(std::vector<Row> &r) {
    Config &c = s.draft;
    add_choice(r, "menu.confirm", "Confirm button (recomp)", c.menu_confirm, {tr("Original"), tr("Bottom button"), tr("Right button")},
               [](int v) { s.draft.menu_confirm = v; }, ini("MenuConfirm"));
    add_choice(r, "icons", "Button icons", c.button_icons, {"Xbox", "Switch", "PlayStation"},
               [](int v) { s.draft.button_icons = v; }, ini("ButtonIcons"));
    add_bool(r, "background", "Background input", &c.background_input, ini("BackgroundInput"));  // (a phone pauses in the background)
    add_choice(r, "combo", "Combo input window", c.combo_window, {tr("Lenient"), tr("Strict")},
               [](int v) { s.draft.combo_window = v; }, ini("ComboInputWindow"));
}
void reset_controls_pad_110() {
    Config f = config_defaults();
    s.draft.menu_confirm = f.menu_confirm;
    s.draft.button_icons = f.button_icons;
    s.draft.background_input = f.background_input;
    s.draft.combo_window = f.combo_window;
}
MENU_ENTRY("controls/pad", 110, rows_controls_pad_110, reset_controls_pad_110);
#endif
// Controls > Keyboard and mouse (a desktop's; on a phone its keys are reset with the section all the same, as before)
void rows_controls_keys_10(std::vector<Row> &r) {
#ifndef __ANDROID__
    Config &c = s.draft;
    action(r, "keybinds", tr("Keybinds"), []() { push(View::Keybinds, "bind.0"); });
    r.back().help = tr("The keys and mouse buttons for the Switch controller's buttons, for moving, the camera, the item bar and the combined buttons, and the chat key.");
    number(r, "mouse", tr("Mouse sensitivity"), &c.mouse_sensitivity, lo("MouseSensitivity"), hi("MouseSensitivity"), .05f, ini("MouseSensitivity"));
    add_bool(r, "mouse.menus", "Mouse in the game's menus", &c.mouse_menus, ini("MouseMenus"));  // (hle/mousemenu.c)
#else
    keyboard_mouse_rows(r);  // (S14: a phone's, only while a keyboard and a mouse are connected)
#endif
}
void reset_controls_keys_10() {
    Config f = config_defaults();
    s.draft.mouse_sensitivity = f.mouse_sensitivity;
    s.draft.mouse_menus = f.mouse_menus;
    memcpy(s.draft.binds, f.binds, sizeof f.binds);
    SDL_strlcpy(s.draft.chat_key, f.chat_key, sizeof s.draft.chat_key);
}
bool shown_controls_keys_10() {
#ifdef __ANDROID__
    return host_input_keyboard_mouse();  // (S14)
#else
    return true;
#endif
}
MENU_ENTRY("controls/keys", 10, rows_controls_keys_10, reset_controls_keys_10, shown_controls_keys_10);

// ---- Graphics & Audio: the three that trade looks for speed together first, as in the MH4U port (Low-end mode, the
// frame rate, the 3D resolution), the switches players reach for, the sound and the readout
void rows_graphics_10(std::vector<Row> &r) {
    Config &c = s.draft;
    add_choice(
        r, "lowend", "Low-end mode", c.low_end < 0 || c.low_end > 2 ? 0 : c.low_end, {tr("Off"), tr("On"), tr("Toaster")},
        [](int v) {  // (it brings the resolution, the frame rate and the switches along; all can then be changed)
            Config &d = s.draft;
            int was = d.low_end;
            d.low_end = v;
#ifdef __ANDROID__
            if (v) {
                int scale = v == LOW_END_TOASTER ? TOASTER_SCALE : LOW_END_SCALE;
                if (was == LOW_END_TOASTER && d.render_scale == TOASTER_SCALE) d.render_scale = scale;  // (back to On)
                d.render_scale = std::min(d.render_scale, scale);
                d.fps = std::min(d.fps, LOW_END_FPS);
                d.shadows = 0;
                d.bloom = 0;
                if (v == LOW_END_TOASTER) d.reverb = 0, d.grass = 0;
                else if (was == LOW_END_TOASTER) d.reverb = 1, d.grass = 1;
            } else {
                if (d.render_scale <= LOW_END_SCALE) d.render_scale = 100;
                if (d.fps == LOW_END_FPS) d.fps = 60;
                d.shadows = 1;
                d.bloom = 1;
                d.reverb = 1;
                if (was == LOW_END_TOASTER) d.grass = 1;  // (only Toaster turns the grass off: On leaves it as set)
            }
#else  // (a desktop: the 3D picture about 720 lines tall, 540 with Toaster, whatever the screen (config_lowend_scale), and
       // Bloom off; Low-end keeps the frame rate and the shadows, Toaster sets 30 FPS and no shadows; the reverb stays.
       // Turned off, or from Toaster to On, what it lowered comes back where it still has the value it set)
            if (v == was)
                return;
            int on = config_lowend_scale(&d, 1), toaster = config_lowend_scale(&d, LOW_END_TOASTER);
            // (an older PC build's switch was a phone's: RenderScale 40, Toaster 25, 30 FPS and no shadows, Toaster no
            // reverb either. A file it wrote keeps those, and leaving the mode takes them back too; 40 under Toaster is
            // On's, which Toaster's min kept. Under On, 40 is that only with its 30 FPS or no shadows still there: this
            // On sets neither, and 40% picked by hand stays)
            bool old = was == LOW_END_TOASTER ? (d.render_scale == TOASTER_SCALE || d.render_scale == LOW_END_SCALE)
                                              : (was && d.render_scale == LOW_END_SCALE && (d.fps == LOW_END_FPS || !d.shadows));
            if (v) {
                int scale = v == LOW_END_TOASTER ? toaster : on;
                if (was == LOW_END_TOASTER && (d.render_scale == toaster || old)) d.render_scale = scale;  // (back to On)
                d.render_scale = std::min(d.render_scale, scale);
                d.bloom = 0;
                if (v == LOW_END_TOASTER) {
                    d.fps = std::min(d.fps, LOW_END_FPS);
                    d.shadows = 0;
                }
            } else {
                if (old || d.render_scale == (was == LOW_END_TOASTER ? toaster : on)) d.render_scale = 100;
                d.bloom = 1;
            }
            if (was == LOW_END_TOASTER || (old && !v)) {
                if (d.fps == LOW_END_FPS) d.fps = 60;
                d.shadows = 1;
                if (old && was == LOW_END_TOASTER) d.reverb = 1;
            }
#endif
        },
        ini("LowEnd"));
#ifdef __ANDROID__
    r.back().help = tr("For weak phones: turns off bloom, depth of field and shadows, uses lighter textures and keeps the HUD sharp over a smaller 3D picture. It also sets the 3D resolution and the frame rate, and you can change all of them. Toaster: everything for speed and the battery before looks: 25%, 30 FPS, no reverb or grass, and a lighter HUD and textures still.");
#else  // (a PC's GPU takes the game's textures as they are: none smaller, nvn/vulkan/textures.c; config.c turns MSAA and FSR off,
       // and with Toaster FXAA. The switch sets RenderScale for the Resolution the draft has, once: config.c ignores
       // RenderScale with a RenderResolution of its own)
    r.back().help = tr("For a weak GPU, such as integrated graphics: it sets the 3D resolution to about 720 lines for the screen resolution you have now (66% at 1080p, 50% at 1440p, 33% at 4K; with Render resolution on Auto), keeps the HUD and the text sharp, and turns off bloom, depth of field, MSAA and FSR. The frame rate, shadows, FXAA, texture filtering and reverb stay as they are. Toaster, for the weakest: about 540 lines, 30 FPS, no shadows or FXAA, and cheaper texture filtering. You can change the 3D resolution, the frame rate and shadows afterwards.");
#endif
}
void reset_graphics_10() { s.draft.low_end = config_defaults().low_end; }
MENU_ENTRY("graphics", 10, rows_graphics_10, reset_graphics_10);
void rows_graphics_20(std::vector<Row> &r) {
    Config &c = s.draft;
    number(r, "fps", "Frame rate limit", &c.fps, (int)lo("FPS"), (int)hi("FPS"), 1, ini("FPS"));
#ifndef __ANDROID__  // (a desktop: past 240 comes Unlimited; a number in between, as the file may have it, stays a number)
    if (c.fps >= FPS_UNLIMITED)
        r.back().value = tr("Unlimited");
    r.back().adjust = [](int d) {
        int &v = s.draft.fps;
        if (d > 0)
            v = v >= FPS_PHONE_MAX ? FPS_UNLIMITED : std::min(FPS_PHONE_MAX, v + d);
        else if (d < 0)
            v = v > FPS_PHONE_MAX ? FPS_PHONE_MAX : std::max(30, v + d);
    };
    r.back().help = tr("The most frames a second. Unlimited: as many as the PC can draw, with VSync off; with VSync on, the monitor's refresh rate is the most. On a PC that can't hold 60, 30 is steadier: Toaster sets it, and Low-end mode leaves the frame rate as it is.");
#endif
    // left / right: one frame per second more or less; Confirm: the common ones
    static const int presets[] = {30, 60, 90, 120, 144, 240,  // (the MH4U port's same list)
#ifndef __ANDROID__
                                  FPS_UNLIMITED,
#endif
    };
    r.back().menu = true;
    Row copy = r.back();
    r.back().activate = [copy]() {
        std::vector<std::string> names;
        int now = -1;
        for (int i = 0; i < (int)std::size(presets); i++) {
            names.push_back(presets[i] >= FPS_UNLIMITED ? std::string(tr("Unlimited")) : std::to_string(presets[i]));
            if (presets[i] <= s.draft.fps)
                now = presets[i] == s.draft.fps ? i : -1 - i;  // (not one of them: start at the one below)
        }
        choices(copy, names, now, [](int v) { s.draft.fps = presets[v]; });
        if (now < -1)
            focus("choice." + std::to_string(-1 - now));
    };
#ifdef MHGU_IOS
    add_bool(r, "town.fps.saver", "Town FPS saver", &c.town_fps_saver, ini("TownFpsSaver"));
    r.back().help = tr("Caps villages and hubs at 30 FPS to reduce rendering work there. Quests keep your chosen FPS limit; resolution and visual effects stay unchanged.");
#endif
}
void reset_graphics_20() { s.draft.fps = config_defaults().fps; s.draft.town_fps_saver = config_defaults().town_fps_saver; }
MENU_ENTRY("graphics", 20, rows_graphics_20, reset_graphics_20);
void rows_graphics_30(std::vector<Row> &r) { scale_row(r); }
// (a desktop's: while its Render resolution is Auto)
void reset_graphics_30() {
    Config f = config_defaults();
    s.draft.render_scale = f.render_scale;
#ifdef __ANDROID__  // (a phone's exact size is the 3D resolution's too: scale_row)
    s.draft.render_w = f.render_w, s.draft.render_h = f.render_h;
#endif
}
MENU_ENTRY("graphics", 30, rows_graphics_30, reset_graphics_30);
void rows_graphics_40(std::vector<Row> &r) { add_bool(r, "shadows", "Shadows", &s.draft.shadows, ini("Shadows")); }
void reset_graphics_40() { s.draft.shadows = config_defaults().shadows; }
MENU_ENTRY("graphics", 40, rows_graphics_40, reset_graphics_40);
void rows_graphics_50(std::vector<Row> &r) { add_bool(r, "grass", "Grass", &s.draft.grass, ini("Grass")); }
void reset_graphics_50() { s.draft.grass = config_defaults().grass; }
MENU_ENTRY("graphics", 50, rows_graphics_50, reset_graphics_50);
void rows_graphics_60(std::vector<Row> &r) {
    number(r, "volume", "Volume", &s.draft.volume, (int)lo("Volume"), (int)hi("Volume"), 1, ini("Volume"));
    r.back().value = std::to_string(s.draft.volume) + "%";
}
void reset_graphics_60() { s.draft.volume = config_defaults().volume; }
MENU_ENTRY("graphics", 60, rows_graphics_60, reset_graphics_60);
void rows_graphics_screen_85(std::vector<Row> &r) {
#ifdef __ANDROID__
    add_bool(r, "stats", "FPS counter", &s.draft.show_stats, ini("ShowStats"));
#else  // (a desktop: Off, Basic (the file's On) or Full: runtime/perfstats.cpp, platform/win_stats.c)
    add_choice(r, "stats", "Show FPS and PC stats", s.draft.show_stats, {tr("Off"), tr("Basic"), tr("Full")},
               [](int v) { s.draft.show_stats = v; }, ini("ShowStats"));
    r.back().help = tr("Basic: frames per second, frame time, the longest frame and the GPU's temperature. Full adds a line on the GPU (use, temperature, clock, video memory) and one on the CPU (the game's use and memory, the CPU's clock, the time the game's and the render threads take per frame). The CPU's temperature is not shown: Windows lets no program read it without installing a driver.");
#endif
}
void reset_graphics_screen_85() { s.draft.show_stats = config_defaults().show_stats; }
MENU_ENTRY("graphics/screen", 85, rows_graphics_screen_85, reset_graphics_screen_85);  // (the FPS counter: with the HUD, where the editor moves it)
// Graphics & Audio > Picture and sound. (None of these with Low-end mode: config.c. fxaa, FXAA's rows: a desktop's
// Low-end mode keeps them, only Toaster's turns FXAA off. The anti-aliasing rows while FSR runs: FSR at the next start
// turns them off. A desktop's Low-end mode keeps FXAA and turns FSR off there, config.c, so with it they say what that
// start will have)
void low_end_off(std::vector<Row> &r, bool fxaa = false) {
    const Config &c = s.draft;
#ifdef __ANDROID__
    (void)fxaa;
    if (!c.low_end) return;
#else
    if (!c.low_end || (fxaa && c.low_end != LOW_END_TOASTER)) return;
#endif
    r.back().enabled = false;
    r.back().value = tr("Off (low-end)");
}
bool fsr_next() {
#ifdef __ANDROID__
    return s.draft.fsr != 0;
#else
    return s.draft.fsr && !s.draft.low_end;
#endif
}
void fsr_off(std::vector<Row> &r) {
    if (!g_config.fsr)
        return;
    r.back().cold = true;
    if (fsr_next()) {
        r.back().enabled = false;
        r.back().value = tr("Off (FSR)");
    }
}
void rows_graphics_picture_5(std::vector<Row> &r) {
    note(r, "fsr.note", tr("FSR overrides MSAA and FXAA while active."));
}
bool shown_graphics_picture_5() { return s.draft.fsr || g_config.fsr; }
MENU_ENTRY("graphics/picture", 5, rows_graphics_picture_5, {}, shown_graphics_picture_5);
#ifndef MHGU_IOS
void rows_graphics_picture_10(std::vector<Row> &r) {
    add_bool(r, "bloom", "Bloom and depth of field", &s.draft.bloom, ini("Bloom"));
    if (s.draft.fsr && !s.draft.low_end) {
        r.back().enabled = false;
        r.back().value = tr("On (FSR)");
    }
}
void reset_graphics_picture_10() { s.draft.bloom = config_defaults().bloom; }
MENU_ENTRY("graphics/picture", 10, rows_graphics_picture_10, reset_graphics_picture_10);
#endif
void rows_graphics_picture_20(std::vector<Row> &r) {
    Config &c = s.draft;
#ifdef MHGU_IOS
    add_choice(r, "msaa", "MSAA", 0, {tr("Off")}, [](int) { s.draft.msaa = 1; }, ini("MSAA"));
    r.back().enabled = false;
    r.back().value = tr("Not supported");
    r.back().help = "MSAA is not supported on iOS; use FXAA for anti-aliasing.";
#else
    add_choice(r, "msaa", "MSAA", c.msaa == 8 ? 3 : c.msaa == 4 ? 2 : c.msaa == 2 ? 1 : 0, {tr("Off"), "2x", "4x", "8x"},
               [](int v) { s.draft.msaa = 1 << v; }, ini("MSAA"));
    low_end_off(r);
    fsr_off(r);
#endif
    add_bool(r, "fxaa", "FXAA", &c.fxaa, ini("FXAA"));
    low_end_off(r, true);
    fsr_off(r);
#ifndef __ANDROID__  // (a phone: not worth a row)
    add_choice(r, "fxaamode", "FXAA mode", c.fxaa_mode, {tr("Original"), "3.11"}, [](int v) { s.draft.fxaa_mode = v; },
               ini("FXAAMode"));
    low_end_off(r, true);
    fsr_off(r);
#endif
}
void reset_graphics_picture_20() {
    Config f = config_defaults();
    s.draft.msaa = f.msaa;
    s.draft.fxaa = f.fxaa;
    s.draft.fxaa_mode = f.fxaa_mode;
}
MENU_ENTRY("graphics/picture", 20, rows_graphics_picture_20, reset_graphics_picture_20);
void rows_graphics_picture_30(std::vector<Row> &r) {
    Config &c = s.draft;
    number(r, "drawdist", tr("Draw distance"), &c.draw_distance, lo("DrawDistance"), hi("DrawDistance"), .25f, ini("DrawDistance"));
    if (c.draw_distance == 0)
        r.back().value = tr("No limit");
}
void reset_graphics_picture_30() { s.draft.draw_distance = config_defaults().draw_distance; }
MENU_ENTRY("graphics/picture", 30, rows_graphics_picture_30, reset_graphics_picture_30);
#ifndef __ANDROID__  // (a phone: not worth a row)
void rows_graphics_picture_40(std::vector<Row> &r) {
    add_bool(r, "smooth", "Smooth gradients", &s.draft.smooth_gradients, ini("SmoothGradients"));
}
void reset_graphics_picture_40() { s.draft.smooth_gradients = config_defaults().smooth_gradients; }
MENU_ENTRY("graphics/picture", 40, rows_graphics_picture_40, reset_graphics_picture_40);
#endif
void rows_graphics_picture_50(std::vector<Row> &r) {
    Config &c = s.draft;
    add_bool(r, "fsr", "FSR", &c.fsr, ini("FSR"));
#ifndef __ANDROID__  // (measured on an RX 6800 XT: FSR 3.1 Quality's frame 3.7 ms, 1.8 to 2.3 without FSR and with FXAA)
    r.back().help = tr("Rebuilds the 3D picture with FSR's temporal upscaling and anti-aliasing. FSR costs GPU time of its own: about 2 ms a frame on a fast graphics card, more on integrated graphics. For speed on a weak GPU, lower the 3D resolution or use Low-end mode instead.");
#endif
    low_end_off(r);
    if (!c.fsr || c.low_end)
        return;
#ifndef __ANDROID__  // (FSR 4: AMD's RX 9000 cards only; XeSS-SR: Windows, libxess.dll beside MHGU.exe)
    add_choice(
        r, "fsr.provider", "Upscaler", c.fsr_upscaler,
#ifdef _WIN32
        {"FSR 3.1", "FSR 4", "XeSS-SR"},
#else
        {"FSR 3.1", "FSR 4"},
#endif
        [](int v) { s.draft.fsr_upscaler = v; }, ini("Upscaler"));
#ifdef _WIN32
    r.back().help = tr("Which upscaler rebuilds the 3D picture. FSR 3.1 runs on most graphics cards. XeSS-SR, Intel's machine-learning upscaler, needs Intel Iris Xe or Arc graphics, or another card with DP4a (AMD Radeon RX 6000, NVIDIA GeForce RTX 3000 or newer), where it costs more GPU time than FSR 3.1. It also needs the Microsoft Visual C++ Redistributable (x64). When the one chosen can't run, the game uses FSR 3.1.");
#endif
    if (g_fsr4_fallback && c.fsr_upscaler == FSR_UP_4 && g_config.fsr && g_config.fsr_upscaler == FSR_UP_4) {
        r.back().value += std::string(" (") + tr("FSR 3.1 in use") + ")";  // (fsr4.c: FSR 4 didn't start)
        r.back().warn = true;
        r.back().help = tr(g_fsr4_fallback);
    }
#ifdef _WIN32
    // (xess.c: XeSS-SR didn't start, or stopped; it would not after a restart either)
    bool xess_out = g_xess_fallback && g_config.fsr && g_config.fsr_upscaler == FSR_UP_XESS;
    if (xess_out && c.fsr_upscaler == FSR_UP_XESS) {
        r.back().value += std::string(" (") + tr("FSR 3.1 in use") + ")";
        r.back().warn = true;
        r.back().help = tr(g_xess_fallback);
    }
#endif
#endif
    add_choice(r, "fsr.quality", "FSR quality", c.fsr_quality,
               {tr("Native AA"), tr("Quality"), tr("Balanced"), tr("Performance"), tr("Ultra performance")},
               [](int v) { s.draft.fsr_quality = v; }, ini("FSRQuality"));
#ifndef __ANDROID__  // (config.c: FSRQuality's ratios 1, 1.5, 1.7, 2 and 3)
    r.back().help = tr("How small FSR draws the 3D picture before rebuilding it. Native AA draws it at full size: it only improves the image, and costs more than FSR off. Quality, Balanced, Performance and Ultra performance draw it at 67%, 59%, 50% and 33%; FSR's own cost stays, so the 3D resolution alone at the same size is faster, though softer.");
#endif
    number(r, "fsr.sharpness", tr("Sharpness"), &c.fsr_sharpness, lo("Sharpness"), hi("Sharpness"), .05f, ini("Sharpness"));
#ifdef _WIN32
    if (c.fsr_upscaler == FSR_UP_XESS && !xess_out) {  // (XeSS-SR has no sharpening; FSR 3.1 in its place has)
        r.back().enabled = false;
        r.back().value = tr("Off (XeSS-SR)");
        r.back().help = tr("XeSS-SR has no sharpening filter: Sharpness is for FSR 3.1 and FSR 4.");
    }
#endif
#ifndef __ANDROID__  // (a phone: not worth these rows)
    add_bool(r, "fsr.motion", "Object motion", &c.fsr_objmotion, ini("ObjectMotion"));
    number(r, "fsr.reactive", tr("Reactive mask"), &c.fsr_reactive, lo("Reactive"), hi("Reactive"), .05f, ini("Reactive"));
    add_bool(r, "fsr.surfaces", "Animated surfaces", &c.fsr_animsurf, ini("AnimSurf"));
#endif
}
void reset_graphics_picture_50() {
    Config f = config_defaults(), &c = s.draft;
    c.fsr = f.fsr;
    c.fsr_upscaler = f.fsr_upscaler;
    c.fsr_quality = f.fsr_quality;
    c.fsr_sharpness = f.fsr_sharpness;
    c.fsr_objmotion = f.fsr_objmotion;
    c.fsr_reactive = f.fsr_reactive;
    c.fsr_animsurf = f.fsr_animsurf;
}
MENU_ENTRY("graphics/picture", 50, rows_graphics_picture_50, reset_graphics_picture_50);
void rows_graphics_picture_80(std::vector<Row> &r) {
    header(r, "audio.head", tr("Sound"));
    add_bool(r, "reverb", "Reverb", &s.draft.reverb, ini("Reverb"));
#ifndef __ANDROID__  // (a phone: not worth a row)
    add_bool(r, "mutebg", "Mute in background", &s.draft.mute_in_background, ini("MuteInBackground"));
#endif
}
void reset_graphics_picture_80() {
    Config f = config_defaults();
    s.draft.reverb = f.reverb;
    s.draft.mute_in_background = f.mute_in_background;
}
MENU_ENTRY("graphics/picture", 80, rows_graphics_picture_80, reset_graphics_picture_80);
// Graphics & Audio > Screen and HUD (the Display tab of 0.1.9: a phone's window is the screen, at its own resolution)
#ifndef __ANDROID__
#ifdef MHGU_IOS
struct IOSResolutionPreset {
    const char *name;
    int width, height;
};
struct IOSAspectPreset {
    const char *name;
    float aspect;
};
static constexpr IOSAspectPreset ios_aspect_presets[] = {
    {"iPhone classic 3:2", 3.0f / 2.0f},
    {"iPhone 5-8 16:9", 16.0f / 9.0f},
    {"iPhone X-18 19.5:9", 19.5f / 9.0f},
    {"iPhone Duo outer", 2034.0f / 1398.0f},
    {"iPhone Duo inner", 2670.0f / 1878.0f},
    {"iPad / Pro 9.7-13 4:3", 4.0f / 3.0f},
    {"iPad mini 6-7", 2266.0f / 1488.0f},
    {"iPad Air 10.9-11", 2360.0f / 1640.0f},
    {"iPad Pro 11 (1st-3rd)", 2388.0f / 1668.0f},
    {"iPad Pro 11 (M4/M5)", 2420.0f / 1668.0f},
};
int ios_aspect_choice(float aspect) {
    if (aspect == 0) return 0;  // Auto
    for (size_t i = 0; i < sizeof(ios_aspect_presets) / sizeof(ios_aspect_presets[0]); ++i)
        if (fabsf(aspect - ios_aspect_presets[i].aspect) < 0.003f) return (int)i + 1;
    return (int)(sizeof(ios_aspect_presets) / sizeof(ios_aspect_presets[0])) + 1;  // Custom
}
std::vector<std::string> ios_aspect_names(bool automatic, bool custom) {
    std::vector<std::string> names;
    if (automatic) names.emplace_back(tr("Auto"));
    for (const auto &preset : ios_aspect_presets) names.emplace_back(preset.name);
    if (custom) names.emplace_back(tr("Custom"));
    return names;
}
// Landscape pixel dimensions, grouped where older devices share the same panel resolution. These are selectable
// targets; they do not detect or change the physical device.
static constexpr IOSResolutionPreset ios_screen_presets[] = {
    {"iPhone 2G / 3G / 3GS (480 x 320)", 480, 320},
    {"iPhone 4 / 4s (960 x 640)", 960, 640},
    {"iPhone 5 / 5c / 5s / SE (1st gen) (1136 x 640)", 1136, 640},
    {"iPhone 6 / 6s / 7 / 8 / SE (2nd-3rd gen) (1334 x 750)", 1334, 750},
    {"iPhone 6 Plus / 6s Plus / 7 Plus / 8 Plus (1920 x 1080)", 1920, 1080},
    {"iPhone XR / 11 (1792 x 828)", 1792, 828},
    {"iPhone X / XS / 11 Pro (2436 x 1125)", 2436, 1125},
    {"iPhone XS Max / 11 Pro Max (2688 x 1242)", 2688, 1242},
    {"iPhone 12 mini / 13 mini (2340 x 1080)", 2340, 1080},
    {"iPhone 12 / 12 Pro / 13 / 13 Pro / 14 / 16e / 17e (2532 x 1170)", 2532, 1170},
    {"iPhone 12 Pro Max / 13 Pro Max / 14 Plus (2778 x 1284)", 2778, 1284},
    {"iPhone 14 Pro / 15 / 15 Pro / 16 (2556 x 1179)", 2556, 1179},
    {"iPhone 14 Pro Max / 15 Plus / 15 Pro Max / 16 Plus (2796 x 1290)", 2796, 1290},
    {"iPhone 16 Pro / 17 / 17 Pro / 18 / 18 Pro (2622 x 1206)", 2622, 1206},
    {"iPhone 16 Pro Max / 17 Pro Max / 18 Pro Max (2868 x 1320)", 2868, 1320},
    {"iPhone Air (2736 x 1260)", 2736, 1260},
    {"iPhone Duo outer (2034 x 1398)", 2034, 1398},
    {"iPhone Duo inner (2670 x 1878)", 2670, 1878},
    {"iPad (1st-2nd gen) / iPad mini (1st gen) (1024 x 768)", 1024, 768},
    {"iPad / iPad mini / iPad Air (2048 x 1536)", 2048, 1536},
    {"iPad (6th-10th gen) / iPad (A16) (2160 x 1620)", 2160, 1620},
    {"iPad mini (6th-7th gen) (2266 x 1488)", 2266, 1488},
    {"iPad Air 10.9 / 11-inch (2360 x 1640)", 2360, 1640},
    {"iPad Pro 9.7-inch (2048 x 1536)", 2048, 1536},
    {"iPad Pro 10.5-inch (2224 x 1668)", 2224, 1668},
    {"iPad Pro 11-inch (2388 x 1668)", 2388, 1668},
    {"iPad Pro 11-inch (M4 / M5) (2420 x 1668)", 2420, 1668},
    {"iPad Pro 12.9-inch (2732 x 2048)", 2732, 2048},
    {"iPad Pro 13-inch (M4 / M5) (2752 x 2064)", 2752, 2064},
};
template <size_t N>
int ios_resolution_choice(int width, int height, const IOSResolutionPreset (&presets)[N], bool desktop) {
    if (desktop && width == 0 && height == 0) return 0;
    for (size_t i = 0; i < N; ++i)
        if (presets[i].width == width && presets[i].height == height) return (int)i + (desktop ? 1 : 0);
    return (int)N + (desktop ? 1 : 0);  // Custom
}
template <size_t N>
std::vector<std::string> ios_resolution_names(const IOSResolutionPreset (&presets)[N], bool desktop, bool render) {
    std::vector<std::string> names;
    if (desktop) names.emplace_back(tr("Desktop"));
    if (render) names.emplace_back("1080p (1920 x 1080)");
    for (const auto &preset : presets) names.emplace_back(preset.name);
    names.emplace_back(tr("Custom"));
    return names;
}
#endif
void rows_graphics_screen_10(std::vector<Row> &r) {
    Config &c = s.draft;
    add_choice(r, "display.mode", "Window mode", c.display_mode, {tr("Windowed"), tr("Fullscreen"), tr("Borderless")},
               [](int v) { s.draft.display_mode = v; }, ini("Mode"));
#ifdef MHGU_IOS
    auto names = ios_resolution_names(ios_screen_presets, true, false);
    int selected = ios_resolution_choice(c.width, c.height, ios_screen_presets, true);
    add_choice(r, "display.preset", "Screen resolution", selected, names, [selected](int v) {
        if (v == 0) s.draft.width = s.draft.height = 0;
        else if (v <= (int)(sizeof(ios_screen_presets) / sizeof(ios_screen_presets[0]))) {
            const auto &preset = ios_screen_presets[v - 1];
            s.draft.width = preset.width; s.draft.height = preset.height;
        } else if (v == (int)(sizeof(ios_screen_presets) / sizeof(ios_screen_presets[0])) + 1 &&
                   selected != (int)(sizeof(ios_screen_presets) / sizeof(ios_screen_presets[0])) + 1) {
            s.draft.width = 1920; s.draft.height = 1200;
        }
    }, ini("Resolution"));
    if (selected == (int)(sizeof(ios_screen_presets) / sizeof(ios_screen_presets[0])) + 1) {
        number(r, "display.width", "Width", &c.width, 320, 16384, 80, ini("Resolution"));
        number(r, "display.height", "Height", &c.height, 180, 16384, 45, ini("Resolution"));
    }
#else
    add_choice(
        r, "display.auto", "Screen resolution", !c.width ? 0 : 1, {tr("Desktop"), tr("Custom")},
        [](int v) {
            s.draft.width = v ? 1920 : 0;
            s.draft.height = v ? 1080 : 0;
        },
        ini("Resolution"));
    if (c.width) {
        number(r, "display.width", "Width", &c.width, 320, 16384, 80, ini("Resolution"));
        number(r, "display.height", "Height", &c.height, 180, 16384, 45, ini("Resolution"));
    }
#endif
    add_bool(r, "vsync", "VSync", &c.vsync, ini("VSync"));
}
void reset_graphics_screen_10() {
    Config f = config_defaults(), &c = s.draft;
    c.display_mode = f.display_mode;
    c.width = f.width;
    c.height = f.height;
    c.vsync = f.vsync;
}
MENU_ENTRY("graphics/screen", 10, rows_graphics_screen_10, reset_graphics_screen_10);
void rows_graphics_screen_20(std::vector<Row> &r) {
    Config &c = s.draft;
#ifdef MHGU_IOS
    auto names = ios_resolution_names(ios_screen_presets, false, true);
    const int preset_count = (int)(sizeof(ios_screen_presets) / sizeof(ios_screen_presets[0]));
    int selected = !c.render_w ? 0 : c.render_w == 1920 && c.render_h == 1080 ? 0
                                                                          : ios_resolution_choice(c.render_w, c.render_h, ios_screen_presets, false) + 1;
    add_choice(r, "render.preset", "Render resolution", selected, names, [selected](int v) {
        if (v == 0) { s.draft.render_w = 1920; s.draft.render_h = 1080; }
        else if (v <= (int)(sizeof(ios_screen_presets) / sizeof(ios_screen_presets[0]))) {
            const auto &preset = ios_screen_presets[v - 1];
            s.draft.render_w = preset.width; s.draft.render_h = preset.height;
        } else if (v == (int)(sizeof(ios_screen_presets) / sizeof(ios_screen_presets[0])) + 1 &&
                   selected != (int)(sizeof(ios_screen_presets) / sizeof(ios_screen_presets[0])) + 1) {
            s.draft.render_w = 1920; s.draft.render_h = 1200;
        }
    }, ini("RenderResolution"));
    if (selected == preset_count + 1) {
        number(r, "render.width", "Width", &c.render_w, 320, 16384, 80, ini("RenderResolution"));
        number(r, "render.height", "Height", &c.render_h, 180, 16384, 45, ini("RenderResolution"));
    }
#else
    add_choice(
        r, "render.auto", "Render resolution", !c.render_w ? 0 : 1, {tr("Auto"), tr("Custom")},
        [](int v) {
            s.draft.render_w = v ? 1920 : 0;
            s.draft.render_h = v ? 1080 : 0;
        },
        ini("RenderResolution"));
    if (c.render_w) {
        number(r, "render.width", "Width", &c.render_w, 320, 16384, 80, ini("RenderResolution"));
        number(r, "render.height", "Height", &c.render_h, 180, 16384, 45, ini("RenderResolution"));
    }
#endif
}
void reset_graphics_screen_20() {
    Config f = config_defaults();
    s.draft.render_w = f.render_w;
    s.draft.render_h = f.render_h;
}
MENU_ENTRY("graphics/screen", 20, rows_graphics_screen_20, reset_graphics_screen_20);
void rows_graphics_screen_30(std::vector<Row> &r) {  // (a phone: not worth a row)
    Config &c = s.draft;
#ifdef MHGU_IOS
    auto names = ios_aspect_names(true, true);
    const int preset_count = (int)(sizeof(ios_aspect_presets) / sizeof(ios_aspect_presets[0]));
    int selected = ios_aspect_choice(c.aspect_ratio);
    add_choice(r, "aspect.auto", "Automatic aspect ratio", selected, names, [selected, preset_count](int v) {
        if (v == 0) s.draft.aspect_ratio = 0;
        else if (v <= preset_count) s.draft.aspect_ratio = ios_aspect_presets[v - 1].aspect;
        else if (selected != preset_count + 1) s.draft.aspect_ratio = 1.6f;
    }, ini("AspectRatio"));
    r.back().help = tr("Choose the game's landscape aspect ratio. Device presets use that iPhone or iPad screen shape; Custom lets you enter a ratio.");
    if (selected == preset_count + 1)
        number(r, "aspect", tr("Aspect ratio"), &c.aspect_ratio, lo("AspectRatio"), hi("AspectRatio"), .01f, ini("AspectRatio"));
#else
    add_choice(r, "aspect.auto", "Automatic aspect ratio", c.aspect_ratio == 0 ? 0 : 1, {tr("Auto"), tr("Custom")},
               [](int v) { s.draft.aspect_ratio = v ? 16.f / 9 : 0; }, ini("AspectRatio"));
    if (c.aspect_ratio)
        number(r, "aspect", tr("Aspect ratio"), &c.aspect_ratio, lo("AspectRatio"), hi("AspectRatio"), .05f, ini("AspectRatio"));
#endif
}
void reset_graphics_screen_30() { s.draft.aspect_ratio = config_defaults().aspect_ratio; }
MENU_ENTRY("graphics/screen", 30, rows_graphics_screen_30, reset_graphics_screen_30);
#endif
void rows_graphics_screen_60(std::vector<Row> &r) {
    number(r, "fov", tr("Field of view"), &s.draft.fov, lo("FOV"), hi("FOV"), .05f, ini("FOV"));
}
void reset_graphics_screen_60() { s.draft.fov = config_defaults().fov; }
MENU_ENTRY("graphics/screen", 60, rows_graphics_screen_60, reset_graphics_screen_60);
void rows_graphics_screen_70(std::vector<Row> &r) {
#ifdef MHGU_IOS
    std::vector<std::string> names = {"16:9", "21:9", "32:9", tr("Edges")};
    for (const auto &preset : ios_aspect_presets) names.emplace_back(preset.name);
    int selected = s.draft.ui_anchor <= UI_EDGES ? s.draft.ui_anchor - 1
                                                 : 4 + s.draft.ui_anchor - UI_IPHONE_CLASSIC;
    add_choice(r, "anchor", "HUD anchor", selected, names, [](int v) {
        s.draft.ui_anchor = v < 4 ? v + 1 : UI_IPHONE_CLASSIC + v - 4;
    }, ini("UIAnchor"));
#else
    add_choice(r, "anchor", "HUD anchor", s.draft.ui_anchor - 1, {"16:9", "21:9", "32:9", tr("Edges")},
               [](int v) { s.draft.ui_anchor = v + 1; }, ini("UIAnchor"));
#endif
#ifndef __ANDROID__  // (the values by the menu's names: the ini calls 16:9 Center; a phone's: PHONE_HELP)
#ifdef MHGU_IOS
    r.back().help = tr("Choose how wide the HUD is laid out. iPhone and iPad presets use their landscape screen shape; on a narrower picture the HUD keeps the game's minimum width.");
#else
    r.back().help = tr("On a picture wider than 16:9, how wide the HUD is laid out: 16:9 in the middle, 21:9, 32:9, or Edges for the whole width.");
#endif
#endif
}
void reset_graphics_screen_70() { s.draft.ui_anchor = config_defaults().ui_anchor; }
MENU_ENTRY("graphics/screen", 70, rows_graphics_screen_70, reset_graphics_screen_70);
#ifndef __ANDROID__  // (a desktop's, with the mouse: on a phone the touch layout editor moves them)
void rows_graphics_screen_80(std::vector<Row> &r) {
    action(r, "hud.edit", tr("Move the HUD"), []() {
        touch_hud_edit_begin();  // (it starts once the menu is closed, as the touch layout editor: runtime/touch.cpp)
        request_back.store(true);
    });
    r.back().help = tr("Drag any part of the HUD with the mouse: the clock, health and stamina, the sharpness and gauges, the party, the map, the target camera, the item bar and the Hunter Arts. The wheel over one changes its size; Hide takes it off the screen. Esc cancels; on a controller, the button shown on Cancel.");
}
MENU_ENTRY("graphics/screen", 80, rows_graphics_screen_80);
#endif
void rows_graphics_screen_90(std::vector<Row> &r) {
    add_bool(r, "fill", "Fill the screen", &s.draft.fill_screen, ini("FillScreen"));
}
void reset_graphics_screen_90() { s.draft.fill_screen = config_defaults().fill_screen; }
MENU_ENTRY("graphics/screen", 90, rows_graphics_screen_90, reset_graphics_screen_90);
// Graphics & Audio > Advanced
#ifdef __ANDROID__
void rows_graphics_advanced_20(std::vector<Row> &r) {  // (an Adreno on a Vulkan 1.1 driver: device.c msaa_floor)
    add_choice(r, "adrenofix", "Adreno fix", s.draft.adreno_fix ? 1 : 0, {tr("Auto"), tr("Off")},
               [](int v) { s.draft.adreno_fix = v; }, ini("AdrenoFix"));
}
void reset_graphics_advanced_20() { s.draft.adreno_fix = config_defaults().adreno_fix; }
bool shown_graphics_advanced_20() { return vk_gpu_adreno_fix_applies(); }
MENU_ENTRY("graphics/advanced", 20, rows_graphics_advanced_20, reset_graphics_advanced_20, shown_graphics_advanced_20);
void rows_graphics_advanced_60(std::vector<Row> &r) {
    action(r, "gpu.driver", tr("GPU driver"), []() { ui_request_gpu_driver(); });
    r.back().value = *gpu_driver_name() ? gpu_driver_name() : tr("System");
    r.back().help = tr("Adreno only, at your own risk: load a Vulkan driver of your own. By default the system's is used.");
}
bool shown_graphics_advanced_60() { return vk_gpu_adreno(); }
MENU_ENTRY("graphics/advanced", 60, rows_graphics_advanced_60, {}, shown_graphics_advanced_60);
#else
void rows_graphics_advanced_30(std::vector<Row> &r) {  // [Display] GPU: Automatic, or a device by its name
    const Config &c = s.draft;                                  // (nvn/vulkan/device.c pick_device), at the next start
    const char *names[16];
    int used = -1, n = vk_gpu_list(names, 16, &used), pick = 0;
    bool automatic = !*c.gpu || !SDL_strcasecmp(c.gpu, "Auto");
    std::vector<std::string> list = {tr("Automatic")};
    for (int i = 0; i < n; i++) {
        list.push_back(names[i]);
        if (!automatic && !pick && !SDL_strcasecmp(names[i], c.gpu))
            pick = i + 1;
    }
    if (!automatic && !pick) {  // (one not here now, as the file says it: kept until another is picked)
        list.push_back(fmt("%s (not found)", c.gpu));
        pick = n + 1;
    }
    add_choice(
        r, "gpu", "GPU", pick, list,
        [list, n](int v) {
            if (v <= n)
                SDL_strlcpy(s.draft.gpu, v ? list[v].c_str() : "Auto", sizeof s.draft.gpu);
        },
        ini("GPU"));
    if (!pick && used >= 0 && used < n)  // (Automatic: the one it took)
        r.back().value = std::string(tr("Automatic")) + " (" + names[used] + ")";
    r.back().help = tr("The graphics card the game runs on. Automatic: a dedicated card if there is one.");
}
void reset_graphics_advanced_30() { SDL_strlcpy(s.draft.gpu, config_defaults().gpu, sizeof s.draft.gpu); }
MENU_ENTRY("graphics/advanced", 30, rows_graphics_advanced_30, reset_graphics_advanced_30);
void rows_graphics_advanced_40(std::vector<Row> &r) {
    add_bool(r, "prewarm", "Shader prewarm", &s.draft.shader_prewarm, ini("ShaderPrewarm"));
}
void reset_graphics_advanced_40() { s.draft.shader_prewarm = config_defaults().shader_prewarm; }
MENU_ENTRY("graphics/advanced", 40, rows_graphics_advanced_40, reset_graphics_advanced_40);
#endif

// ---- Gameplay
void rows_gameplay_40(std::vector<Row> &r) {
    add_bool(r, "bonus", "Bonus content", &s.draft.bonus_content, ini("BonusContent"));
}
void reset_gameplay_40() { s.draft.bonus_content = config_defaults().bonus_content; }
MENU_ENTRY("gameplay", 40, rows_gameplay_40, reset_gameplay_40);
// Gameplay > Monster health
void rows_gameplay_health_10(std::vector<Row> &r) {
    Config &c = s.draft;
    for (int i = 0; i < 4; i++)
        number(r, "hp." + std::to_string(i), std::to_string(i + 1) + " " + tr(i == 0 ? "Hunter" : "Hunters"), &c.hp.scale[i],
               lo("1Player"), hi("1Player"), .05f, ini("1Player"));
    number(r, "hp.village", tr("Village quests in Hub"), &c.hp.village, lo("HubHP"), hi("HubHP"), .05f, ini("HubHP"));
#ifndef __ANDROID__  // (a phone: not worth a row)
    const char *per_quest =
        tr("HP multipliers for single quests, by their quest ID: in those quests they are used instead of the ones above.");
    action(r, "hp.advanced", tr("Per-quest overrides"), []() { s.advanced = !s.advanced; });
    r.back().help = per_quest;
    if (s.advanced) {
        for (int i = 0; i < c.hp.quests; i++) {
            auto id = quest_id(i);
            add_number(
                r, id, tr("Quest ID"), [i]() { return (double)s.draft.hp.quest[i].quest; },
                [i](double v) { s.draft.hp.quest[i].quest = (uint32_t)v; }, 1, 4294967295., 1, true, ini("1Player"),
                [i](double v, std::string &e) {
                    for (int j = 0; j < s.draft.hp.quests; j++)
                        if (j != i && s.draft.hp.quest[j].quest == (uint32_t)v) {
                            e = tr("Duplicate quest ID.");
                            return false;
                        }
                    return true;
                });
            for (int n = 0; n < 4; n++)
                number(r, id + "." + std::to_string(n), std::to_string(n + 1) + " " + tr(n == 0 ? "Hunter" : "Hunters"),
                       &c.hp.quest[i].scale[n], HP_SCALE_MIN, HP_SCALE_MAX, .05f, ini("1Player"));
            action(r, id + ".remove", tr("Remove quest"), [i]() {
                for (int j = i; j < s.draft.hp.quests - 1; j++) {
                    s.draft.hp.quest[j] = s.draft.hp.quest[j + 1];
                    s.quest_keys[j] = s.quest_keys[j + 1];
                }
                --s.draft.hp.quests;
                focus(i < s.draft.hp.quests ? quest_id(i) : "hp.add");
            });
        }
        action(
            r, "hp.add", tr("Add quest"),
            []() {
                auto &hp = s.draft.hp;
                uint32_t q = 1;
                bool exists;
                do {
                    exists = false;
                    for (int i = 0; i < hp.quests; i++)
                        if (hp.quest[i].quest == q) {
                            exists = true;
                            ++q;
                            break;
                        }
                } while (exists);
                int i = hp.quests++;
                hp.quest[i].quest = q;
                for (float &v : hp.quest[i].scale)
                    v = 1;
                s.quest_keys[i] = s.next_quest_key++;
                focus(quest_id(i));
            },
            c.hp.quests < HP_QUESTS_MAX);
    }
    for (auto &row : r)
        if (!row.id.compare(0, 6, "quest.") || row.id == "hp.add")
            row.help = per_quest;
#endif
}
void reset_gameplay_health_10() {
    s.draft.hp = config_defaults().hp;
    quest_keys();
}
MENU_ENTRY("gameplay/health", 10, rows_gameplay_health_10, reset_gameplay_health_10);

// ---- Multiplayer: the internet first (a hub server, the default one already set), then the local network
void rows_multiplayer_10(std::vector<Row> &r) {
    header(r, "online.header", tr("Over the internet"));
    server_row(r);
    key_row(r);
    hub_check(r);
}
void reset_multiplayer_10() {
    Config f = config_defaults(), &c = s.draft;
    SDL_strlcpy(c.ldn_server, f.ldn_server, sizeof c.ldn_server);
    SDL_strlcpy(c.ldn_key, f.ldn_key, sizeof c.ldn_key);
}
MENU_ENTRY("multiplayer", 10, rows_multiplayer_10, reset_multiplayer_10, no_crossplay);
// (crossplay on: a line where the hubs' rows were, saying where they went)
MENU_ENTRY("multiplayer", 5, [](std::vector<Row> &r) {
    note(r, "xplay.on", xl("Online play goes through the emulators' rooms or servers: Play with emulators. Choose This app's hubs there to see the hub server and the key again.",
                           "El juego en línea pasa por las salas o servidores de los emuladores: Jugar con emuladores. Elige Las salas de esta app ahí para volver a ver el servidor de salas y la clave."));
}, {}, []() { return s.draft.crossplay != 0; });
// S32, S35 (the chat group's, MENU.md 4b): Share the key in the chat under the hub's rows, then the Chat and Friends
// pages' rows (View::Chat, View::Friends: settings_chat.inc)
MENU_ENTRY("multiplayer", 30, chat_key_rows, {}, no_crossplay);
MENU_ENTRY("multiplayer", 40, chat_entry_rows);
void rows_multiplayer_lan_10(std::vector<Row> &r) {
    Config &c = s.draft;
    number(r, "port", "Host port (TCP / UDP)", &c.ldn_port, (int)lo("Port"), (int)hi("Port"), 1, ini("Port"));
    text(r, "hosts", "Search hosts", c.ldn_join, sizeof c.ldn_join, *c.ldn_join ? c.ldn_join : tr("LAN"), ini("Join"));
}
void reset_multiplayer_lan_10() {
    Config f = config_defaults(), &c = s.draft;
    c.ldn_port = f.ldn_port;
    SDL_strlcpy(c.ldn_join, f.ldn_join, sizeof c.ldn_join);
}
MENU_ENTRY("multiplayer/lan", 10, rows_multiplayer_lan_10, reset_multiplayer_lan_10);
void rows_multiplayer_hub_10(std::vector<Row> &r) {
    add_bool(r, "sync", "Sync small monsters", &s.draft.sync_small_monsters, ini("SyncSmallMonsters"));
    add_bool(r, "village", "Village quests in Hub", &s.draft.village_in_hub, ini("VillageQuestsInHub"));
}
void reset_multiplayer_hub_10() {
    Config f = config_defaults();
    s.draft.sync_small_monsters = f.sync_small_monsters;
    s.draft.village_in_hub = f.village_in_hub;
}
MENU_ENTRY("multiplayer/hub", 10, rows_multiplayer_hub_10, reset_multiplayer_hub_10);
#ifndef __ANDROID__  // (Discord's Rich Presence is its desktop app's; Reset never put these back)
void rows_multiplayer_discord_10(std::vector<Row> &r) {
    add_bool(r, "discord", "Discord Rich Presence", &s.draft.discord, ini("RichPresence"));
    add_bool(r, "discord.hunter", "Show hunter name and HR", &s.draft.discord_hunter, ini("ShowHunter"));
}
MENU_ENTRY("multiplayer/discord", 10, rows_multiplayer_discord_10);
#endif

// ---- Mods & Cheats
void rows_mods_list_10(std::vector<Row> &r) {
    mods_rows(r);
    for (Row &row : r)  // (what the tab's note said: now each mod's help)
        if (!row.id.compare(0, 4, "mod.") && row.help.empty())
            row.help = tr("Mods load from top to bottom: a later mod wins. Select a conflict to choose which mod is used. Press Save, then restart.");
}
void reset_mods_list_10() {
    for (auto &m : mods.draft)
        m.on = m.name[0] != '_';
    std::sort(mods.draft.begin(), mods.draft.end(),
              [](const ModEntry &a, const ModEntry &b) { return strcasecmp(a.name, b.name) < 0; });
}
MENU_ENTRY("mods/list", 10, rows_mods_list_10, reset_mods_list_10);
// S44 (the mods group's): Forge's menu, one row on the section's page where Forge ›'s link would be (MENU.md 3.5), shown
// while a Forge plugin runs
MENU_ENTRY("mods", 40, forge_menu_row);
// S26 (the gfx group's): this game's HD texture packs are romfs mods (.tex files): a note on Texture packs says so
MENU_ENTRY("mods/textures", 10, [](std::vector<Row> &r) {
    note(r, "textures.how",
         en_es("This game's texture packs are mods: add one with Add a mod, in Mods, as any other. Each texture takes memory as it's drawn.",
               "Los packs de texturas de este juego son mods: agrega uno con Agregar un mod, en Mods, como cualquier otro. Cada textura ocupa memoria al dibujarse."));
});
void rows_mods_cheats_10(std::vector<Row> &r) {
    note(r, "cheats.online", tr("Online: only use cheats when everyone in the lobby agrees to it."));
    r.back().warn = true;
    cheat_rows(r);
    for (Row &row : r)  // (the tab's note: now each cheat's help, after its file)
        if (!row.id.compare(0, 6, "cheat."))
            row.help += (row.help.empty() ? "" : "\n") +
                        std::string(tr("Cheats turn on and off when you press Save, no restart needed. Turning one off undoes its changes to the game's code; values it already changed (money, items) stay. New cheat files show up after a restart."));
}
void reset_mods_cheats_10() {
    for (int i = 0; i < (int)cheat_tab.draft.size(); ++i)
        cheat_tab.draft[i] = !cheats_dropped(i);  // (a removed file's stay off)
}
MENU_ENTRY("mods/cheats", 10, rows_mods_cheats_10, reset_mods_cheats_10);

// ---- System
void rows_system_10(std::vector<Row> &r) {
    add_choice(r, "language", "Language", s.draft.language, {"English", "Español"}, [](int v) { s.draft.language = v; },
               ini("Language"));
}
void reset_system_10() { s.draft.language = config_defaults().language; }
MENU_ENTRY("system", 10, rows_system_10, reset_system_10);
void rows_system_50(std::vector<Row> &r) {
    add_bool(r, "pause.bg", "Pause in the background", &s.draft.pause_background, ini("PauseInBackground"));
#ifndef __ANDROID__  // (a desktop's background: the window minimized, host_input.c)
    r.back().help = tr("The game stops while its window is minimized, and goes on where it was when you bring it back.");
#endif
#ifdef __ANDROID__  // (runtime/overlay.cpp)
    add_bool(r, "pause.menu", "Pause in this menu", &s.draft.pause_menu, ini("PauseInMenu"));
#endif
}
void reset_system_50() {
    Config f = config_defaults();
    s.draft.pause_background = f.pause_background;
    s.draft.pause_menu = f.pause_menu;
}
MENU_ENTRY("system", 50, rows_system_50, reset_system_50);
void rows_system_70(std::vector<Row> &r) {
#ifdef __ANDROID__  // (the app's start asks GitHub, android/.../Notices.java; a PC has no such check yet)
    add_bool(r, "updates", "Check for updates", &s.draft.updates, ini("Updates"));
#else  // (a phone: not worth a row)
    add_bool(r, "confirm.exit", "Confirm exit", &s.draft.confirm_exit, ini("ConfirmExit"));
#endif
}
void reset_system_70() {
    Config f = config_defaults();
    s.draft.updates = f.updates;
    s.draft.confirm_exit = f.confirm_exit;
}
MENU_ENTRY("system", 70, rows_system_70, reset_system_70);
void rows_system_90(std::vector<Row> &r) {
    header(r, "app.head", tr("The app"));
    action(r, "restart", tr("Restart"), []() { push(View::Restart, "dialog.cancel"); });
    action(r, "exit", tr("Exit game"), []() { push(View::Exit, "dialog.cancel"); });
#ifdef __ANDROID__  // (as the header's X: unsaved changes asked about first)
    action(r, "back.game", tr("Back to the game"), []() { request_back.store(true); });
#endif
}
MENU_ENTRY("system", 90, rows_system_90);
// System > This menu
void rows_system_menu_10(std::vector<Row> &r) {
    Config &c = s.draft;
    {  // (on a phone too, listed as in the MH4U port: Hunter, Gold, Blue; the file keeps its own order, THEME_*)
        static const int themes[] = {THEME_HUNTER, THEME_GOLD, THEME_BLUE};
        int pick = 0;
        for (int i = 0; i < 3; i++)
            if (themes[i] == c.menu_theme)
                pick = i;
        add_choice(r, "theme", "Menu colours", pick, {tr("Hunter"), tr("Gold"), tr("Blue")},
                   [](int v) { s.draft.menu_theme = themes[v]; }, ini("Theme"));
    }
    number(r, "scale", "Menu size", &c.menu_scale, (int)lo("MenuScale"), (int)hi("MenuScale"), 10, ini("MenuScale"));
    r.back().value = std::to_string(c.menu_scale) + "%";
    if (!touch_ui()) {  // (the phone's menu fills the screen: nothing to move)
        action(r, "detach", tr(s.floating ? "Attach menu" : "Detach menu"), []() {
            s.floating = !s.floating;
            if (!s.floating)
                s.custom_size = ImVec2(0, 0);
        });
        r.back().help =
            tr(s.floating ? "Puts the menu back at the top of the screen, at its usual size."
                          : "Lets the menu go anywhere on the screen: use Move menu, or drag its tabs with the mouse. Its bottom right corner sizes it.");
    }
    if (s.floating && !touch_ui())
        action(r, "move", tr("Move menu"), []() {
            auto *w = ImGui::GetCurrentWindow();
            s.move_start = s.move_position = w->Pos;
            push(View::Move, "move.accept");
        });
}
void reset_system_menu_10() {
    Config f = config_defaults();
    s.draft.menu_theme = f.menu_theme;
    s.draft.menu_scale = f.menu_scale;
}
MENU_ENTRY("system/menu", 10, rows_system_menu_10, reset_system_menu_10);
// System > Your game > Verify game files (runtime/verify.c; the MH4U port's same view and words): while it runs, its
// progress, Cancel and Back (it goes on with the menu closed); then its report: what was found, what to do, Check again
bool verify_busy(const VerifyState &v) { return v.stage == VERIFY_LISTING || v.stage == VERIFY_READING; }
std::string verify_number(const char *v) {  // (Spanish: 4,1 GB)
    std::string out = v;
    if ((s.editing ? s.draft.language : config_language()) == 1)
        for (char &c : out)
            if (c == '.') c = ',';
    return out;
}
std::string verify_value() {
    VerifyState v = verify_state();
    if (verify_busy(v))
        return std::to_string(v.bytes_total ? (int)(v.bytes_done * 100 / v.bytes_total) : 0) + " %";
    if (v.stage == VERIFY_CANCELLED) return tr("Cancelled");
    if (v.stage == VERIFY_DONE || v.stage == VERIFY_FAILED)
        return v.problems == 0 ? tr("All good") : v.problems == 1 ? tr("1 problem") : fmt("%d problems", v.problems);
    return "";
}
void verify_open() {
    VerifyState v = verify_state();
    if (v.stage == VERIFY_NONE || v.stage == VERIFY_CANCELLED || v.stage == VERIFY_FAILED) verify_start();
    bool busy = verify_busy(verify_state());
    push(View::Verify, busy ? "verify.cancel" : "verify.again");
    if (!busy) s.focus_request = false;  // (a report opens at its top, the verdict, not scrolled to its last rows)
}
void verify_rows(std::vector<Row> &r) {
    VerifyState v = verify_state();
    if (verify_busy(v)) {
        std::string text = tr("Listing the files...");
        float done = 0;
        if (v.stage == VERIFY_READING && v.bytes_total) {
            char a[24], b[24];
            snprintf(a, sizeof a, "%.1f", v.bytes_done / 1e9), snprintf(b, sizeof b, "%.1f", v.bytes_total / 1e9);
            done = (float)((double)v.bytes_done / v.bytes_total);
            text = fmt("Reading the files: %s of %s GB (%d %%)", verify_number(a).c_str(), verify_number(b).c_str(), (int)(done * 100));
            if (v.seconds >= 5 && v.bytes_done) {
                double left = v.seconds * (double)(v.bytes_total - v.bytes_done) / (double)v.bytes_done;
                text += left >= 90 ? fmt(" · about %d min left", (int)std::ceil(left / 60)) : std::string(tr(" · less than 2 min left"));
            }
        }
        note(r, "verify.progress", text);
        r.back().progress = done;
        note(r, "verify.wait", tr("You can leave this page or close the menu: the check goes on."));
        action(r, "verify.cancel", tr("Cancel"), []() { verify_cancel(); });
        action(r, "verify.back", tr("Back"), []() { pop(); });
        return;
    }
    if (s.focus == "verify.cancel")  // (it ended under the cursor: the report stays at its top)
        s.focus = "verify.again", s.focus_request = false, s.focus_scroll_frames = 0;
    std::vector<VerifyLine> lines(std::max(verify_lines(nullptr, 0), 1));
    lines.resize(std::min((int)lines.size(), verify_lines(lines.data(), (int)lines.size())));
    header(r, "verify.verdict", v.stage == VERIFY_CANCELLED ? tr("Check cancelled")
                                : v.problems == 0       ? tr("All good: your game files are right")
                                : v.problems == 1       ? tr("1 problem found")
                                                        : fmt("%d problems found", v.problems));
    // (a finding's example files go under its own text; what to do, under its header)
    std::vector<std::pair<std::string, int>> found, todo;
    for (const VerifyLine &l : lines) {
        std::string text = fmt(l.text, verify_number(l.a).c_str(), verify_number(l.b).c_str());
        if (l.kind == VL_FILE) {
            if (!found.empty()) found.back().first += "\n" + fmt(l.text, l.a, l.b);
        } else if (l.kind == VL_TODO) {
            todo.push_back({text, l.kind});
        } else {
            found.push_back({text, l.kind});
        }
    }
    for (size_t i = 0; i < found.size(); i++) {
        note(r, "verify.line" + std::to_string(i), found[i].first);
        r.back().warn = found[i].second == VL_PROBLEM;
        r.back().bright = found[i].second == VL_OK || found[i].second == VL_PROBLEM;
    }
    if (!todo.empty()) {
        header(r, "verify.todo", tr("What to do"));
        for (size_t i = 0; i < todo.size(); i++)
            note(r, "verify.todo" + std::to_string(i), todo[i].first), r.back().bright = true;
    }
    note(r, "verify.log", tr("The full list is in the log: System › Your game › Share log."));
    action(r, "verify.again", tr("Check again"), []() {
        verify_start();
        focus("verify.cancel");
    });
    action(r, "verify.back", tr("Back"), []() { pop(); });
}
void verify_row(std::vector<Row> &r) {
    action(r, "game.verify", tr("Verify game files"), []() { verify_open(); });
    r.back().value = verify_value();
    r.back().help = tr("Reads every game file and compares it with the version the port needs: says what is missing, cut short, changed or from another version, and what to do. It can take a few minutes; it changes and downloads nothing.");
}
// System > Your game (the MH4U port's same rows)
void rows_system_game_10(std::vector<Row> &r) {
#ifdef __ANDROID__
    action(r, "game.folder", tr("Game folder"), []() { ui_request_game_folder(); });
    r.back().help = tr("Where the game's exefs and romfs are read from. A new folder is used the next time the game starts.");
    verify_row(r);
    action(r, "save.folder", tr("Save folder"), []() { ui_request_save_folder(); });
    r.back().help = tr("Where your save is kept. Choose a folder that a sync app shares with your other devices (the PC version too) to carry your hunt between them. Your save is copied there first, and the game restarts to use it.");
    action(r, "save.import", tr("Import save"), []() { ui_request_save_import(); });
    r.back().help = tr("Brings your save from an emulator or another device. It replaces the characters on this device, and the current save is kept in a copy.");
    action(r, "save.export", tr("Export save"), []() { ui_request_save_export(); });
    r.back().help = tr("Copies your save to a folder you choose, to take it to an emulator or another device.");
    action(r, "log.share", tr("Share log"), []() { ui_request_share_log(); });
    r.back().help = tr("Sends the game's log to the app you choose, for whoever is helping you with a problem.");
#else  // (a desktop: the system's dialogs, runtime/pc_actions.c; the licenses are on Credits & Licenses)
    action(r, "game.folder", tr("Game folder"), []() { ui_request_game_folder(); });
    r.back().help = tr("Where the game's exefs, romfs and mhgugame.dll are read from. A new folder is used the next time the game starts.");
    verify_row(r);
    action(r, "save.import", tr("Import save"), []() { ui_request_save_import(); });
    r.back().help = tr("Brings your save from an emulator or another device: choose its file named system. It replaces the characters here, and the current save is kept in a copy.");
    action(r, "save.export", tr("Export save"), []() { ui_request_save_export(); });
    r.back().help = tr("Copies your save to a folder you choose, to take it to an emulator or another device.");
#if defined(__APPLE__)
    action(r, "log.share", tr("Share log"), []() { ui_request_share_log(); });
    r.back().help = tr("Opens the iOS share sheet for the game's logs. Choose Save to Files or another app to send them.");
#else
    action(r, "log.open", tr("Log folder"), []() { ui_request_share_log(); });
    r.back().help = tr("Opens the folder with log.txt, the game's log, to send it to whoever is helping you with a problem.");
#endif
#endif
}
MENU_ENTRY("system/game", 10, rows_system_game_10);

// ---- Credits & Licenses: who made it, where the official one is, the licences and the legal notice: shown, as in the
// MH4U port, not in a help
// 1.0's credits (MENU.md 3.7: one note each, under who made it): tabarong's designs (the layout and chat groups), the
// builder's idea (builder_credit_rows, Android), Alfonso's (the qol group)
void credits_10_rows(std::vector<Row> &r) {
    note(r, "about.tabarong",
         en_es("The control profiles, the chat, the friends and the room keys follow the designs of tabarong (Discord; GitHub: oliveaglien).",
               "Los perfiles de controles, el chat, los amigos y las claves de sala siguen los diseños de tabarong (Discord; GitHub: oliveaglien)."));
    builder_credit_rows(r);
    note(r, "about.alfonso", en_es("Sending all the rewards to the box at once: Alfonso's idea.",
                                   "Mandar todas las recompensas a la caja de una vez: idea de Alfonso."));
}
void rows_about_10(std::vector<Row> &r) {
    header(r, "about.head", std::string(app_title()) + " " + MHGU_VERSION);
    note(r, "about.by", tr("Made by khorne-hub. Free."));
    note(r, "about.site", std::string(tr("Official download:")) + " github.com/khorne-hub/gu-native");
    note(r, "about.base", tr("Based on MHGURecomp."));
    note(r, "about.4u", std::string(tr("Also by khorne-hub: MH4U for Android,")) + " github.com/khorne-hub/4u-native");
    credits_10_rows(r);
#ifdef __ANDROID__
    note(r, "about.legal", tr("This app includes no game code, files, ROMs or keys: you need your own copy of the game. Not affiliated with the Great C or the Great N."));
#else
    note(r, "about.legal", tr("This program includes no game code, files, ROMs or keys: you need your own copy of the game. Not affiliated with the Great C or the Great N."));
#endif
    note(r, "about.paid", tr("Only the links khorne-hub gives are official. If you got it anywhere else, paid for it, or it came with ads, it is not the official one."));
    action(r, "credits", tr("Show the credits"), []() { credits_show(); });
    r.back().help = tr("Shows again the credits that appear when the app opens.");
#ifdef __ANDROID__
    action(r, "licenses", tr("Licenses"), []() { ui_request_licenses(); });
    r.back().help = tr("The licenses of the software this app is made with, and the legal notice: this app includes no game code, files, ROMs or keys, you need your own copy of the game, and it is not affiliated with the Great C or the Great N.");
#else  // (a desktop: the menu's own page, the legal notice first: licenses_text)
    action(r, "licenses", tr("Licenses"), []() { push(View::Licenses, "dialog.cancel"); });
    r.back().help = tr("The legal notice and the licenses of the software this program is made with: it includes no game code, files, ROMs or keys, you need your own copy of the game, and it is not affiliated with the Great C or the Great N.");
#endif
    header(r, "about.thanks", tr("Thank you"));
    note(r, "thanks.body", tr(THANKS_TEXT));
    note(r, "thanks.sign", thanks_signature());
    action(r, "thanks", tr("Show the thanks"), []() { thanks_show(); });
    r.back().help = tr("Shows the thank-you again, as it showed the first time the game opened.");
}
MENU_ENTRY("about", 10, rows_about_10);

// ---------------------------------------------------------------- a page's rows
const MenuPage *find_page(const std::string &id) {
    for (const MenuPage &p : menu_pages())
        if (id == p.id)
            return &p;
    return nullptr;
}
bool entry_shown(const MenuEntry &e) { return !e.shown || e.shown(); }
// A page with something on it: an entry that shows, or a page under it that has (its row: none on an empty one)
bool page_live(const std::string &id) {
    for (const MenuEntry &e : menu_entries())
        if (id == e.page && entry_shown(e))
            return true;
    for (const MenuPage &p : menu_pages())
        if (id == p.parent && (!p.shown || p.shown()) && page_live(p.id))
            return true;
    return false;
}
// The page shown now: a section's own, or the one one level down
std::string current_page() { return s.view == View::Page ? s.at : std::string(page_ids[s.page]); }
// A page's title: a section's name, else its own (English: tr)
const char *page_title(const std::string &id) {
    for (int i = 0; i < PAGES; i++)
        if (id == page_ids[i])
            return page_names[i];
    const MenuPage *p = find_page(id);
    return p ? p->title : "";
}
// "Section › Page" (one level down), or the section's name
std::string page_path(const std::string &id) {
    const MenuPage *p = find_page(id);
    if (!p)
        return tr(page_title(id));
    return std::string(tr(page_title(p->parent))) + "  \xE2\x80\xBA  " + tr(p->title);
}
void open_page(const std::string &id) {
    push(View::Page, "");
    s.at = id;
}
// Its entries' rows and the rows of the pages under it, by their order (the same order: in the order they were placed)
std::vector<Row> page_rows(const std::string &id) {
    struct Item {
        int order;
        const MenuEntry *entry;
        const MenuPage *page;
    };
    std::vector<Item> items;
    for (const MenuEntry &e : menu_entries())
        if (id == e.page && entry_shown(e))
            items.push_back({e.order, &e, nullptr});
    for (const MenuPage &p : menu_pages())
        if (id == p.parent && (!p.shown || p.shown()) && page_live(p.id))
            items.push_back({p.order, nullptr, &p});
    std::stable_sort(items.begin(), items.end(), [](const Item &a, const Item &b) { return a.order < b.order; });
    std::vector<Row> r;
    for (const Item &it : items) {
        if (it.entry) {
            it.entry->rows(r);
            continue;
        }
        const std::string to = it.page->id;
        action(r, "page." + to, tr(it.page->title), [to]() { open_page(to); });
        if (it.page->link)
            it.page->link(r.back());
    }
    return r;
}
std::vector<Row> main_rows() {
    const std::string id = current_page();
    std::vector<Row> r = page_rows(id);
    if (!touch_ui() || SDL_HasGamepad())  // (a finger has the header's Save; a controller can't reach that one)
        action(r, "save", tr("Save"), []() { s.command = Command::Save; }, dirty());
    if (s.page != ABOUT_PAGE)  // (Credits & Licenses: nothing to reset)
        action(r, "reset", tr(s.view == View::Page ? "Reset this page" : "Reset this section"), [id]() {
            s.reset_at = id;
            push(View::Reset, "dialog.cancel");
        });
    return r;
}
bool save() {
    if (pending_text()) {
        std::string error;
        if (!s.keyboard.commit(s.keyboard.buffer, error)) {
            while (s.view != View::Keyboard && !s.origins.empty())
                pop();
            s.error = error;
            return false;
        }
        s.keyboard.original = s.keyboard.buffer;
    }
    remember_typed(s.draft, s.saved);
    char error[512];
    if (!config_save(&s.draft, error, sizeof error)) {
        s.error = settings_text(s.draft.language, error);
        return false;
    }
    crossplay_saved(s.saved, s.draft);  // (a room or server no longer used is left)
    if (mods_dirty()) {
        if (!mods_save_order(mods.draft.data(), (int)mods.draft.size(), error, sizeof error)) {
            s.error = settings_text(s.draft.language, error);
            return false;
        }
        mods.saved = mods.draft;
    }
    if (cheats_dirty()) {
        std::unique_ptr<bool[]> on(new bool[cheat_tab.draft.size() + 1]);
        for (size_t i = 0; i < cheat_tab.draft.size(); ++i)
            on[i] = cheat_tab.draft[i] != 0;
        if (!cheats_set(on.get(), (int)cheat_tab.draft.size(), error, sizeof error)) {
            s.error = settings_text(s.draft.language, error);
            return false;
        }
        cheat_tab.saved = cheat_tab.draft;
    }
    if (std::lround(s.chat_panel_size_draft * 100.f) != std::lround(s.chat_panel_size_saved * 100.f)) {
        chat_panel_size(s.chat_panel_size_draft);
        s.chat_panel_size_saved = s.chat_panel_size_draft;
    }
    s.saved = s.draft;
    s.saved_notice = true;
    s.error.clear();
    return true;
}
#ifndef __ANDROID__
// The player opened the menu: the notice at the start that says how (overlay.cpp menu_hint) is done with.
// [Application] MenuHintSeen goes into the file now, with the settings as saved: the ones about to be edited are saved
// or not later, as the player chooses.
void menu_hint_seen() {
    Config c = s.saved;
    c.menu_hint_seen = 1;
    char error[512];
    if (!config_save(&c, error, sizeof error)) {
        fprintf(stderr, "[settings] MenuHintSeen could not be saved: %s\n", error);
        return;
    }
    s.draft.menu_hint_seen = s.saved.menu_hint_seen = 1;
    fprintf(stderr, "[settings] the menu was opened: MenuHintSeen = On, no notice at the next start\n");
}
#endif
// Which of the game's buttons are on the screen, and the player's own
const char *const TB_TITLES[TB_COUNT] = {"Attacks (A / X)", "Evade (B)", "Guard / dash (R)", "Sheathe (Y)", "Game menu (+)", "Minus (-)", "D-pad",
                                         "Camera (L)", "Target (ZL)", "ZR", "Left stick click (L3)", "Right stick click (R3)", "Movement stick",
                                         "Layout for bows and bowguns", "Fire / shoot", "Reload / melee", "Aim",
                                         "Crouching fire / coating", "Ammo arrows", "Item bar arrows", "ZL in menus", "ZR in menus",
                                         "Menu pad", "Run with the stick", "Keep guarding while sliding", "Lock-on button", "Floating stick",
                                         "L and R in menus", "D-pad in menus", "Hunter Arts with a controller"};
const char *const TB_KEYS[TB_COUNT] = {"ShowAttacks", "ShowDodge", "ShowGuard", "ShowSheathe", "ShowPlus", "ShowMinus", "ShowDpad",
                                       "ShowL", "ShowZL", "ShowZR", "ShowL3", "ShowR3", "ShowStick", "ShowRanged", "ShowFire",
                                       "ShowSecond", "ShowAim", "ShowRangedSpecial", "ShowAmmo", "ShowItemArrows", "ShowMenuZL",
                                       "ShowMenuZR", "ShowMenuPad", "StickRun", "GuardSlide", "ShowLockOn", "FloatingStick",
                                       "ShowMenuLR", "DpadInMenus", "ArtsWithController"};
// (their rows' order: each way of a button by it - keeping the guard by Guard, the run and the floating stick by the stick,
// the D-pad in menus by the D-pad -, the menu pad before the tabs that go with it; the Hunter Arts' taps with a controller
// last, a controller's way. The floating stick and the Arts' taps have rows of their own elsewhere: tb_elsewhere)
const int TB_ORDER[TB_COUNT] = {TB_ATTACKS, TB_DODGE, TB_GUARD, TB_GUARD_SLIDE, TB_SHEATHE, TB_PLUS, TB_MINUS, TB_DPAD,
                                TB_DPAD_MENUS, TB_L, TB_ZL, TB_LOCKON, TB_ZR, TB_L3, TB_R3, TB_STICK, TB_FLOAT_STICK, TB_STICK_RUN,
                                TB_RANGED, TB_FIRE, TB_SECOND, TB_AIM, TB_RSPECIAL, TB_AMMO, TB_ITEM_ARROWS, TB_MENU_PAD, TB_MENU_LR,
                                TB_MENU_ZL, TB_MENU_ZR, TB_ARTS_PAD};
static_assert(TB_COUNT == 30, "TB_ORDER: a place for each of the touch settings");
int s_combo;  // the combined button being edited
void touch_button_rows(std::vector<Row> &r) {
    Config &c = s.draft;
    bool fingers = touch_rows() && !s_combos_alone;  // (none: the combined buttons alone, for a controller's button or a key)
    if (fingers) {
        header(r, "tb.head", tr("Buttons on the screen"));
        for (int n = 0; n < TB_COUNT; n++) {
            int i = TB_ORDER[n];
            if (tb_elsewhere(i)) continue;  // (a row of its own elsewhere in the menu)
            add_bool(r, ("tb." + std::to_string(i)).c_str(), TB_TITLES[i], &c.touch_show[i], nullptr);
            r.back().key = TB_KEYS[i];
            if (i == TB_MINUS)  // (both platforms: the default ini's says only what the buttons are)
                r.back().help = tr("The game's Minus, in a hunt. While it is off, the menu pad has a small Minus below it: the item box opens its other sections with it.");
            if (i == TB_DPAD)  // (both platforms, the MH4U port's words: the menu pad takes its place, touch.cpp under_mpad)
                r.back().help = tr("The D-pad during a hunt. In the game's menus the menu pad takes its place, unless D-pad in menus is on.");
            // (S08: the menus' and a controller's ways, each with its own words; the MH4U port's the same but the Arts')
            if (i == TB_DPAD_MENUS)
                r.back().help = tr("On: the D-pad stays on the screen in the game's menus too, beside the menu pad, and moves their cursor. Off: the menu pad takes its place while a menu is open.");
            if (i == TB_MENU_LR)
                r.back().help = tr("The menu pad's L and R tabs above it, which turn the menus' pages (ZL and ZR when the game's options turn pages with them). Off: the menu pad without them.");
            if (i == TB_ARTS_PAD)
                r.back().help = tr("With a controller connected (the touch controls hidden), a tap on a Hunter Art's panel performs it, with what your Control Type uses for it. Off: the panel takes no taps then.");
#ifndef __ANDROID__  // (the default ini says nothing of these two; a phone's: PHONE_HELP)
            if (i == TB_MENU_ZL)
                r.back().help = tr("With the menu pad, a ZL tab above its left one (L when the game turns pages with ZL and ZR). Some menus use it to change sections or show more information: the item box, the smithy.");
            if (i == TB_MENU_ZR)
                r.back().help = tr("With the menu pad, a ZR tab above its right one (R when the game turns pages with ZL and ZR). Some menus use it to change sections or show more information: the item box, the smithy.");
#endif
        }
    }
    if (fingers) {
        Row row;
        row.id = "tb.chat", row.title = tr("Chat bubble");
        const bool on = chat_bubble_shown();
        row.value = on ? tr("On") : tr("Off"), row.toggle = on ? 1 : 0;
        row.help = tr("Show the co-op chat shortcut on the screen. Turn it off when you play solo.");
        row.activate = []() { chat::set_bubble_shown(!chat_bubble_shown()); };
        row.adjust = [](int d) { chat::set_bubble_shown(d > 0); };
        r.push_back(std::move(row));
    }
    header(r, "tc.head", tr("Combined buttons"));
    for (int k = 0; k < TOUCH_COMBOS; k++) {
        action(r, "tc." + std::to_string(k), fmt("Button %d", k + 1), [k]() {
            s_combo = k;
            push(View::ComboEdit, "ce.0");
        });
        r.back().value = c.touch_combo[k][0] ? c.touch_combo[k] : tr("Empty");
        if (!fingers)
#ifdef __ANDROID__  // (no Keybinds on a phone)
            r.back().help = tr("A button of your own presses several of the game's together. Give it a controller's button here.");
#else
            r.back().help = tr("A button of your own presses several of the game's together. Give it a controller's button here, or a key in Keybinds.");
#endif
    }
    if (fingers)
        r.back().help = tr("A button of your own presses several of the game's together. Place it with Customize controls and HUD.");
    action(r, "tb.back", tr("Back"), []() { pop(); });
}
// ---- the control profiles (S12, after tabarong's design; the 1.0 layout group's): the Controls page's link to them
// (control_profile_row), their page (View::Profiles: the ten slots) and a slot's (View::ProfileSlot: Use, Save the current
// layout here, New of either kind, Edit, Clear). Each acts at once on the layout in use (runtime/touch.cpp
// touch_profile_*), not on the menu's settings; replacing or emptying a slot asks for a second tap. The layout editor's
// Profile window does the same. The MH4U port's the same rows and texts
int s_profile = 1;        // the slot View::ProfileSlot shows
std::string s_prof_arm;   // the row tapped once that a second tap confirms ("" none)
std::string s_prof_said;  // what the last action did (a note under the rows)
std::string profile_what(int n) {
    int kind = touch_profile_kind(n);
    std::string t = tr(kind < 0 ? "Empty" : kind == 1 ? "Emulator style" : "Ours");
    if (n == touch_profile_active()) t += std::string("  \xC2\xB7  ") + tr("In use");
    return t;
}
// The players' own pictures for the touch buttons (S06, the 1.0 layout group's): the screen that copies them in
// (Android's PicturesActivity, a desktop's file dialog: runtime/pc_actions.c); the layout editor's Picture puts one on
// a button. The MH4U port's the same row
void button_images_row(std::vector<Row> &r) {
    action(r, "touch.images", tr("Button images"), []() { ui_request_pictures(); });
    r.back().help = tr("Copy pictures of your own (PNG, JPG or WebP) to put on the touch buttons, then pick one in the layout editor with Picture. What you add is your own responsibility.");
}
void control_profile_row(std::vector<Row> &r) {
    action(r, "touch.profiles", tr("Control profiles"), []() {
        s_prof_said.clear();
        push(View::Profiles, "pf.1");
    });
    int n = touch_profile_active(), kind = touch_profile_kind(n);
    r.back().value = fmt(kind == 1 ? "Profile %d: emulator style" : "Profile %d: ours", n);
    r.back().help = tr("Ten slots, each a whole layout of the touch controls and the HUD: the port's own or an emulator-style one. Use one, save the one you play with in another, or edit it. A design by tabarong.");
}
void profile_rows(std::vector<Row> &r) {
    for (int n = 1; n <= 10; n++) {
        action(r, "pf." + std::to_string(n), fmt("Profile %d", n), [n]() {
            s_profile = n, s_prof_arm.clear(), s_prof_said.clear();
            push(View::ProfileSlot, "ps.use");
        });
        r.back().value = profile_what(n);
    }
    note(r, "pf.where", tr("Kept in the \"layout profiles\" folder of your save folder (or of the app's), with your saves."));
    action(r, "pf.back", tr("Back"), []() { pop(); });
}
void profile_slot_rows(std::vector<Row> &r) {
    int n = s_profile, active = touch_profile_active(), kind = touch_profile_kind(n);
    bool used = kind >= 0, in_use = n == active;
    note(r, "ps.what", profile_what(n));
    // (an action that replaces or empties a slot: a first tap arms it, its title says to tap again)
    auto armed = [&r](const char *id, const char *title, const char *again, bool ask, std::function<bool()> fn,
                      const char *done) {
        bool on = s_prof_arm == id;
        action(r, id, tr(on ? again : title), [id = std::string(id), ask, fn, done]() {
            if (ask && s_prof_arm != id) {
                s_prof_arm = id;
                return;
            }
            s_prof_arm.clear();
            s_prof_said = tr(fn() ? done : "It couldn't be done. Is the save folder there?");
        });
    };
    action(r, "ps.use", tr("Use"), [n]() {
        s_prof_arm.clear();
        s_prof_said = tr(touch_profile_use(n) ? "In use" : "It couldn't be done. Is the save folder there?");
    }, used && !in_use);
    r.back().help = tr("Play with this profile's layout from now on.");
    armed("ps.save", "Save the current layout here", "Tap again to replace it", used && !in_use, [n]() { return touch_profile_store(n); },
          "Saved");
    r.back().help = tr("The layout you play with now goes into this profile, which is the one in use from then on.");
    armed("ps.new", "New: ours", "Tap again to start it over", used, [n]() { return touch_profile_new(n, 0); }, "In use");
    armed("ps.emu", "New: emulator style", "Tap again to start it over", used, [n]() { return touch_profile_new(n, 1); }, "In use");
    r.back().help = tr("Each button presses only its own button of the game's, as an emulator's pad on the screen, laid out the same way. Move, resize and hide each one in the editor.");
    action(r, "ps.edit", tr("Edit"), [n, in_use]() {
        if (!in_use && !touch_profile_use(n)) {
            s_prof_said = tr("It couldn't be done. Is the save folder there?");
            return;
        }
#ifndef __ANDROID__
        if (!touch_screen()) touch_hud_edit_begin();  // (no touch screen: the HUD editor, worked with the mouse)
        else
#endif
            touch_edit_begin();  // (it starts once the menu is closed)
        request_back.store(true);
    }, used);
    r.back().help = tr("Opens the layout editor on this profile: it is the one in use from then on.");
    armed("ps.clear", "Clear", "Tap again to empty it", true, [n]() { return touch_profile_clear(n); }, "Emptied");
    r.back().enabled = used && !in_use;
    if (!s_prof_said.empty()) note(r, "ps.said", s_prof_said);
    action(r, "ps.back", tr("Back"), []() { s_prof_arm.clear(), pop(); });
}
// The layout group's places on the menu (MENU.md 3.1): the profiles' link on Controls (a desktop with no touch screen too:
// its profiles hold the HUD, which Move the HUD edits), the pictures and the floating stick on Touch controls
bool profiles_shown() {
#ifdef __ANDROID__
    return touch_rows();
#else
    return true;
#endif
}
MENU_ENTRY("controls", 20, control_profile_row, {}, profiles_shown);
void rows_controls_touch_60(std::vector<Row> &r) {
    add_bool(r, "touch.float", "Floating stick", &s.draft.touch_show[TB_FLOAT_STICK], ini("FloatingStick"));
}
void reset_controls_touch_60() { s.draft.touch_show[TB_FLOAT_STICK] = config_defaults().touch_show[TB_FLOAT_STICK]; }
MENU_ENTRY("controls/touch", 60, rows_controls_touch_60, reset_controls_touch_60);
MENU_ENTRY("controls/touch", 70, button_images_row);
// The input group's (S08): the Hunter Arts' taps with a controller on Controls > Controller (MENU.md 3.1); the menu pad's
// L and R and the D-pad in menus stay in Buttons on the screen
void rows_controls_pad_150(std::vector<Row> &r) {
    add_bool(r, "tb.arts", "Hunter Arts with a controller", &s.draft.touch_show[TB_ARTS_PAD], ini("ArtsWithController"));
    r.back().help = tr("With a controller connected (the touch controls hidden), a tap on a Hunter Art's panel performs it, with what your Control Type uses for it. Off: the panel takes no taps then.");
}
void reset_controls_pad_150() { s.draft.touch_show[TB_ARTS_PAD] = config_defaults().touch_show[TB_ARTS_PAD]; }
MENU_ENTRY("controls/pad", 150, rows_controls_pad_150, reset_controls_pad_150, touch_rows);
void combo_rows(std::vector<Row> &r) {
    static const char *const NAMES[16] = {"A", "B", "X", "Y", "L3", "R3", "L", "R", "ZL", "ZR", "Plus", "Minus", "Left", "Up", "Right", "Down"};
    static const int ORDER[16] = {0, 1, 2, 3, 6, 7, 8, 9, 10, 11, 13, 15, 12, 14, 4, 5};  // (the face buttons first)
    Config &c = s.draft;
    int k = s_combo;
    uint32_t mask = config_combo_mask(c.touch_combo[k]);
    for (int n = 0; n < 16; n++) {
        int b = ORDER[n];
        Row row;
        row.id = "ce." + std::to_string(n);
        row.title = tr(NAMES[b]);
        row.toggle = mask >> b & 1;
        row.activate = [k, b, mask]() { config_combo_text(mask ^ 1u << b, s.draft.touch_combo[k], sizeof s.draft.touch_combo[k]); };
        row.adjust = [k, b, mask](int d) {
            config_combo_text(d > 0 ? mask | 1u << b : mask & ~(1u << b), s.draft.touch_combo[k], sizeof s.draft.touch_combo[k]);
        };
        r.push_back(std::move(row));
    }
    add_choice(r, "ce.pad", "Controller button", c.touch_combo_pad[k],
               {tr("None"), "L3", "R3", tr("Minus"), "Guide", "Misc", "Paddle 1", "Paddle 2", "Paddle 3", "Paddle 4", "Touchpad"},
               [k](int v) { s.draft.touch_combo_pad[k] = v; });
    r.back().help = tr("That button of a controller does the same, and no longer does what it did.");
#ifdef __ANDROID__  // (a key does the same while held: [Keybinds] Combo<n>Key, also in Keybinds; a phone's with a keyboard
    if (host_input_keyboard_mouse())  // and a mouse connected, S14)
#endif
    {
        r.push_back(bind_row(BIND_COMBO1 + k, tr("A key or mouse button that presses these buttons while held. Keybinds has it too.")));
        r.back().id = "ce.key";
        r.back().title = tr("Key");
    }
    action(r, "ce.clear", tr("Clear"), [k]() {
        s.draft.touch_combo[k][0] = 0;
        s.draft.touch_combo_pad[k] = 0;
    });
    action(r, "ce.back", tr("Back"), []() { pop(); });
}
// Mapping a controller (runtime/padmap.c): the list of those connected, then its steps
void pad_list_rows(std::vector<Row> &r) {
    padmap_watch();
    char names[PADMAP_MAX][64];
    bool custom[PADMAP_MAX];
    int n = padmap_list(names, custom, PADMAP_MAX);
    if (!n) header(r, "pad.none", tr("No controller connected"));
    for (int i = 0; i < n; i++) {
        action(r, "pad." + std::to_string(i), names[i], [i]() {
            padmap_begin(i);
            push(View::PadMap, "pm.go");
        });
        if (custom[i]) {
            r.back().value = tr("Mapped");
            action(r, "padf." + std::to_string(i), fmt("Forget the map of %s", names[i]), [i]() { padmap_forget(i); });
            r.back().help = tr("The next time the game starts it reads this controller as before.");
        }
    }
    action(r, "pad.back", tr("Back"), []() { pop(); });
}
void pad_map_rows(std::vector<Row> &r) {
    padmap_watch();
    int step = padmap_step(), steps = padmap_steps();
    if (!padmap_active()) {  // (saved, or it was unplugged)
        pop();
        return;
    }
    if (step == PADMAP_REST) {
        header(r, "pm.rest", tr("Move both sticks and press the triggers once, then let everything go"));
        action(r, "pm.go", tr("Continue"), []() { padmap_continue(); });
    } else if (step < steps) {
        header(r, "pm.step", fmt("%d of %d: press", step + 1, steps) + std::string(" ") + tr(padmap_step_title(step)));
        action(r, "pm.go", tr("Skip"), []() { padmap_skip(); });
        r.back().help = tr("Leave this one out: the buttons your controller does not have.");
        if (step > 0) action(r, "pm.back", tr("Previous"), []() { padmap_back(); });
    } else {
        header(r, "pm.done", tr("That's all of them"));
        action(r, "pm.go", tr("Save"), []() {
            padmap_save();
            pop();
        });
        action(r, "pm.back", tr("Previous"), []() { padmap_back(); });
    }
    action(r, "pm.cancel", tr("Cancel"), []() {
        padmap_cancel();
        pop();
    });
}

std::vector<Row> rows_for_view(bool *open) {
    if (s.view == View::Main || s.view == View::Page)
        return main_rows();
    std::vector<Row> r;
    if (s.view == View::TouchButtons) { touch_button_rows(r); return r; }
    if (s.view == View::Chat) { chat_page_rows(r); return r; }
    if (s.view == View::Friends) { friends_page_rows(r); return r; }
    if (s.view == View::ComboEdit) { combo_rows(r); return r; }
    if (s.view == View::Profiles) { profile_rows(r); return r; }
    if (s.view == View::ProfileSlot) { profile_slot_rows(r); return r; }
    if (s.view == View::PadList) { pad_list_rows(r); return r; }
    if (s.view == View::PadMap) { pad_map_rows(r); return r; }
    if (s.view == View::Verify) { verify_rows(r); return r; }
    if (s.view == View::Keyboard) {
        // A QWERTY letter layout, with the number row first and punctuation after the letters.
        // Keep ten characters per row for draw_rows(): qwertyuiop / asdfghjkl: / zxcvbnm.,- / _/@.
        action(r, "key.copy", tr("Copy"), []() {
#ifdef __APPLE__
            const bool copied = plat_ios_set_clipboard_text(s.keyboard.buffer.c_str());
#else
            const bool copied = SDL_SetClipboardText(s.keyboard.buffer.c_str());
#endif
            s.error = copied ? tr("Copied to clipboard") : tr("Could not copy to clipboard");
        });
        action(r, "key.paste", tr("Paste"), []() {
#ifdef __APPLE__
            char clip[4096];
            if (plat_ios_get_clipboard_text(clip, sizeof clip)) insert(clip);
            else s.error = tr("Clipboard is empty or unavailable");
#else
            char *clip = SDL_GetClipboardText();
            if (clip && *clip) insert(clip);
            else s.error = tr("Clipboard is empty or unavailable");
            SDL_free(clip);
#endif
        });
        std::string chars = "1234567890qwertyuiopasdfghjkl:zxcvbnm.,-_/@";
        if (s.keyboard.upper)
            for (char &c : chars)
                c = (char)SDL_toupper(c);
        for (int i = 0; i < (int)chars.size(); i++) {
            std::string ch(1, chars[i]);
            action(r, "key." + std::to_string(i), ch, [ch]() { insert(ch); });
        }
        action(r, "key.delete", tr("Delete"), []() { erase_previous(); });
        action(r, "key.clear", tr("Clear"), []() {
            s.keyboard.buffer.clear();
            s.keyboard.cursor = 0;
        });
        action(r, "key.space", tr("Space"), []() { insert(" "); });
        action(r, "key.case", tr("Case"), []() { s.keyboard.upper = !s.keyboard.upper; });
#ifdef __ANDROID__  // (the phone's own keyboard, as the MH4U port's: Enter accepts, Back puts it away; textinput.c)
        action(r, "key.phone", tr("Phone keyboard"), []() {
            s.keyboard.phone = true;
            textinput_menu_keyboard_show();
        });
#endif
        action(r, "key.accept", tr("Accept"), []() { accept_keyboard(); });
        action(r, "key.cancel", tr("Cancel"), []() {
            if (s.keyboard.game) g_close_now = true;  // (the game's entry stays as it was)
            pop();
        });
    } else if (s.view == View::Conflicts) {
        conflict_rows(r);
        action(r, "conflicts.back", tr("Back"), []() { pop(); });
    } else if (s.view == View::Keybinds) {
        keybind_rows(r);
    } else if (s.view == View::KeyCapture) {
        int key = captured_key.exchange(-1);
        const char *name = key > 0 && key < KEY_MOUSE ? SDL_GetScancodeName((SDL_Scancode)key) : "";
        const char *reserved = key > 0 && key < KEY_MOUSE ? key_reserved(key) : nullptr;
        if (key == SDL_SCANCODE_ESCAPE || (touch_ui() && key == SDL_SCANCODE_AC_BACK))  // (the phone's Back key: cancel)
            pop();
        else if (s.capture_bind >= 0 && key > 0) {
            int *keys = s.draft.binds[s.capture_bind];
            if (reserved)
                s.error = fmt("That key is the recomp's own (%s).", tr(reserved));
            else if (!*config_key_name(key))
                s.error = tr("That key can't be used.");
            else {
                if (!s.capture_add)
                    keys[0] = key, keys[1] = 0;
                else if (keys[0] != key)
                    keys[1] = key;
                pop();
            }
        } else if (key > 0 && *name && strlen(name) < sizeof s.draft.chat_key && !strpbrk(name, ";#")) {
            SDL_strlcpy(s.draft.chat_key, name, sizeof s.draft.chat_key);
            pop();
        } else if (key > 0)
            s.error = tr("That key can't be used for chat.");
        if (s.view == View::KeyCapture) {
            action(r, "capture.none", tr("None"), []() {
                if (s.capture_bind >= 0)
                    s.draft.binds[s.capture_bind][0] = s.draft.binds[s.capture_bind][1] = 0;
                else
                    s.draft.chat_key[0] = 0;
                pop();
            });
            action(r, "capture.cancel", tr("Cancel"), []() { pop(); });
        }
    } else if (s.view == View::Move) {
        action(r, "move.accept", tr("Accept"), []() { pop(); });
        action(r, "move.cancel", tr("Cancel"), []() {
            s.move_position = s.move_start;
            s.position_override = true;
            pop();
        });
    } else {
        // (as Back: the unsaved-changes dialog's leaves the menu open with no touch layout editor after all)
        action(r, "dialog.cancel", tr(s.view == View::Licenses ? "Close" : "Cancel"), [open]() { leave_view(open); });
#ifndef __ANDROID__
        if (s.view == View::ImportSave)  // (runtime/pc_actions.c: kept for the next start, which puts it in place)
            action(r, "dialog.import", tr("Import and restart"), []() {
                if (pc_import_save_confirm()) ui_request_action(true);
                else pop();
            });
#endif
        if (s.view == View::Reset)
            action(r, "dialog.reset", tr("Reset"), []() { reset_section(); });
        if (s.view == View::OpenSite)  // (back to where the button was, then the browser: a notice there without one)
            action(r, "dialog.open", tr("Open"), []() {
                pop();
                open_official_page();
            });
        if (s.view == View::OpenDiscord)
            action(r, "dialog.open", tr("Open"), []() {
                pop();
                open_discord();
            });
        if (s.view == View::ChatOn)  // (the online chat's relays, the first time: settings_chat.inc)
            action(r, "dialog.chat", cs("Turn it on", "Activarlo"), []() {
                chat::set_notice_seen();
                chat::set_enabled(true);
                pop();
            });
        if (s.view == View::CloseChanges) {
            action(r, "dialog.save", tr("Save and close"), [open]() {
                if (save())
                    *open = false;
            });
            action(r, "dialog.discard", tr("Discard and close"), [open]() {
                discard();
                *open = false;
            });
        }
        if (s.view == View::Exit) {
            action(r, "dialog.exit", tr((dirty() || pending_text()) ? "Save and exit" : "Exit game"), []() {
                if ((!dirty() && !pending_text()) || save())
                    ui_request_action(false);
            });
            if (dirty() || pending_text())
                action(r, "dialog.discard", tr("Exit without saving"), []() { ui_request_action(false); });
        }
        if (s.view == View::Restart)
            action(r, "dialog.restart", tr("Save and restart"), []() {
                if (save())
                    ui_request_action(true);
            });
#ifndef __ANDROID__
        if (s.view == View::Remove)  // (a mod or a cheat file: runtime/pc_actions.c)
            action(r, "dialog.remove", tr("Remove"), []() { remove_confirmed(); });
#endif
    }
    return r;
}
// The open dropdown's choices
std::vector<Row> dropdown_rows() {
    std::vector<Row> r;
    for (int i = 0; i < (int)s.dropdown.names.size(); i++) {
        action(r, "choice." + std::to_string(i), s.dropdown.names[i], [i]() {
            auto set = s.dropdown.set;
            close_dropdown();
            set(i);
        });
        r.back().current = i == s.dropdown.selected;
        if (i < (int)s.dropdown.removable.size() && s.dropdown.removable[i] && s.dropdown.remove)
            r.back().remove = [i]() {
                auto remove = s.dropdown.remove;
                remove(i);
            };
    }
    return r;
}
// The picker's remembered choice picked by a controller or the keys: the button that saves elsewhere (the top one) or
// Delete takes it out, as its x does
void picker_keys(const std::vector<Row> &options) {
    if (!s.dropdown.open || !(pressed(ImGuiKey_GamepadFaceUp, false) || pressed(ImGuiKey_Delete, false)))
        return;
    for (const Row &o : options)
        if (o.id == s.focus && o.remove) {
            auto fn = o.remove;
            fn();
            return;
        }
}
// A row's help: its own, or what the default ini says of its setting (each line looked up in settings_locale.h)
#ifdef __ANDROID__
// A phone's own: the default ini's speaks of keys and of a PC, and stays in English
struct PhoneHelp {
    const char *key, *en, *es;
};
const PhoneHelp PHONE_HELP[] = {
    {"RenderScale", "The size of the 3D picture against the screen's. Lower runs faster and looks softer.",
     "El tamaño de la imagen 3D respecto de la pantalla. Más bajo corre más rápido y se ve más suave."},
    {"ShowMenuPad", "While a menu of the game's is open, a small pad shows that moves its cursor, with the page buttons above it (L and R, or ZL and ZR if the game's options turn pages with them). The movement stick keeps walking and the other buttons stay where they are; where the hunter can't walk (a town's item box, a shop) it moves the cursor too. If the pad covers a combined button, move it with Customize controls and HUD.",
     "Mientras hay un menú del juego abierto aparece un pad chico que mueve su cursor, con los botones de página encima (L y R, o ZL y ZR si las opciones del juego pasan páginas con ellos). La palanca de movimiento sigue caminando y los demás botones quedan donde están; donde el cazador no puede caminar (la caja de objetos de un pueblo, una tienda) también mueve el cursor. Si el pad tapa un botón combinado, muévelo con Personalizar controles y HUD."},
    {"ShowMenuZL", "With the menu pad, a ZL tab above its left one (L when the game turns pages with ZL and ZR). Some menus use it to change sections or show more information: the item box, the smithy.",
     "Con el pad de menú, una pestaña ZL sobre la de la izquierda (L si el juego pasa páginas con ZL y ZR). Algunos menús la usan para cambiar de sección o ver más información: la caja de objetos, la herrería."},
    {"ShowMenuZR", "With the menu pad, a ZR tab above its right one (R when the game turns pages with ZL and ZR). Some menus use it to change sections or show more information: the item box, the smithy.",
     "Con el pad de menú, una pestaña ZR sobre la de la derecha (R si el juego pasa páginas con ZL y ZR). Algunos menús la usan para cambiar de sección o ver más información: la caja de objetos, la herrería."},
    {"Reverb", "The echo of caves and rooms. Off: the sound is dry, and a weak phone's processor does less.",
     "El eco de cuevas y salas. Apagada: el sonido queda seco y el procesador de un teléfono débil trabaja menos."},
    {"LowEnd", "For a weak phone: no bloom or depth of field, cheaper and smaller textures, and the HUD stays sharp over a smaller 3D picture. Toaster: everything for speed and the battery before looks.",
     "Para un teléfono débil: sin resplandor ni profundidad de campo, texturas más livianas y más chicas, y el HUD sigue nítido sobre una imagen 3D más chica. Tostadora: todo para la velocidad y la batería antes que el aspecto."},
    {"Shadows", "The shadows of hunters, monsters and scenery. Off: a little faster on a weak phone.",
     "Las sombras de cazadores, monstruos y escenario. Apagadas: un poco más rápido en un teléfono débil."},
    {"Grass", "The grass fields of the maps, as the tall grass of the Marshland's area 8. Off: faster where there is a lot of it on a weak phone. The plants that are part of a map's ground stay.",
     "Los pastizales de los mapas, como el pasto alto de la zona 8 del Pantano. Apagado: más rápido donde hay mucho, en un teléfono débil. Las plantas que son parte del suelo del mapa quedan."},
    {"AdrenoFix", "Some Adreno drivers repeat the 3D picture in a grid at a low 3D resolution: Auto keeps 2x MSAA there. If the picture looks dark or flickers, or for more speed, choose Off.",
     "Algunos drivers de Adreno repiten la imagen 3D en grilla con una resolución 3D baja: Auto deja MSAA 2x en ese caso. Si la imagen se ve oscura o parpadea, o para ganar velocidad, elige Off."},
    {"LockOn", "Tap the Lock-on button on the screen (a controller: click the right stick; hold it with Control Type 3, where the click changes the target) and the camera keeps turning to the monster, the one the Target Cam chose or the nearest large one, until you tap it again. The target button changes the monster. Bows and bowguns fire at it from a normal stance; your own aim, crouching fire and the styles' moves are left to you. Turning the camera yourself pauses it for a moment.",
     "Toca el botón Fijar objetivo en la pantalla (un mando: aprieta la palanca derecha; mantenla apretada con el Tipo de control 3, donde el clic cambia el objetivo) y la cámara sigue girando hacia el monstruo, el que eligió la cámara objetivo o el grande más cercano, hasta que lo vuelvas a tocar. El botón de objetivo cambia el monstruo. Arcos y ballestas disparan hacia él desde la postura normal; tu propio apuntado, el fuego agachado y los movimientos de los estilos quedan en tus manos. Girar la cámara tú mismo la pausa un momento."},
    {"ShowLockOn", "The port's own button, not one of the game's: a tap locks the camera on the monster and it keeps turning to it; another tap lets go. The target button changes the monster. It lights up while the lock-on is on, and shows while Lock-on is on in Controls.",
     "Un botón propio del port, no del juego: un toque fija la cámara en el monstruo y la sigue girando hacia él; otro toque la suelta. El botón de objetivo cambia el monstruo. Se ilumina mientras está fijado, y aparece mientras Fijar objetivo está activado en Controles."},
    {"GyroAim", "Aiming a bow or a bowgun (a gun's aim, its scope, crouching fire; a bow's aiming mode), turning the phone turns the aim too, from where it was as the aim began, with what your fingers or the sticks do. A controller with a gyro is read instead of the phone. The gyroscope is read only while you aim.",
     "Al apuntar con un arco o una ballesta (la mira de la ballesta, su visor, el disparo agachado; el modo de apuntar del arco), girar el teléfono también mueve la mira, desde donde estaba al empezar a apuntar, junto con lo que hagan tus dedos o las palancas. Si el mando tiene giroscopio, se usa el del mando en vez del teléfono. El giroscopio solo se lee mientras apuntas."},
    {"GyroSensitivity", "How far the aim turns for a turn of the phone or the controller: 1.0x the same angle.",
     "Cuánto gira la mira por cada giro del teléfono o del mando: 1.0x, el mismo ángulo."},
    {"Join", "A host's IP address, to play over a VPN. Empty: searches your network.", "La dirección IP de un anfitrión, para jugar por VPN. Vacío: busca en tu red."},
    {"Server", "The server that lists hubs over the internet: everyone who uses the same one finds the others' hubs when they search for hubs in the game, with no ports to open. The default, " LDN_DEFAULT_SERVER ", is run by players, not by this project. Custom: type another (a name or IP, and :port if it is not 39510). Off: only your local network. The servers you type and save stay in this list, the last one first (up to 24): the × beside one takes it out (with a controller, the button that saves).",
     "El servidor que lista las salas por internet: todos los que usan el mismo encuentran las salas de los demás al buscar salas en el juego, sin abrir puertos. El predeterminado, " LDN_DEFAULT_SERVER ", lo mantienen jugadores, no este proyecto. Otro: escribe otro (un nombre o una IP, y :puerto si no es el 39510). Ninguno: solo tu red local. Los servidores que escribes y guardas quedan en esta lista, el último primero (hasta 24): la × a su lado lo quita (con un mando, el botón que guarda)."},
    {"Key", "On the hub server, only players with the same key see each other's hubs: agree on one with your friends. Public: no key, the public hubs. The keys you type and save stay in this list, the last one first (up to 24): the × beside one takes it out (with a controller, the button that saves).",
     "En el servidor de hubs, solo los jugadores con la misma clave ven los hubs de los demás: acuerden una con tus amigos. Pública: sin clave, los hubs públicos. Las claves que escribes y guardas quedan en esta lista, la última primero (hasta 24): la × a su lado la quita (con un mando, el botón que guarda)."},
    {"1Player", "The health of large monsters in Hub quests, by number of hunters. When you join a hub, the host's values are used.",
     "La vida de los monstruos grandes en las misiones del Hub, según la cantidad de cazadores. Al unirte a un Hub se usan los valores del anfitrión."},
    {"FOV", "How much of the scene you see: higher shows more.", "Cuánto se ve de la escena: un valor mayor muestra más."},
    {"ShowRanged", "With a bow or a bowgun in hand, in a hunt, the touch controls change to a layout of their own. Its buttons are moved in the editor.",
     "Con un arco o una ballesta en la mano, en una cacería, los controles táctiles pasan a un layout propio. Sus botones se mueven en el editor."},
    {"ShowFire", "A bowgun fires. A bow draws while you hold it and shoots when you let go. Drag on it to aim while you hold it.",
     "La ballesta dispara. El arco se tensa mientras lo mantienes y dispara al soltar. Arrastra sobre él para apuntar mientras lo mantienes."},
    {"ShowSecond", "A bowgun reloads. A bow does its melee attack.", "La ballesta recarga. El arco da su golpe cuerpo a cuerpo."},
    {"ShowAim", "A bowgun: a tap, the scope; held, the quick aim. A bow: the aiming mode.", "Ballesta: un toque, la mira; mantenido, el apuntado rápido. Arco: el modo de apuntado."},
    {"ShowRangedSpecial", "A bowgun's crouching fire. A bow applies its coating.", "El fuego agachado de la ballesta. El arco aplica su capa."},
    {"ShowAmmo", "Change the ammo or the coating. A swipe up or down on the item bar does it too.", "Cambian la munición o la capa. También se puede deslizar hacia arriba o abajo sobre la barra de ítems."},
    {"ShowItemArrows", "Arrows beside the item bar. A swipe on the bar turns it too.", "Flechas a los lados de la barra de ítems. Deslizar sobre la barra también la gira."},
    {"FloatingStick", "On: the movement stick comes to where your thumb lands near it, and goes back to its place when you lift it. Off: it stays where it is.",
     "Activado: la palanca de movimiento aparece donde apoyas el pulgar cerca de ella, y vuelve a su lugar al levantarlo. Desactivado: se queda donde está."},
    {"StickRun", "On: push the movement stick past its edge to run, as before. Slide it up onto the small circle with a padlock that shows above it, which lights up, and lift your thumb there: the run locks and the hunter keeps running forward (steer with the camera), until you touch the stick or the circle again, draw the weapon or open a menu. Off: the stick only walks, and a Run button shows above the attacks instead: it runs while held.",
     "Activado: empuja la palanca de movimiento más allá de su borde para correr, como siempre. Deslízala hacia arriba hasta el círculo chico con un candado que aparece encima, que se ilumina, y levanta el pulgar ahí: la carrera se fija y el cazador sigue corriendo hacia adelante (giras con la cámara), hasta que vuelvas a tocar la palanca o el círculo, desenvaines o abras un menú. Desactivado: la palanca solo camina, y aparece un botón Correr sobre los ataques: corre mientras lo mantienes."},
    {"GuardSlide", "On: with the weapon out, a thumb that lands on Guard and slides onto the attacks keeps guarding (R held), for the moves that need R and an attack together, like a lance's counter or a shield's thrust; slid onto the item bar, it presses R and Y together. Off: the slide lets go of R.",
     "Activado: con el arma desenvainada, un pulgar que se apoya en Guardia (R) y se desliza a los ataques sigue en guardia (R mantenido), para los movimientos que piden R junto con un ataque, como el contraataque de la lanza o el empujón del escudo; deslizado a la barra de ítems, aprieta R e Y juntos. Desactivado: al deslizar se suelta R."},
    {"UIAnchor", "On a screen wider than 16:9, where the HUD goes.", "En una pantalla más ancha que 16:9, dónde va el HUD."},
    {"FillScreen", "Movies and menu backdrops fill the screen, with a little cut above and below, instead of bars at the sides.",
     "Los videos y los fondos de los menús llenan la pantalla, con un pequeño recorte arriba y abajo, en lugar de barras a los costados."},
    {"FPS", "The most frames a second. A lower limit heats the phone less and saves battery.",
     "El máximo de cuadros por segundo. Un límite más bajo calienta menos el teléfono y gasta menos batería."},
    {"ShowStats", "Shows the frame rate and the phone's temperature on the screen.", "Muestra los FPS y la temperatura del teléfono en la pantalla."},
    {"MSAA", "Smooths the edges of 3D models. It asks more of the GPU.", "Suaviza los bordes de los modelos 3D. Exige más a la GPU."},
    {"FXAA", "Smooths the edges of the whole picture. On Mali GPUs it can leave a green line at the edge of the screen.",
     "Suaviza los bordes de toda la imagen. En GPU Mali puede dejar una línea verde al borde de la pantalla."},
    {"DrawDistance", "How far away people in towns are drawn: 1 is the game's distance, 2 twice as far, 0 no limit.",
     "Hasta qué distancia se dibuja a la gente en los pueblos: 1 es la distancia del juego, 2 el doble, 0 sin límite."},
    {"Volume", "The game's volume.", "El volumen del juego."},
    {"FSR", "Rebuilds the picture from a lower resolution. It needs a Vulkan 1.2 GPU.", "Reconstruye la imagen desde una resolución menor. Necesita una GPU con Vulkan 1.2."},
    {"FSRQuality", "How low the resolution goes before the picture is rebuilt.", "Cuánto baja la resolución antes de reconstruir la imagen."},
    {"Sharpness", "How sharp FSR leaves the picture.", "Qué tan nítida deja FSR la imagen."},
    {"FaceButtons", "How A, B, X and Y are read on a controller. Position: as on the Switch. Label: by the letter printed on the button.",
     "Cómo se leen A, B, X e Y en un mando. Posición: como en la Switch. Etiqueta: según la letra impresa en el botón."},
    {"Controls", "Auto: they show while no controller is connected. Never: only the settings button stays.",
     "Automático: se ven mientras no haya un mando conectado. Nunca: solo queda el botón de opciones."},
    {"MoveHUD", "On: with the touch controls the HUD has an arrangement of its own, out of your thumbs' way. Off: the same HUD as without them.", "Activado: con los controles táctiles el HUD tiene un acomodo propio, lejos de los pulgares. Desactivado: el mismo HUD que sin ellos."},
    {"CameraSpeed", "How far the camera turns for a drag; adjustable from 1x to 10x.", "Cuánto gira la cámara al arrastrar; ajustable de 1x a 10x."},
    {"Opacity", "How solid the touch controls look.", "Qué tan sólidos se ven los controles táctiles."},
    {"Vibration", "A short vibration when you press a touch control.", "Una vibración corta al tocar un control."},
    {"PhoneRumble", "The game's rumble on the phone too, with or without a controller.", "La vibración del juego también en el teléfono, con o sin mando."},
    {"Port", "The port for local play hubs. Everyone must use the same one.", "El puerto de las salas de juego local. Todos deben usar el mismo."},
    {"SyncSmallMonsters", "Small monsters are the same for every player. Experimental: they may stop attacking.",
     "Los monstruos pequeños son los mismos para todos los jugadores. Experimental: pueden dejar de atacar."},
    {"VillageQuestsInHub", "In the Hub, L or R while choosing a quest shows the Village quests, to play them with others.",
     "En el Hub, L o R al elegir una misión muestra las de la aldea, para jugarlas con otros."},
    {"HubHP", "A Village quest played in the Hub first multiplies the monster's health by this.",
     "Una misión de la aldea jugada en el Hub primero multiplica la vida del monstruo por este valor."},
    {"Language", "The language of this menu.", "El idioma de este menú."},
    {"MenuScale", "The size of this menu, 50 % to 200 %.", "El tamaño de este menú, de 50 % a 200 %."},
    {"Theme", "The colours of this menu.", "Los colores de este menú."},
    {"PauseInBackground", "The game stops while you are out of the app.", "El juego se detiene mientras estás fuera de la app."},
    {"PauseInMenu", "The game waits while this menu is open, when you play alone. With others online or in Local Play it goes on.",
     "El juego espera mientras este menú está abierto, cuando juegas solo. Con otros, en línea o en juego local, sigue."},
    {"BonusContent", "Copies the free downloadable content (event quests, item packs, Palicoes) to a save that has not received it yet.",
     "Copia el contenido descargable gratuito (misiones de evento, packs de objetos, Palicoes) a una partida que todavía no lo recibió."},
    {"Updates", "At most once a day the app asks GitHub for the latest version (nothing else is sent) and tells you at the next start when there is a new one. It never downloads or installs anything by itself.",
     "Como mucho una vez al día la app le pregunta a GitHub cuál es la última versión (no se envía nada más) y te avisa al abrir el juego cuando hay una nueva. Nunca descarga ni instala nada por su cuenta."},
};
#endif
std::string help_text(const Row &r) {
    if (!r.help.empty() || r.key.empty())
        return r.help;
#ifdef __ANDROID__
    for (const PhoneHelp &h : PHONE_HELP)
        if (r.key == h.key) return s.draft.language == 1 ? h.es : h.en;
#endif
    static std::vector<std::pair<std::string, std::string>> cache;  // (key, help in English)
    auto at = std::find_if(cache.begin(), cache.end(), [&](const auto &e) { return e.first == r.key; });
    if (at == cache.end()) {
        char buf[2048];
        cache.emplace_back(r.key, config_help(r.key.c_str(), buf, sizeof buf) ? buf : "");
        at = cache.end() - 1;
    }
    std::string out, line;
    for (size_t i = 0, j; i < at->second.size(); i = j + 1) {
        j = at->second.find('\n', i);
        if (j == std::string::npos)
            j = at->second.size();
        line = at->second.substr(i, j - i);
        out += (out.empty() ? "" : "\n") + std::string(tr(line.c_str()));
    }
    return out;
}
bool pressed(ImGuiKey key, bool repeat = false) { return ImGui::IsKeyPressed(key, repeat); }
bool direction(ImGuiKey a, ImGuiKey b, ImGuiKey c) {
    return pressed(a, true) || pressed(b, true) || pressed(c, true);
}
// Tab moves to the next row (Shift+Tab the one before); a desktop's Ctrl+Tab changes the tab instead (page_keys)
bool tab_key() {
#ifndef __ANDROID__
    if (ImGui::GetIO().KeyCtrl)
        return false;
#endif
    return pressed(ImGuiKey_Tab, true);
}
// list: a dropdown's choices (left / right do nothing there)
void navigate(std::vector<Row> &rows, bool list = false) {
    if (rows.empty())
        return;
    auto it =
        std::find_if(rows.begin(), rows.end(), [](const Row &r) { return r.id == s.focus && r.enabled; });
    if (it == rows.end()) {
        it = std::find_if(rows.begin(), rows.end(), [](const Row &r) { return r.enabled; });
        if (it == rows.end())
            return;
        focus(it->id);
    }
    int index = (int)(it - rows.begin());
    int dy = direction(ImGuiKey_DownArrow, ImGuiKey_GamepadDpadDown, ImGuiKey_GamepadLStickDown) ? 1
             : direction(ImGuiKey_UpArrow, ImGuiKey_GamepadDpadUp, ImGuiKey_GamepadLStickUp)     ? -1
                                                                                                 : 0;
    int dx = direction(ImGuiKey_RightArrow, ImGuiKey_GamepadDpadRight, ImGuiKey_GamepadLStickRight) ? 1
             : direction(ImGuiKey_LeftArrow, ImGuiKey_GamepadDpadLeft, ImGuiKey_GamepadLStickLeft)  ? -1
                                                                                                    : 0;
    if (tab_key())
        dy = ImGui::GetIO().KeyShift ? -1 : 1;
    if (list)
        dx = 0;
    if (dx && it->adjust) {
        it->adjust(dx);
        return;
    }
    int delta = dy;
    if (s.view == View::Keyboard && (dx || dy) && !tab_key()) {
        auto from =
            std::find_if(s.targets.begin(), s.targets.end(), [](const Target &t) { return t.id == s.focus; });
        if (from != s.targets.end()) {
            float best = 1e30f;
            std::string next;
            for (const auto &t : s.targets) {
                float x = t.center.x - from->center.x, y = t.center.y - from->center.y;
                if (!t.enabled || (dy && y * dy <= 1) || (dx && (x * dx <= 1 || std::abs(y) > 1)))
                    continue;
                float score = dy ? std::abs(y) * 1000 + std::abs(x) : std::abs(x);
                if (score < best) {
                    best = score;
                    next = t.id;
                }
            }
            if (!next.empty())
                focus(next);
            return;
        }
    }
    if (dx)
        delta = dx;
    if (delta) {
        int next = std::clamp(index + delta, 0, (int)rows.size() - 1);
        int step = delta > 0 ? 1 : -1;
        while (next >= 0 && next < (int)rows.size() && !rows[next].enabled)
            next += step;
        if (next >= 0 && next < (int)rows.size())
            focus(rows[next].id);
    }
    auto first = std::find_if(rows.begin(), rows.end(), [](const Row &r) { return r.enabled; });
    auto last = std::find_if(rows.rbegin(), rows.rend(), [](const Row &r) { return r.enabled; });
    if (pressed(ImGuiKey_Home))
        focus(first->id);
    if (pressed(ImGuiKey_End))
        focus(last->id);
}
// Keep ImGui internals at this boundary: rows retain native activation and rendering.
void own_focus(ImGuiWindow *w, ImGuiID id, const ImRect &rect) {
    ImGuiContext &g = *ImGui::GetCurrentContext();
    // Focus first: a click outside the menu leaves no focused window, and SetNavID asserts one
    ImGui::FocusWindow(w);
    ImGui::SetNavID(id, ImGuiNavLayer_Main, 0,
                    ImRect(ImVec2(rect.Min.x - w->Pos.x, rect.Min.y - w->Pos.y),
                           ImVec2(rect.Max.x - w->Pos.x, rect.Max.y - w->Pos.y)));
    g.NavCursorVisible = true;
    g.NavInitRequest = false;
    g.NavMoveSubmitted = false;
    // Let auto-sizing settle after a view change; do not fight later mouse-wheel scrolling.
    if (s.focus_request) {
        s.focus_scroll_frames = 3;
        s.focus_request = false;
    }
    if (s.focus_scroll_frames > 0) {
        --s.focus_scroll_frames;
        if (s.guide_height) {
            float top = w->ClipRect.Min.y, bottom = w->ClipRect.Max.y;
            float delta = rect.Min.y < top ? rect.Min.y - top : rect.Max.y > bottom ? rect.Max.y - bottom : 0;
            if (delta)
                ImGui::SetScrollY(w, w->Scroll.y + delta);
        } else  // (the phone's lists scroll, the menu around them stays)
            ImGui::ScrollToRect(w, rect, ImGuiScrollFlags_KeepVisibleEdgeY | (s.list ? ImGuiScrollFlags_NoScrollParent : 0));
    }
}
// A value cut to fit (available: its width), "..." at its end
void fit(std::string &value, float available) {
    if (ImGui::CalcTextSize(value.c_str()).x <= available)
        return;
    do {
        size_t n = value.size() - 1;
        while (n && ((unsigned char)value[n] & 0xc0) == 0x80)
            --n;
        value.resize(n);
    } while (!value.empty() && ImGui::CalcTextSize((value + "...").c_str()).x > available);
    value += "...";
}
// A name cut to fit at a space, never inside a word (room: its width in font at size), "..." at its end; empty when not
// even its first word fits
std::string whole_words(ImFont *font, float size, const std::string &name, float room) {
    if (font->CalcTextSizeA(size, FLT_MAX, 0, name.c_str()).x <= room)
        return name;
    for (size_t n = name.rfind(' '); n != std::string::npos && n; n = name.rfind(' ', n - 1)) {
        std::string cut = name.substr(0, n) + "...";
        if (font->CalcTextSizeA(size, FLT_MAX, 0, cut.c_str()).x <= room)
            return cut;
    }
    return "";
}
// An invisible button over r for a finger (not one of the rows: the controller never lands on it); true when tapped
bool touch_button(const char *id, const ImRect &r, bool enabled, bool *held) {
    ImGui::SetCursorScreenPos(r.Min);
    ImGui::PushItemFlag(ImGuiItemFlags_NoNav, true);
    ImGui::BeginDisabled(!enabled);
    bool tapped = ImGui::InvisibleButton(id, ImVec2(std::max(1.f, r.GetWidth()), std::max(1.f, r.GetHeight())));
    *held = ImGui::IsItemActive();
    ImGui::EndDisabled();
    ImGui::PopItemFlag();
    return tapped && !s.swallow;
}
// The side of the x that takes a remembered choice out of a picker (the phone's)
float forget_side() { return std::min(s.m.row * .72f, ImGui::GetFontSize() * 2.f); }
// A row on the phone: lit gold when it is the one picked (a diamond at its left, as the game's cursor), lighter while a
// finger holds it; its title at the left, at the right an On / Off switch, the value between - and + (stepper: those
// are draw_rows' buttons, room their width), or the value, marked when a tap lists its choices. plated: a key or a
// dialog's button, a plate with its title in the middle
void touch_row(ImDrawList *dl, const Row &r, const ImRect &rect, bool lit, bool held, bool plated, ImVec2 label,
               float wrap, float room, bool toggle, bool stepper) {
    const Theme &t = theme();
    const Look k = touch_look();
    float font = ImGui::GetFontSize(), line = s.m.line, cy = rect.GetCenter().y;
    if (plated && !lit)
        plate(dl, rect, line * .8f, held, r.enabled);
    if (lit) {
        dl->AddRectFilledMultiColor(rect.Min, rect.Max, k.bar0, k.bar1, k.bar1, k.bar0);
        dl->AddRect(rect.Min, rect.Max, fade(k.glow, held ? 1.f : .8f), 0, 0, line * .6f);
        if (held)
            dl->AddRectFilled(rect.Min, rect.Max, IM_COL32(255, 240, 200, 40));
    } else if (held && !plated)
        dl->AddRectFilled(rect.Min, rect.Max, fade(k.glow, .14f));
    if (!plated && t.game) {  // (lines between the rows, as in the game's lists)
        float y = rect.Max.y + ImGui::GetStyle().ItemSpacing.y * .5f;
        dl->AddLine(ImVec2(rect.Min.x, y), ImVec2(rect.Max.x, y), fade(t.divider, .8f), std::max(1.f, line * .5f));
    }
    dl->PushClipRect(rect.Min, rect.Max, true);
    if (lit && !plated)
        diamond(dl, ImVec2(rect.Min.x + font * .55f, cy), font * .2f, k.glow);
    ImU32 ink = !r.enabled ? t.text_off : lit ? IM_COL32(255, 248, 232, 255) : r.current ? k.glow : k.ink;
    float x = plated ? rect.GetCenter().x - label.x * .5f : rect.Min.x + font * 1.1f;
    shadow_text(dl, font, ImVec2(x, cy - label.y * .5f), ink, r.title.c_str(), wrap);
    float right = rect.Max.x - font * .6f - (r.remove ? forget_side() + font * .4f : 0);  // (draw_rows' x at the right)
    if (r.current)  // (the picker: the choice the row has now)
        diamond(dl, ImVec2(right - font * .3f, cy), font * .24f, k.glow);
    // (a tap goes on - to a page, a screen of the app's, a question: a mark at the right, as in the MH4U port; not a
    // picker's choice, which only picks, as there)
    bool goes_on = r.action && r.enabled && r.id != "save" && r.id.compare(0, 7, "choice.") && !plated && !toggle;
    if (goes_on)
        chevron(dl, ImVec2(right - font * .35f, cy), font * .28f, 1, lit ? ink : fade(k.rule, .8f), std::max(2.f, s.m.line));
    if (toggle) {
        ImRect slot(right - font * 2.6f, cy - font * .6f, right, cy + font * .6f);
        switch_mark(dl, slot, r.toggle == 1);
        if (r.cold)
            shadow_text(dl, font, ImVec2(slot.Min.x - font * .8f, cy - font * .5f), lit ? ink : t.warn, "*");
    } else if (!r.value.empty() && !plated) {
        std::string value = r.value + (r.cold ? " *" : "");
        float bs = stepper ? std::min(s.m.row * .84f, font * 2.3f) : 0;
        fit(value, stepper ? room - bs * 2 - font * .4f : room - font * (r.menu || goes_on ? 1.4f : .3f));
        ImVec2 size = ImGui::CalcTextSize(value.c_str());
        float vx = stepper ? right - room * .5f - size.x * .5f : right - size.x - ((r.menu && r.enabled) || goes_on ? font * 1.1f : 0);
        ImU32 value_ink = r.warn ? IM_COL32(255, 110, 96, 255) : !r.enabled ? t.text_off : lit ? ink : k.rule;
        shadow_text(dl, font, ImVec2(vx, cy - size.y * .5f), value_ink, value.c_str());
        if (r.menu && r.enabled) {  // (a tap lists the choices)
            float m = font * .26f, mx = right - font * .4f;
            dl->AddTriangleFilled(ImVec2(mx - m, cy - m * .55f), ImVec2(mx + m, cy - m * .55f), ImVec2(mx, cy + m * .65f),
                                  lit ? ink : k.rule);
        }
    }
    dl->PopClipRect();
}
// The phone's rows to the pages one level down (MENU.md): plates side by side, two or three to a line, each with its
// title, its summary under it and a chevron; lit as a picked row. Their runs, by row: the place in its run and the run's
// length (0: not a page's row)
void tile_runs(const std::vector<Row> &rows, std::vector<int> &at, std::vector<int> &run) {
    at.assign(rows.size(), 0), run.assign(rows.size(), 0);
    for (size_t i = 0; i < rows.size();) {
        size_t j = i;
        while (j < rows.size() && !rows[j].id.compare(0, 5, "page.") && !rows[j].header)
            j++;
        for (size_t k = i; k < j; k++)
            at[k] = (int)(k - i), run[k] = (int)(j - i);
        i = j > i ? j : i + 1;
    }
}
void tile_draw(ImDrawList *dl, const Row &r, const ImRect &rect, bool lit, bool held) {
    const Look k = touch_look();
    ImFont *font = ImGui::GetFont();
    float f = ImGui::GetFontSize(), line = s.m.line, cy = rect.GetCenter().y;
    if (lit) {
        dl->AddRectFilledMultiColor(rect.Min, rect.Max, k.bar0, k.bar1, k.bar1, k.bar0);
        dl->AddRect(rect.Min, rect.Max, fade(k.glow, held ? 1.f : .85f), 0, 0, line * .7f);
    } else
        plate(dl, rect, line * .8f, held, r.enabled);
    ImU32 ink = !r.enabled ? theme().text_off : lit ? IM_COL32(255, 248, 232, 255) : k.ink;
    float right = rect.Max.x - f * .75f, x = rect.Min.x + f * .8f, room = right - f * .7f - x;
    chevron(dl, ImVec2(right, cy), f * .26f, 1, lit ? ink : fade(k.rule, .85f), std::max(2.f, line));
    if (lit)
        diamond(dl, ImVec2(rect.Min.x + f * .42f, cy), f * .17f, k.glow);
    float size = f, wide = font->CalcTextSizeA(size, FLT_MAX, 0, r.title.c_str()).x;
    if (wide > room)  // (a long title: smaller, down to .8 of the letters, then cut at a word)
        size = std::max(std::floor(f * .8f), std::floor(f * room / wide));
    std::string title = whole_words(font, size, r.title, room);
    if (title.empty())
        title = r.title;
    float small = std::floor(f * .78f);
    std::string value = r.value;
    if (!value.empty())
        value = whole_words(font, small, value, room);
    ImVec2 ts = font->CalcTextSizeA(size, FLT_MAX, 0, title.c_str());
    float y = value.empty() ? cy - ts.y * .5f : cy - (ts.y + small * 1.05f) * .5f;
    dl->PushClipRect(rect.Min, rect.Max, true);
    shadow_text(dl, font, size, ImVec2(x, y), ink, title.c_str());
    if (!value.empty())
        dl->AddText(font, small, ImVec2(x, y + ts.y + small * .05f), lit ? fade(ink, .85f) : k.rule, value.c_str());
    dl->PopClipRect();
}
// A row's help opened or closed (its "?", Y or H): one at a time; the list shows it as it opens
void toggle_help(const std::string &id) {
    s.help_open = s.help_open == id ? std::string() : id;
    s.help_scroll = !s.help_open.empty();
}
// The open picker's help: its row's, as the view's rows have it this frame
void picker_help(const std::vector<Row> &rows) {
    if (!s.dropdown.open)
        return;
    for (const Row &r : rows)
        if (r.id == s.dropdown.row) {
            s.dropdown.help = help_text(r);
            return;
        }
}
// Y (the left face button) or H: the picked row's help, as its "?"
void help_keys(const std::vector<Row> &rows) {
    if (s.view == View::Keyboard || s.view == View::KeyCapture || confirmation())
        return;
    if (!pressed(ImGuiKey_GamepadFaceLeft) && !pressed(ImGuiKey_H))
        return;
    if (s.dropdown.open) {  // (the picker's: its row's help over the choices)
        if (!s.dropdown.help.empty())
            s.dropdown.show_help = !s.dropdown.show_help;
        return;
    }
    for (const Row &r : rows)
        if (r.id == s.focus && !r.header && r.id.compare(0, 5, "page.") && !help_text(r).empty()) {
            toggle_help(r.id);
            return;
        }
}
// A row's help, open under it: a parchment-dark plate the list's width, a gold rule and a diamond at its left, the text
// in the letters' colour; a tap on it closes it
void help_box(ImGuiWindow *w, const Row &r, float width) {
    const Look k = touch_look();
    const std::string text = help_text(r);
    ImFont *font = ImGui::GetFont();
    float f = ImGui::GetFontSize(), size = std::floor(f * .84f), line = s.m.line, in = f * 1.1f;
    float wrap = width - in - f * .9f;
    ImVec2 ts = font->CalcTextSizeA(size, FLT_MAX, wrap, text.c_str());
    ImVec2 p = ImGui::GetCursorScreenPos();
    ImRect box(ImVec2(p.x + f * .4f, p.y), ImVec2(p.x + width, p.y + ts.y + f * 1.0f));
    ImGui::PushID(r.id.c_str());
    bool held = false;
    if (touch_button("###helpbox", box, true, &held))
        s.help_open.clear();
    ImGui::PopID();
    ImGui::SetCursorScreenPos(p);
    ImGui::Dummy(ImVec2(width, box.GetHeight()));
    ImDrawList *dl = w->DrawList;
    dl->AddRectFilled(box.Min, box.Max, theme().game ? IM_COL32(62, 42, 30, 240) : fade(k.plate, .9f));
    dl->AddRect(box.Min, box.Max, fade(k.edge, .9f), 0, 0, std::max(1.f, line * .5f));
    dl->AddRectFilled(box.Min, ImVec2(box.Min.x + line * 1.2f, box.Max.y), k.rule);
    diamond(dl, ImVec2(box.Min.x + line * .6f, box.Min.y + f * .85f), f * .2f, k.glow);
    dl->AddText(font, size, ImVec2(box.Min.x + in - f * .4f, box.Min.y + f * .5f), held ? k.glow : k.ink, text.c_str(), nullptr, wrap);
    if (s.help_scroll) {  // (just opened: in sight, its row too)
        s.help_scroll = false;
        ImGui::ScrollToRect(w, ImRect(ImVec2(box.Min.x, box.Min.y - s.m.row), box.Max), ImGuiScrollFlags_KeepVisibleEdgeY | ImGuiScrollFlags_NoScrollParent);
    }
}
// list: a dropdown's choices, a remembered one with an x at its right that takes it out; else the view's rows (while a
// dropdown is open they keep its row marked, the focus being in the dropdown). The phone (touch_ui): taller rows, drawn
// by touch_row, with - and + on a number's; the keyboard's Delete ... Cancel six to a line (in two even lines when there
// are more: the Phone keyboard key), a dialog's choices as plates
void draw_rows(std::vector<Row> &rows, bool list = false) {
    auto *w = ImGui::GetCurrentWindow();
    bool touch = touch_ui();
    float font = ImGui::GetFontSize(), width = ImGui::GetContentRegionAvail().x;
    if (touch)
        width -= s.m.line * 3;  // (room for the scroll mark at the list's right: scroll_mark)
    bool keyboard_view = s.view == View::Keyboard && !list;
    bool passive = s.dropdown.open && !list;
    bool plated = touch && !list && (confirmation() || s.view == View::KeyCapture || s.view == View::Move);
    float gap = ImGui::GetStyle().ItemSpacing.x;
    float cell = (width - 9 * gap) / 10;
    float bs = std::min(s.m.row * .84f, font * 2.3f);  // (the phone: a - or + button's side)
    int keys = 0;  // (the keyboard's characters, first)
    for (const Row &r : rows)
        keys += keyboard_view && r.id.size() > 4 && r.id[4] >= '0' && r.id[4] <= '9';
    if (!list) {
        s.targets.clear();
        s.hovered.clear();
        s.pointing = false;
        s.dropdown.anchored = false;
    }
    std::function<void()> activate;
    std::function<void(int)> adjust;  // (a - or + tapped: its row's, by step)
    std::function<void()> remove;     // (a remembered choice's x tapped)
    std::string help_tap;             // (a row's "?" tapped)
    int step = 0;
    const float xs = touch ? forget_side() : font * 1.3f;  // (that x's side)
    // The phone: a row's help is the "?" at its right, opened under it (MENU.md: no paragraphs on the pages). A column
    // for them where a row of the view has one, so the values line up
    std::vector<int> tile_at, tile_run;  // (the phone's pages' rows: plates side by side)
    tile_runs(rows, tile_at, tile_run);
    if (!touch || list || (s.view != View::Main && s.view != View::Page))
        tile_run.assign(rows.size(), 0);
    std::vector<char> helps(rows.size(), 0);
    bool seals = false;
    if (touch && !list && !keyboard_view && !plated)
        for (size_t i = 0; i < rows.size(); i++)
            seals |= helps[i] = !rows[i].header && !tile_run[i] && !help_text(rows[i]).empty();
    const float qw = seals ? std::min(s.m.row * .66f, font * 2.3f) : 0;
    for (int i = 0; i < (int)rows.size(); i++) {
        Row &r = rows[i];
        if (r.note) {  // (a line of text: a diamond, then the text in the dimmer colour, wrapped to the list)
            ImVec2 p = ImGui::GetCursorScreenPos();
            float size = std::floor(font * .86f), indent = font * 1.15f, wrap = width - indent - font * .3f;
            ImVec2 ts = ImGui::GetFont()->CalcTextSizeA(size, FLT_MAX, wrap, r.title.c_str());
            float top = font * .3f, who = r.who.empty() ? 0 : std::floor(size * .9f);  // (a chat line's sender over it)
            float bar = r.progress >= 0 ? std::floor(font * .55f) : 0, under = bar ? std::floor(font * .35f) : 0;
            ImGui::Dummy(ImVec2(width, ts.y + top * 2 + who + under + bar));
            if (bar) {  // (a progress: a dark slot under the text, filled with the accent as the game's gauges)
                ImVec2 a(p.x + indent, p.y + top + who + ts.y + under), b(p.x + indent + wrap, a.y + bar);
                float round = std::min(bar * .5f, theme().rounding), x = a.x + (b.x - a.x) * std::clamp(r.progress, 0.f, 1.f);
                w->DrawList->AddRectFilled(a, b, IM_COL32(0, 0, 0, 120), round);
                if (x > a.x + 1) w->DrawList->AddRectFilled(a, ImVec2(x, b.y), theme().accent, round);
                w->DrawList->AddRect(a, b, fade(theme().accent, .55f), round, 0, std::max(1.f, s.m.line * .5f));
            }
            diamond(w->DrawList, ImVec2(p.x + font * .6f, p.y + top + (who ? who * .55f : size * .55f)), size * .18f,
                    r.warn ? theme().warn : theme().accent);
            if (who)
                shadow_text(w->DrawList, who, ImVec2(p.x + indent, p.y + top), r.who_mine ? theme().text_dim : theme().accent,
                            r.who.c_str());
            w->DrawList->AddText(ImGui::GetFont(), size, ImVec2(p.x + indent, p.y + top + who),
                                 r.warn ? theme().warn : r.who.empty() && !r.bright ? theme().text_dim : theme().text, r.title.c_str(),
                                 nullptr, wrap);
            continue;
        }
        if (r.header) {  // (a section's title: accent-coloured, a little apart from the rows above it)
            ImVec2 p = ImGui::GetCursorScreenPos();
            float h = font * (i ? 2.2f : 1.6f);
            ImGui::Dummy(ImVec2(width, h));
            ImFont *tf = title_font();
            w->DrawList->AddText(tf, font, ImVec2(p.x + font * .25f, p.y + h - font * 1.35f), theme().accent, r.title.c_str());
            float end = p.x + font * .75f + tf->CalcTextSizeA(font, FLT_MAX, 0, r.title.c_str()).x, y = p.y + h - font * .85f;
            if (touch && end < p.x + width)  // (the phone: a rule after it, as the game's section titles)
                w->DrawList->AddLine(ImVec2(end, y), ImVec2(p.x + width, y), fade(theme().accent, .45f),
                                     std::max(1.f, s.m.line * .5f));
            continue;
        }
        if (tile_run[i]) {  // (a page one level down: a plate of a line of them)
            const int per = width >= font * 34 ? 3 : 2, k = tile_at[i], n = tile_run[i], first = k / per * per;
            const int on = std::min(per, n - first);  // (a last line's fewer: wider)
            float tw = (width - (on - 1) * gap) / on, th = s.m.row;
            for (int j = i - k; j < i - k + n; j++)  // (the run's height: with a summary under a title, a little taller)
                if (!rows[j].value.empty())
                    th = std::max(s.m.row, font * 2.9f);
            if (k % per)
                ImGui::SameLine();
            ImVec2 p = ImGui::GetCursorScreenPos();
            ImGui::PushID(r.id.c_str());
            ImGuiID id = w->GetID("row");
            ImRect rect(p, ImVec2(p.x + tw, p.y + th));
            bool selected = passive ? r.id == s.dropdown.row : s.focus == r.id;
            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0, 0, 0, 0));
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0, 0, 0, 0));
            ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0, 0, 0, 0));
            ImGui::PushStyleColor(ImGuiCol_NavCursor, ImVec4(0, 0, 0, 0));
            ImGui::BeginDisabled(!r.enabled);
            bool clicked = ImGui::Button("###row", ImVec2(tw, th));
            bool held = ImGui::IsItemActive();
            ImGui::EndDisabled();
            ImGui::PopStyleColor(4);
            if (ImGui::IsItemHovered())
                s.hovered = r.id;
            if (selected && r.enabled && !passive)
                own_focus(w, id, rect);
            tile_draw(w->DrawList, r, rect, selected && r.enabled, held);
            s.targets.push_back({r.id, rect.GetCenter(), r.enabled});
            ImGui::PopID();
            if (clicked && r.enabled && !s.swallow) {
                focus(r.id);
                activate = r.activate;
            }
            continue;
        }
        bool key = keyboard_view && i < keys;
        bool grid = key || (touch && keyboard_view);
        int extra = (int)rows.size() - keys;  // (the keyboard's other keys)
        int per_line = key ? 10 : extra <= 6 ? 6 : (extra + 1) / 2, column = key ? i : i - keys;
        int on_line = key ? 10 : std::min(per_line, extra - column / per_line * per_line);  // (a last line's fewer: wider)
        float rw = !grid ? width - qw : !touch ? cell : (width - (on_line - 1) * gap) / on_line;
        if (grid && column % per_line)
            ImGui::SameLine();
        ImVec2 p = ImGui::GetCursorScreenPos();
        bool stepper = touch && r.number && r.adjust && !grid;
        bool toggle = touch && r.toggle >= 0 && r.enabled;
        // (the phone: the title wraps before the value's room - a switch, - value +, or the value)
        float room = r.remove ? xs + font * .6f : toggle ? font * 3.6f : stepper ? bs * 2 + font * 5.8f : r.value.empty() ? 0 : rw * .42f;
        float wrap = touch ? std::max(font, rw - font * (grid || plated ? 1.2f : 1.9f) - room)
                           : std::max(font, rw * (r.action ? 1.f : .58f) - font - (r.remove ? xs + font * .5f : 0));
        ImVec2 label = ImGui::CalcTextSize(r.title.c_str(), nullptr, false, wrap);
        float h = touch ? grid ? s.m.row : std::max(s.m.row, label.y + font * .9f)
                  : grid ? font * 2
                         : std::max(font * 2.1f, label.y + font * .8f);
        ImGui::PushID(r.id.c_str());
        ImGuiID id = w->GetID("row");
        ImRect rect(p, ImVec2(p.x + rw, p.y + h));
        bool selected = passive ? r.id == s.dropdown.row : s.focus == r.id;
        if (passive && selected)
            s.dropdown.anchor = rect, s.dropdown.anchored = true;
        const Theme &t = theme();
        ImVec4 clear(0, 0, 0, 0);  // (the phone: touch_row draws it)
        // (lit as the selection while pressed, a lighter version of it under the mouse - only while the mouse is what
        // moves, not under a pointer left there while the keys or a controller move, nor under a dropdown open)
        ImU32 base = selected && r.enabled ? t.row_focus : t.row;
        ImU32 hover = s.input == USED_MOUSE && !passive && !(selected && r.enabled) ? t.row_hover : base;
        ImGui::PushStyleColor(ImGuiCol_Button, touch ? clear : vec(base));
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, touch ? clear : vec(hover));
        ImGui::PushStyleColor(ImGuiCol_ButtonActive, touch ? clear : vec(t.row_focus));
        ImGui::PushStyleColor(ImGuiCol_NavCursor, ImVec4(0, 0, 0, 0));
        ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, t.rounding);
        ImGui::BeginDisabled(!r.enabled);
        if (stepper || r.remove)
            ImGui::SetNextItemAllowOverlap();  // (its - and +, or its x, are over it)
        bool clicked = ImGui::Button("###row", ImVec2(rw, h));
        bool held = ImGui::IsItemActive();
        ImGui::EndDisabled();
        ImGui::PopStyleVar();
        ImGui::PopStyleColor(4);
        if (!list && ImGui::IsItemHovered())
            s.hovered = r.id;
        if (!list && ImGui::IsItemHovered(ImGuiHoveredFlags_NoNavOverride))
            s.pointing = true;
        if (touch) {
            if (selected && r.enabled && !passive)
                own_focus(w, id, rect);
            touch_row(w->DrawList, r, rect, selected && r.enabled, held, grid || plated, label, wrap, room, toggle,
                      stepper);
            if (stepper) {  // - and + (held: they repeat)
                ImVec2 next = ImGui::GetCursorScreenPos();
                float right = rect.Max.x - font * .6f, cy = rect.GetCenter().y;
                for (int d = -1; d <= 1; d += 2) {
                    float x = d < 0 ? right - room : right - bs;
                    ImRect b(x, cy - bs * .5f, x + bs, cy + bs * .5f);
                    ImGui::SetCursorScreenPos(b.Min);
                    ImGui::PushItemFlag(ImGuiItemFlags_NoNav, true);
                    ImGui::PushItemFlag(ImGuiItemFlags_ButtonRepeat, true);
                    ImGui::BeginDisabled(!r.enabled);
                    // (on release, as a tap; held, it repeats: a drag that starts on it changes nothing)
                    bool hit = ImGui::InvisibleButton(d < 0 ? "###less" : "###more", ImVec2(bs, bs),
                                                      ImGuiButtonFlags_PressedOnClickRelease);
                    bool down = ImGui::IsItemActive();
                    ImGui::EndDisabled();
                    ImGui::PopItemFlag();
                    ImGui::PopItemFlag();
                    if (hit && r.enabled && !s.swallow)
                        step = d, adjust = r.adjust, focus(r.id);
                    plate(w->DrawList, b, s.m.line * .8f, down, r.enabled);
                    sign(w->DrawList, b.GetCenter(), bs * .24f, d > 0, down ? touch_look().glow : touch_look().ink,
                         std::max(2.f, s.m.line * 1.4f));
                }
                ImGui::SetCursorScreenPos(next);
            }
            if (r.remove) {  // (a remembered choice: its x, a plate of its own at the right, takes it out of the list)
                ImVec2 next = ImGui::GetCursorScreenPos();
                float right = rect.Max.x - font * .6f, cy = rect.GetCenter().y;
                ImRect b(right - xs, cy - xs * .5f, right, cy + xs * .5f);
                bool down = false;
                if (touch_button("###forget", b, true, &down))
                    remove = r.remove;
                plate(w->DrawList, b, s.m.line * .8f, down, true);
                cross(w->DrawList, b.GetCenter(), xs * .2f, down || selected ? touch_look().glow : touch_look().ink,
                      std::max(2.f, s.m.line * 1.3f));
                ImGui::SetCursorScreenPos(next);
            }
            if (helps[i] && !grid) {  // (its "?": a tap opens its help under it, another closes it)
                ImVec2 next = ImGui::GetCursorScreenPos();
                float cx = p.x + width - qw * .5f, cy = rect.GetCenter().y, rad = std::min(qw, s.m.row) * .34f;
                ImRect b(cx - qw * .5f, rect.Min.y, cx + qw * .5f, rect.Max.y);
                bool down = false;
                if (touch_button("###help", b, true, &down))
                    help_tap = r.id;
                help_seal(w->DrawList, ImVec2(cx, cy), rad, s.help_open == r.id, down);
                ImGui::SetCursorScreenPos(next);
            }
            s.targets.push_back({r.id, rect.GetCenter(), r.enabled});
            ImGui::PopID();
            if (clicked && r.enabled && !s.swallow) {
                focus(r.id);
                activate = r.activate;
            }
            if (helps[i] && s.help_open == r.id)
                help_box(w, r, width);
            continue;
        }
        if (selected && r.enabled) {
            if (!passive)
                own_focus(w, id, rect);
            if (t.bar)
                w->DrawList->AddRectFilled(rect.Min, ImVec2(rect.Min.x + font * .22f, rect.Max.y), t.accent,
                                           t.rounding, ImDrawFlags_RoundCornersLeft);
            else if (!t.game)
                w->DrawList->AddRect(rect.Min, rect.Max, t.accent, t.rounding, 0, 2.f);
        }
        if (held && r.enabled)  // (pressed: brighter still, the selected row too)
            w->DrawList->AddRectFilled(rect.Min, rect.Max, IM_COL32(255, 240, 200, 38), t.rounding);
        if (t.game && !grid)  // (Hunter: a line under each row)
            w->DrawList->AddLine(ImVec2(rect.Min.x, rect.Max.y + ImGui::GetStyle().ItemSpacing.y * .5f),
                                 ImVec2(rect.Max.x, rect.Max.y + ImGui::GetStyle().ItemSpacing.y * .5f), t.divider,
                                 2.f);
        w->DrawList->PushClipRect(rect.Min, rect.Max, true);
        ImU32 ink = !r.enabled ? t.text_off : selected && t.bar ? t.accent_bright : t.text;
        ImU32 value_ink = r.warn ? IM_COL32(255, 110, 96, 255) : ink;
        if (r.current)  // (the dropdown's choice now: a bar on its left)
            w->DrawList->AddRectFilled(rect.Min, ImVec2(rect.Min.x + font * .22f, rect.Max.y), t.accent,
                                       t.rounding, ImDrawFlags_RoundCornersLeft);
        w->DrawList->AddText(ImGui::GetFont(), font, ImVec2(p.x + font * .5f, p.y + (h - label.y) * .5f), ink,
                             r.title.c_str(), nullptr, wrap);
        float arrow = 0;
        if (r.menu && r.enabled) {  // (Confirm opens a dropdown: an arrow after the value)
            arrow = font * 1.1f;
            ImGui::RenderArrow(w->DrawList, ImVec2(p.x + rw - font * .5f - font * .7f, p.y + (h - font) * .5f), ink,
                               s.dropdown.open && s.dropdown.row == r.id ? ImGuiDir_Up : ImGuiDir_Down, .7f);
        } else if (r.enabled && !r.id.compare(0, 5, "page.")) {  // (a page one level down: a chevron, as on a phone)
            arrow = font * 1.1f;
            chevron(w->DrawList, ImVec2(p.x + rw - font * .9f, p.y + h * .5f), font * .26f, 1, ink, 1.5f);
        }
        if (!r.value.empty()) {
            std::string value = r.value + (r.cold ? " *" : "");
            fit(value, rw * .38f - font - arrow);
            auto sz = ImGui::CalcTextSize(value.c_str());
            w->DrawList->AddText(ImVec2(p.x + rw - font * .5f - arrow - sz.x, p.y + (h - font) * .5f), value_ink,
                                 value.c_str());
        }
        w->DrawList->PopClipRect();
        if (r.remove) {  // (a remembered choice: an x at its right takes it out of the list)
            ImVec2 next = ImGui::GetCursorScreenPos();
            ImRect b(p.x + rw - font * .4f - xs, p.y + (h - xs) * .5f, p.x + rw - font * .4f, p.y + (h + xs) * .5f);
            ImGui::SetCursorScreenPos(b.Min);
            ImGui::PushItemFlag(ImGuiItemFlags_NoNav, true);
            if (ImGui::InvisibleButton("###forget", b.GetSize()) && !s.swallow)
                remove = r.remove;
            bool lit = ImGui::IsItemHovered() || ImGui::IsItemActive();
            ImGui::PopItemFlag();
            if (lit)
                w->DrawList->AddRectFilled(b.Min, b.Max, t.row_hover, t.rounding);
            cross(w->DrawList, b.GetCenter(), xs * .24f, lit || selected ? t.accent_bright : t.text_dim, 2.f);
            ImGui::SetCursorScreenPos(next);
        }
        s.targets.push_back({r.id, rect.GetCenter(), r.enabled});
        ImGui::PopID();
        if (clicked && r.enabled && !s.swallow) {  // (not the click that closed the dropdown: back_keys)
            focus(r.id);
            activate = r.activate;
        }
    }
    if (remove) {  // (the list changes under it: the picker opens again, reopen_picker)
        remove();
        return;
    }
    if (!help_tap.empty())
        toggle_help(help_tap);
    if (adjust)
        adjust(step);
    if (activate)
        activate();
}
#ifndef __ANDROID__
// ---------------------------------------------------------------- coming in and going out (a desktop's menu)
// The menu, its dropdown and its views come in with a short fade and a small slide; the menu and the dropdown go out
// with a fade. Only what is drawn moves, never where input lands: the menu takes input from its first frame, and once
// closed it takes none - its fade out is a copy of its last frame, drawn with no window (settings_panel_after_render)
constexpr double ANIM_IN = .14, ANIM_OUT = .12;  // (seconds)
// How far an animation that began at `since` has come: 0 .. 1, easing out (1: over, or none)
float anim_in(double since) {
    if (since < 0)
        return 1;
    float t = (float)std::clamp((anim_now() - since) / ANIM_IN, 0.0, 1.0);
    return 1 - (1 - t) * (1 - t) * (1 - t);
}
// What a draw list holds from vertex `from` to `to`, faded by alpha and moved by off; clips: its commands' clip
// rectangles moved too (a whole window's)
void tween_list(ImDrawList *dl, int from, int to, float alpha, ImVec2 off, bool clips) {
    for (int i = from; i < to; i++) {
        ImDrawVert &v = dl->VtxBuffer[i];
        v.pos.x += off.x, v.pos.y += off.y;
        v.col = fade(v.col, alpha);
    }
    if (clips && (off.x || off.y))
        for (ImDrawCmd &c : dl->CmdBuffer)
            c.ClipRect.x += off.x, c.ClipRect.y += off.y, c.ClipRect.z += off.x, c.ClipRect.w += off.y;
}
// A window as drawn this frame, its child windows too
void tween_window(ImGuiWindow *w, float alpha, ImVec2 off) {
    tween_list(w->DrawList, 0, w->DrawList->VtxBuffer.Size, alpha, off, true);
    for (ImGuiWindow *c : w->DC.ChildWindows)
        if (c->Active)
            tween_window(c, alpha, off);
}
// What closed, fading: copies of a window's lists as last drawn (its child windows' after its own), when it closed,
// how far it slides as it goes
struct Ghost {
    std::vector<ImDrawList *> lists;
    double at;
    ImVec2 slide;
};
std::vector<Ghost> ghosts;
std::vector<ImDrawList *> ghost_shown;  // (this frame's faded copies, given to the draw data)
void ghost_copy(ImGuiWindow *w, bool now, std::vector<ImDrawList *> &out) {
    out.push_back(w->DrawList->CloneOutput());
    for (ImGuiWindow *c : w->DC.ChildWindows)
        if (now ? c->Active : c->WasActive)
            ghost_copy(c, now, out);
}
// w as drawn this frame (now), or as last drawn: a window left out of this frame still holds that one's lists
void ghost_take(ImGuiWindow *w, bool now, ImVec2 slide) {
    if (!w)
        return;
    Ghost g = {{}, anim_now(), slide};
    ghost_copy(w, now, g.lists);
    ghosts.push_back(std::move(g));
}
void ghosts_clear() {
    for (Ghost &g : ghosts)
        for (ImDrawList *l : g.lists)
            IM_DELETE(l);
    ghosts.clear();
}
#endif
// The open dropdown, a window of its own over the menu: under its row, at the right, or above the row when there is
// more room there; it scrolls when it doesn't fit. scale, base: the menu's (settings_panel)
void draw_dropdown(std::vector<Row> &options, float scale, float base) {
    ImGuiViewport *vp = ImGui::GetMainViewport();
    const ImGuiStyle &style = ImGui::GetStyle();
    float font = base * scale, longest = 0;
    for (const auto &o : options)  // (a remembered one: and its x)
        longest = std::max(longest, (ImGui::CalcTextSize(o.title.c_str()).x + (o.remove ? base * 2.2f : 0)) * scale);
    const ImRect &a = s.dropdown.anchor;
    float w = std::clamp(longest + font * 2 + style.WindowPadding.x * 2, a.GetWidth() * .4f, a.GetWidth());
    float h = options.size() * (font * 2.1f + style.ItemSpacing.y) - style.ItemSpacing.y + style.WindowPadding.y * 2;
    float below = vp->WorkPos.y + vp->WorkSize.y - a.Max.y, above = a.Min.y - vp->WorkPos.y;
    bool up = h > below && above > below;
    h = std::min(h, up ? above : below);
    ImGui::SetNextWindowPos(ImVec2(a.Max.x - w, up ? a.Min.y - h : a.Max.y), ImGuiCond_Always);
    ImGui::SetNextWindowSize(ImVec2(w, h), ImGuiCond_Always);
    ImGui::PushStyleColor(ImGuiCol_WindowBg, vec(theme().popup));
    ImGui::PushStyleColor(ImGuiCol_Border, vec(theme().edge));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 1.f);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, theme().rounding);
    ImGui::Begin("Settings##dropdown", nullptr,
                 ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove |
                     ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoSavedSettings);
    ImGui::SetWindowFontScale(scale);
    draw_rows(options, true);
    s.dropdown.hovered = ImGui::IsWindowHovered();
#ifndef __ANDROID__
    ImGuiWindow *list = ImGui::GetCurrentWindow();
#endif
    ImGui::End();
    ImGui::PopStyleVar(2);
    ImGui::PopStyleColor(2);
#ifndef __ANDROID__
    float in = anim_in(s.dropdown_at);  // (it comes out of its row: down from it, or up above it)
    if (in < 1)
        tween_window(list, in, ImVec2(0, (up ? 1 : -1) * (1 - in) * font * .6f));
    s.dropdown_up = up;
#endif
}
// Hunter's window frame, over the rest: a red rule with a green one inside it along the top and the bottom, and a gold
// square on each corner
void draw_frame(ImGuiWindow *w, const Theme &look) {
    if (!look.game)
        return;
    const ImU32 red = IM_COL32(176, 34, 30, 255), green = IM_COL32(80, 142, 54, 255), gold = IM_COL32(222, 190, 40, 255);
    float b = w->WindowBorderSize, x0 = w->Pos.x + b, x1 = w->Pos.x + w->Size.x - b, y0 = w->Pos.y + b,
          y1 = w->Pos.y + w->Size.y - b, line = std::max(2.f, ImGui::GetFontSize() * .14f);
    w->DrawList->PushClipRectFullScreen();
    w->DrawList->AddRectFilled(ImVec2(x0, y0), ImVec2(x1, y0 + line), red);
    w->DrawList->AddRectFilled(ImVec2(x0, y0 + line), ImVec2(x1, y0 + line * 1.7f), green);
    w->DrawList->AddRectFilled(ImVec2(x0, y1 - line * 1.7f), ImVec2(x1, y1 - line), green);
    w->DrawList->AddRectFilled(ImVec2(x0, y1 - line), ImVec2(x1, y1), red);
    float c = ImGui::GetFontSize() * .5f;
    for (ImVec2 corner : {w->Pos, ImVec2(w->Pos.x + w->Size.x, w->Pos.y), ImVec2(w->Pos.x, w->Pos.y + w->Size.y),
                          ImVec2(w->Pos.x + w->Size.x, w->Pos.y + w->Size.y)}) {
        ImVec2 a(corner.x - c * .5f, corner.y - c * .5f), z(corner.x + c * .5f, corner.y + c * .5f);
        w->DrawList->AddRectFilled(a, z, IM_COL32(0, 0, 0, 255));
        w->DrawList->AddRect(ImVec2(a.x + 1, a.y + 1), ImVec2(z.x - 1, z.y - 1), gold, 0, 0, std::max(1.f, c * .16f));
        w->DrawList->AddRectFilled(ImVec2(corner.x - c * .14f, corner.y - c * .14f),
                                   ImVec2(corner.x + c * .14f, corner.y + c * .14f), gold);
    }
    w->DrawList->PopClipRect();
}
// The corner grip that sizes the menu (mouse_drag): three short lines across the bottom right corner
float grip_size() { return ImGui::GetFontSize() * 1.3f; }
void draw_grip(ImGuiWindow *w, const Theme &look) {
    ImVec2 corner(w->Pos.x + w->Size.x, w->Pos.y + w->Size.y);
    float g = grip_size(), inset = look.bar ? g * .35f : g * .2f;
    bool lit =
        s.dragging == 2 || ImRect(ImVec2(corner.x - g, corner.y - g), corner).Contains(ImGui::GetIO().MousePos);
    w->DrawList->PushClipRectFullScreen();
    for (int i = 1; i <= 3; i++) {
        float d = g * .22f * i;
        w->DrawList->AddLine(ImVec2(corner.x - inset - d, corner.y - inset),
                             ImVec2(corner.x - inset, corner.y - inset - d), lit ? look.accent : look.text_off, 1.5f);
    }
    w->DrawList->PopClipRect();
}
// The mouse on the menu, before it is drawn: a press on its top part (the tabs, or a dialog's title) and a drag moves
// it, one on the grip at its bottom right corner sizes it. Either one detaches it (Menu Options: Attach menu puts it back).
void mouse_drag(ImGuiViewport *vp, float width) {
    ImGuiIO &io = ImGui::GetIO();
    auto *w = ImGui::FindWindowByName("Settings##main");
    if (!w || s.view == View::Move)
        return;
    if (ImGui::IsMouseClicked(ImGuiMouseButton_Left) && !s.dropdown.open) {
        float g = grip_size();
        ImVec2 corner(w->Pos.x + w->Size.x, w->Pos.y + w->Size.y);
        s.dragged = false;
        bool grip = ImRect(ImVec2(corner.x - g, corner.y - g), corner).Contains(io.MousePos);
        bool top = ImRect(w->Pos, ImVec2(corner.x, w->Pos.y + s.header_bottom)).Contains(io.MousePos);
        s.dragging = grip ? 2 : top ? 1 : 0;
        s.drag_mouse = io.MousePos;
        s.drag_from = s.dragging == 2 ? w->Size : w->Pos;
    }
    if (!s.dragging)
        return;
    if (!ImGui::IsMouseDown(ImGuiMouseButton_Left)) {
        s.dragging = 0;
        return;
    }
    ImVec2 d(io.MousePos.x - s.drag_mouse.x, io.MousePos.y - s.drag_mouse.y);
    if (!s.dragged && d.x * d.x + d.y * d.y < io.MouseDragThreshold * io.MouseDragThreshold)
        return;
    s.dragged = true;
    if (!s.floating) {
        s.floating = true;
        s.move_position = w->Pos;
    }
    if (s.dragging == 2) {
        s.custom_size = ImVec2(s.drag_from.x + d.x, s.drag_from.y + d.y);
        s.move_position = w->Pos;
    } else {
        float h = w->Size.y;
        s.move_position.x = std::clamp(s.drag_from.x + d.x, vp->WorkPos.x - width * .5f,
                                       vp->WorkPos.x + vp->WorkSize.x - width * .5f);
        s.move_position.y = std::clamp(s.drag_from.y + d.y, vp->WorkPos.y,
                                       vp->WorkPos.y + std::max(0.f, vp->WorkSize.y - h * .25f));
    }
    s.position_override = true;
}
// Back (B, Esc, the Android Back key, F1 / the chord: request_back), and a click away from an open dropdown. A
// desktop's: a click on the game, away from every window of the menu, is Back too (a dialog or a page left, the menu
// closed - asking first when something is unsaved); the game never sees it (runtime/overlay.cpp keeps the mouse's
// events while the menu is open)
void back_keys(bool *open) {
    if (request_back.exchange(false) || pressed(ImGuiKey_GamepadFaceRight) || pressed(ImGuiKey_Escape) ||
        pressed(ImGuiKey_AppBack))
        ask_back(open);
    bool click = ImGui::IsMouseClicked(ImGuiMouseButton_Left);
#ifndef __ANDROID__
    bool right = ImGui::IsMouseClicked(ImGuiMouseButton_Right);
#else
    bool right = false;
#endif
    if (s.dropdown.open && (click || right) && !s.dropdown.hovered) {
        close_dropdown();  // (a click elsewhere only closes it, as a system's list does - the phone's picker covers the
        s.swallow = true;  // menu: the tap only closes it; a desktop's row under the click isn't chosen as well)
    }
#ifndef __ANDROID__
    else if ((click || right) && !touch_ui() && !ImGui::GetCurrentContext()->HoveredWindow) {
        ask_back(open);
        s.swallow = true;
    }
#endif
}
// The tabs' keys: Save from anywhere on a tab (the top face button, or Ctrl+S), L / R the tab before / after - on a
// desktop's keyboard Q / E, or Ctrl+Shift+Tab / Ctrl+Tab
void page_keys() {
    ImGuiIO &io = ImGui::GetIO();
    if ((pressed(ImGuiKey_GamepadFaceUp) || (io.KeyCtrl && pressed(ImGuiKey_S))) && dirty() && !s.dropdown.open)
        s.command = Command::Save;
    bool next = pressed(ImGuiKey_GamepadR1), before = pressed(ImGuiKey_GamepadL1);
#ifndef __ANDROID__
    bool ctrl_tab = io.KeyCtrl && pressed(ImGuiKey_Tab, true);
    next |= (ctrl_tab && !io.KeyShift) || (!io.KeyCtrl && !io.KeyAlt && pressed(ImGuiKey_E));
    before |= (ctrl_tab && io.KeyShift) || (!io.KeyCtrl && !io.KeyAlt && pressed(ImGuiKey_Q));
#endif
    if (next)
        first_page((s.page + 1) % PAGES);
    if (before)
        first_page((s.page + PAGES - 1) % PAGES);
}
// The Keyboard view's keys from a real keyboard: typed text, Backspace / Delete, Ctrl+V / Ctrl+A, Enter; L / R move
// the cursor
void keyboard_keys() {
    ImGuiIO &io = ImGui::GetIO();
    for (ImWchar ch : io.InputQueueCharacters) {
        if (ch < 0x20 || ch == 0x7f)  // (a phone's keyboard can send its Enter as a line break too)
            continue;
        char utf8[5];
        int n = ImTextCharToUtf8(utf8, ch);
        utf8[n] = 0;
        insert(utf8);
    }
    if (pressed(ImGuiKey_Backspace, true))
        erase_previous();
    if (io.KeyCtrl && pressed(ImGuiKey_V)) {
        char *clip = SDL_GetClipboardText();
        if (clip) {
            insert(clip);
            SDL_free(clip);
        }
    }
    if (io.KeyCtrl && pressed(ImGuiKey_A))
        s.keyboard.select_all = true;
    if (pressed(ImGuiKey_Delete, true) && s.keyboard.select_all)
        erase_previous();
    else if (pressed(ImGuiKey_Delete, true) && s.keyboard.cursor < s.keyboard.buffer.size()) {
        size_t n = s.keyboard.cursor + 1;
        while (n < s.keyboard.buffer.size() && ((unsigned char)s.keyboard.buffer[n] & 0xc0) == 0x80)
            ++n;
        s.keyboard.buffer.erase(s.keyboard.cursor, n - s.keyboard.cursor);
    }
    if (pressed(ImGuiKey_GamepadL1, true) && s.keyboard.cursor) {
        --s.keyboard.cursor;
        while (s.keyboard.cursor && ((unsigned char)s.keyboard.buffer[s.keyboard.cursor] & 0xc0) == 0x80)
            --s.keyboard.cursor;
    }
    if (pressed(ImGuiKey_GamepadR1, true) && s.keyboard.cursor < s.keyboard.buffer.size()) {
        ++s.keyboard.cursor;
        while (s.keyboard.cursor < s.keyboard.buffer.size() &&
               ((unsigned char)s.keyboard.buffer[s.keyboard.cursor] & 0xc0) == 0x80)
            ++s.keyboard.cursor;
    }
    if (pressed(ImGuiKey_Enter))
        accept_keyboard();
}
// A view's title (not the tabs')
std::string view_title() {
    if (s.view == View::Page)
        return page_path(s.at);
#ifndef __ANDROID__
    if (s.view == View::Remove)
        return removal_question();
#endif
    return s.view == View::Keyboard ? s.keyboard.title
           : s.view == View::KeyCapture && s.capture_bind >= 0
               ? fmt("Press a key or mouse button for %s (Esc: cancel)", tr(bind_titles[s.capture_bind]))
               : tr(s.view == View::Exit         ? "Exit game?"
                    : s.view == View::Restart    ? "Restart game?"
                    : s.view == View::Reset      ? (s.reset_at.find('/') == std::string::npos ? "Reset this section?" : "Reset this page?")
                    : s.view == View::Move       ? "Move menu"
                    : s.view == View::Conflicts  ? "Mod conflicts"
                    : s.view == View::Keybinds   ? "Keybinds"
                    : s.view == View::TouchButtons ? (touch_rows() && !s_combos_alone ? "Buttons on the screen" : "Combined buttons")
                    : s.view == View::ComboEdit  ? "Combined button"
                    : s.view == View::Profiles   ? "Control profiles"
                    : s.view == View::ProfileSlot ? "Control profile"
                    : s.view == View::PadList    ? "Map a controller"
                    : s.view == View::PadMap     ? "Map a controller"
                    : s.view == View::KeyCapture ? "Press the key for chat (Esc: cancel)"
                    : s.view == View::ImportSave ? "Import this save? The characters here are replaced by its own and the game restarts; the current save is kept in a copy."
                    : s.view == View::Licenses   ? "Licenses"
                    : s.view == View::Verify     ? "Verify game files"
                    : s.view == View::OpenSite   ? "Open the project's page?"
                    : s.view == View::OpenDiscord ? "Open the community's Discord?"
                    : s.view == View::Chat       ? cs("Chat", "Chat")
                    : s.view == View::Friends    ? cs("Friends", "Amigos")
                    : s.view == View::ChatOn     ? cs("Turn on the online chat?", "¿Activar el chat en línea?")
                                                 : "Unsaved changes");
}
// What a dialog's question means, under it (empty: the question says it all)
std::string view_detail() {
    return s.view == View::OpenSite
               ? tr("It opens in your browser. On phones with little memory, Android may close the game, so save in the game first.")
           : s.view == View::OpenDiscord
               ? tr("It opens in your browser or the Discord app. On phones with little memory, Android may close the game, so save in the game first.")
           : s.view == View::ChatOn ? chat_on_detail()
               : "";
}
const char *saved_text() {
    return tr((config_restart_required(&s.draft) || mods_restart()) ? "Saved - restart pending" : "Saved");
}
// What a row or a key asked for this frame (Save), and what the draft's changes undo (the "Saved" notice)
void commands(const Config &before) {
    if (s.command != Command::None) {
        auto cmd = s.command;
        s.command = Command::None;
        // (the Save row is greyed once saved: Reset is picked; the phone's header Save leaves the row picked be)
        if (cmd == Command::Save && save() && (!touch_ui() || s.focus == "save"))
            focus("reset");
    }
    if (!equal(before, s.draft) && dirty())
        s.saved_notice = false;
    if (ui_action_failed())
        s.error = tr("Restart failed. The game is still running.");
}
// ---------------------------------------------------------------- the phone's menu (touch_ui)
const ImGuiWindowFlags fixed_window = ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize |
                                      ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoCollapse |
                                      ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoScrollbar |
                                      ImGuiWindowFlags_NoScrollWithMouse;
// A finger dragged on a list scrolls it: a press that moves less than ~2% of the screen's height is still a tap, past
// that the row or button under it lets go. Let go, the list glides on and slows to a stop; a tap on a gliding list
// only stops it. w: the list (a child window), after its rows
void finger_scroll(ImGuiWindow *w) {
    ImGuiContext &g = *ImGui::GetCurrentContext();
    ImGuiIO &io = g.IO;
    Drag &d = s.drag;
    float dt = std::max(io.DeltaTime, 1e-4f);
    if (ImGui::IsMouseClicked(ImGuiMouseButton_Left) && g.HoveredWindow == w) {
        if (d.window == w->ID && std::fabs(d.velocity) > s.m.H * .3f)
            s.swallow = true;
        d = {w->ID, io.MousePos.y, w->Scroll.y, w->Scroll.y, 0, true, false};
    }
    if (d.window != w->ID)
        return;
    if (d.pressed && ImGui::IsMouseDown(ImGuiMouseButton_Left)) {
        if (!d.moving && std::fabs(io.MousePos.y - d.from) > s.m.H * .022f) {
            d.moving = true;
            d.from = io.MousePos.y, d.scroll = d.last = w->Scroll.y;  // (from here: no jump by the threshold)
            ImGui::ClearActiveID();  // (the row or the button under the finger: not tapped after all)
            s.swallow = true;
        }
        if (d.moving) {
            float to = std::clamp(d.scroll - (io.MousePos.y - d.from), 0.f, w->ScrollMax.y);
            d.velocity = d.velocity * .5f + (to - d.last) / dt * .5f;
            d.last = to;
            ImGui::SetScrollY(w, to);
        }
        return;
    }
    if (d.pressed) {  // (let go: a drag glides on, a tap doesn't)
        d.pressed = false;
        if (!d.moving)
            d.velocity = 0;
        d.moving = false;
    }
    if (d.velocity) {
        float to = std::clamp(w->Scroll.y + d.velocity * dt, 0.f, w->ScrollMax.y);
        ImGui::SetScrollY(w, to);
        d.velocity *= std::exp(-dt * 4.f);
        if (std::fabs(d.velocity) < s.m.H * .05f || to <= 0 || to >= w->ScrollMax.y)
            d.velocity = 0;
    }
}
// A thin gold mark at a list's right: how much of it shows, how far down it is
void scroll_mark(ImGuiWindow *w) {
    if (w->ScrollMax.y < 1)
        return;
    const Look k = touch_look();
    float view = w->Size.y, line = s.m.line, bar = std::max(view * view / (view + w->ScrollMax.y), s.m.row * .5f);
    float y = w->Pos.y + (view - bar) * std::clamp(w->Scroll.y / w->ScrollMax.y, 0.f, 1.f);
    float x = w->Pos.x + w->Size.x - line * 1.5f;
    w->DrawList->AddRectFilled(ImVec2(x, w->Pos.y), ImVec2(x + line, w->Pos.y + view), fade(k.rule, .18f));
    w->DrawList->AddRectFilled(ImVec2(x - line * .25f, y), ImVec2(x + line * 1.25f, y + bar), fade(k.rule, .9f));
}
// The phone's picker: a row's choices in a plate of their own in the middle of the screen, over the menu dimmed; a
// tap picks one, a tap away from it, its X or Back closes it. scale: the menu's (touch_panel)
void touch_picker(std::vector<Row> &options, float scale) {
    ImGuiViewport *vp = ImGui::GetMainViewport();
    const Theme &look = theme();
    const Look k = touch_look();
    ImFont *font = ImGui::GetFont();
    float f = s.m.f, pad = s.m.pad, line = s.m.line, spacing = ImGui::GetStyle().ItemSpacing.y;
    float band = std::max(f * 2.4f, s.m.row * .95f), side = band * .74f, title = std::floor(f * 1.05f);
    float frame = std::max(2.f, f * .14f) * 1.7f;  // (draw_frame's rules at the bottom)
    // (its row's help, opened by the "?" in the band: over the choices, in the help's own plate)
    const bool helped = !s.dropdown.help.empty(), helping = helped && s.dropdown.show_help;
    // (the title whole beside its X, and its "?" when it has one: on a narrow screen it would be cut)
    float longest = title_font()->CalcTextSizeA(title, FLT_MAX, 0, s.dropdown.title.c_str()).x + side + pad * 3 +
                    (helped ? side + pad : 0);
    for (const auto &o : options)  // (a remembered one: and its x)
        longest = std::max(longest, font->CalcTextSizeA(f, FLT_MAX, 0, o.title.c_str()).x + f * 3.4f +
                                        (o.remove ? forget_side() + f * .6f : 0));
    float w = std::clamp(longest + pad * 2, vp->WorkSize.x * .32f, vp->WorkSize.x * .62f);
    const float hsize = std::floor(f * .84f), hwrap = w - pad * 2 - f * 1.4f;
    const float help_h = helping ? font->CalcTextSizeA(hsize, FLT_MAX, hwrap, s.dropdown.help.c_str()).y + f * 1.0f + spacing : 0;
    float h = std::min(band + line * 2 + pad * 2 + help_h + options.size() * (s.m.row + spacing) + pad + frame,
                       vp->WorkSize.y * .86f);
    ImGui::SetNextWindowPos(
        ImVec2(vp->WorkPos.x + (vp->WorkSize.x - w) * .5f, vp->WorkPos.y + (vp->WorkSize.y - h) * .5f),
        ImGuiCond_Always);
    ImGui::SetNextWindowSize(ImVec2(w, h), ImGuiCond_Always);
    ImGui::PushStyleColor(ImGuiCol_WindowBg, vec(look.popup));
    ImGui::Begin("Settings##dropdown", nullptr, fixed_window);
    ImGui::SetWindowFontScale(scale);
    auto *win = ImGui::GetCurrentWindow();
    auto *dl = win->DrawList;
    float x0 = win->Pos.x, y0 = win->Pos.y, x1 = x0 + win->Size.x, by = y0 + (band - side) * .5f + line * .5f;
    dl->AddRectFilled(ImVec2(x0, y0), ImVec2(x1, y0 + band), k.band);
    if (look.game) {
        dl->AddRectFilled(ImVec2(x0, y0 + band), ImVec2(x1, y0 + band + line), IM_COL32(176, 34, 30, 255));
        dl->AddRectFilled(ImVec2(x0, y0 + band + line), ImVec2(x1, y0 + band + line * 1.7f),
                          IM_COL32(80, 142, 54, 255));
    }
    ImRect shut(x1 - pad - side, by, x1 - pad, by + side);
    bool held = false;
    if (touch_button("###shut", shut, true, &held))
        close_dropdown();
    plate(dl, shut, line, held, true);
    cross(dl, shut.GetCenter(), side * .2f, held ? k.glow : k.ink, std::max(2.f, line * 1.5f));
    float title_end = shut.Min.x - pad * .5f;
    if (helped) {  // (its "?", left of the X)
        ImRect q(shut.Min.x - pad - side, by, shut.Min.x - pad, by + side);
        bool down = false;
        if (touch_button("###pickhelp", q, true, &down))
            s.dropdown.show_help = !s.dropdown.show_help;
        help_seal(dl, q.GetCenter(), side * .4f, s.dropdown.show_help, down);
        title_end = q.Min.x - pad * .5f;
    }
    // (a title longer than the plate allows, its widest on a narrow screen: smaller, to fit whole)
    float tsize = title;
    ImVec2 ts = title_font()->CalcTextSizeA(tsize, FLT_MAX, 0, s.dropdown.title.c_str());
    const float room = title_end - (x0 + pad * 1.5f);
    if (ts.x > room && room > 0) {
        tsize = std::floor(std::max(title * room / ts.x, title * .6f));
        ts = title_font()->CalcTextSizeA(tsize, FLT_MAX, 0, s.dropdown.title.c_str());
    }
    dl->PushClipRect(ImVec2(x0, y0), ImVec2(title_end, y0 + band), true);
    shadow_text(dl, title_font(), tsize, ImVec2(x0 + pad * 1.5f, by + side * .5f - ts.y * .5f), k.glow, s.dropdown.title.c_str());
    dl->PopClipRect();
    ImGui::SetCursorScreenPos(ImVec2(x0 + pad, y0 + band + line * 2 + pad));
    ImGui::BeginChild("##choices",
                      ImVec2(win->Size.x - pad * 2, std::max(1.f, h - band - line * 2 - pad * 2 - frame)),
                      ImGuiChildFlags_None, ImGuiWindowFlags_NoScrollbar);
    ImGui::SetWindowFontScale(scale);
    auto *choices = ImGui::GetCurrentWindow();
    if (helping) {  // (the row's help, as a row's opened one)
        ImVec2 p = ImGui::GetCursorScreenPos();
        float cw = ImGui::GetContentRegionAvail().x - s.m.line * 3;
        ImRect box(p, ImVec2(p.x + cw, p.y + help_h - spacing));
        ImGui::Dummy(box.GetSize());
        choices->DrawList->AddRectFilled(box.Min, box.Max, theme().game ? IM_COL32(62, 42, 30, 240) : fade(k.plate, .9f));
        choices->DrawList->AddRect(box.Min, box.Max, fade(k.edge, .9f), 0, 0, std::max(1.f, line * .5f));
        choices->DrawList->AddRectFilled(box.Min, ImVec2(box.Min.x + line * 1.2f, box.Max.y), k.rule);
        diamond(choices->DrawList, ImVec2(box.Min.x + line * .6f, box.Min.y + f * .85f), f * .2f, k.glow);
        choices->DrawList->AddText(font, hsize, ImVec2(box.Min.x + f * .7f, box.Min.y + f * .5f), k.ink, s.dropdown.help.c_str(), nullptr, hwrap);
    }
    draw_rows(options, true);
    ImGui::Dummy(ImVec2(1, pad));
    finger_scroll(choices);
    scroll_mark(choices);
    ImGui::EndChild();
    s.dropdown.hovered = ImGui::IsWindowHovered(ImGuiHoveredFlags_ChildWindows);
    draw_frame(win, look);
    ImGui::End();
    ImGui::PopStyleColor();
}
// The phone's menu: nearly the whole screen - a header with the title, Back (in a submenu or a dialog), Save and Close
// (X); the tabs in a column at the left, the rows in a list a finger drags, the picked row's help at the right (under
// the rows where the screen is narrower). The rows, what they do and the dialogs are the controller's (rows_for_view),
// which still works it as before. before: the draft as the frame began
void touch_panel(bool *open, const Config &before) {
    ImGuiViewport *vp = ImGui::GetMainViewport();
    const Theme &look = theme();
    const Look k = touch_look();
    float H = vp->WorkSize.y, base = ImGui::GetFontSize();
    float scale = std::clamp(.034f * H * s.draft.menu_scale / 100.f, .022f * H, .05f * H) / base;
    ImVec2 panel(std::min(vp->WorkSize.x * .92f, H * 2.6f), H * .92f);
    ImGui::SetNextWindowPos(ImVec2(vp->WorkPos.x + (vp->WorkSize.x - panel.x) * .5f,
                                   vp->WorkPos.y + (vp->WorkSize.y - panel.y) * .5f),
                            ImGuiCond_Always);
    ImGui::SetNextWindowSize(panel, ImGuiCond_Always);
    ImGui::PushStyleColor(ImGuiCol_WindowBg, vec(look.panel));
    ImGui::PushStyleColor(ImGuiCol_ChildBg, ImVec4(0, 0, 0, 0));
    ImGui::PushStyleColor(ImGuiCol_Text, vec(look.text));
    ImGui::PushStyleColor(ImGuiCol_Border, vec(look.edge));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, look.game ? 0.f : look.rounding * 2);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 2.f);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
    ImGui::Begin("Settings##main", nullptr, fixed_window);
    ImGui::SetWindowFontScale(scale);
    auto *window = ImGui::GetCurrentWindow();
    auto *dl = window->DrawList;
    ImFont *font = ImGui::GetFont();
    float f = ImGui::GetFontSize();
    s.m.H = H, s.m.f = f, s.m.row = std::max(.09f * H, f * 2.4f), s.m.pad = .014f * H, s.m.line = std::max(2.f, .0035f * H);
    float pad = s.m.pad, line = s.m.line;
    s.guide_height = 0;  // (own_focus: the list scrolls to the row picked)
    back_keys(open);
    if (s.view == View::Main || s.view == View::Page)
        page_keys();
    if (s.view == View::Keyboard)
        keyboard_keys();
    auto rows = rows_for_view(open);
    reopen_picker(rows);
    picker_help(rows);
    std::vector<Row> options;  // (a dropdown open: the picker's, the controller moves in it)
    if (s.dropdown.open)
        options = dropdown_rows();
    if (s.view == View::Move)
        focus("move.accept");
    else
        navigate(s.dropdown.open ? options : rows, s.dropdown.open);
    picker_keys(options);
    help_keys(rows);
    bool dialog = confirmation() || s.view == View::KeyCapture || s.view == View::Move;
    bool picking = s.dropdown.open && !options.empty();  // (the picker over the menu this frame: the menu dimmed)
    // The header: Back at its left, the community's Discord and the official page (their marks), Save and Close at its
    // right, the title between
    float x0 = window->Pos.x, y0 = window->Pos.y, x1 = x0 + window->Size.x, y1 = y0 + window->Size.y;
    float band = std::max(.11f * H, f * 2.9f), side = band * .8f, by = y0 + (band - side) * .5f + line * .5f;
    dl->AddRectFilled(ImVec2(x0, y0), ImVec2(x1, y0 + band), k.band);
    if (look.game) {  // (the game's red and green rules under it)
        dl->AddRectFilled(ImVec2(x0, y0 + band), ImVec2(x1, y0 + band + line), IM_COL32(176, 34, 30, 255));
        dl->AddRectFilled(ImVec2(x0, y0 + band + line), ImVec2(x1, y0 + band + line * 1.7f),
                          IM_COL32(80, 142, 54, 255));
    } else
        dl->AddRectFilled(ImVec2(x0, y0 + band), ImVec2(x1, y0 + band + line * .7f), look.accent);
    float title_x = x0 + pad * 1.5f, right = x1 - pad;
    bool held = false;
    std::function<void()> later;  // (what the header or a tab asked for: once the frame is drawn as it began)
    if (s.view != View::Main) {  // (a submenu or a dialog: a step back)
        ImRect r(x0 + pad, by, x0 + pad + side, by + side);
        if (touch_button("###back", r, true, &held))
            later = [open]() { ask_back(open); };
        plate(dl, r, line, held, true);
        chevron(dl, r.GetCenter(), side * .2f, -1, held ? k.glow : k.ink, std::max(2.f, line * 1.5f));
        title_x = r.Max.x + pad * 1.2f;
    }
    if (!dialog) {  // (a dialog asks for those itself)
        ImRect r(right - side, by, right, by + side);
        if (touch_button("###close", r, true, &held))
            later = [open]() { ask_close(open); };
        plate(dl, r, line, held, true);
        cross(dl, r.GetCenter(), side * .2f, held ? k.glow : k.ink, std::max(2.f, line * 1.5f));
        bool can = dirty() || pending_text();
        const char *label = tr("Save");
        ImVec2 ts = ImGui::CalcTextSize(label);
        float sw = std::max(side * 1.8f, ts.x + f * 1.8f);
        ImRect save_rect(r.Min.x - pad - sw, by, r.Min.x - pad, by + side);
        if (touch_button("###save", save_rect, can, &held))
            s.command = Command::Save;
        plate(dl, save_rect, line, held, can);
        shadow_text(dl, f,
                    ImVec2(save_rect.GetCenter().x - ts.x * .5f, save_rect.GetCenter().y - ts.y * .5f),
                    can ? k.glow : look.text_off, label);
        // (the project's page, a little apart from Save: GitHub's mark, as in the MH4U port)
        ImRect site(save_rect.Min.x - pad * 1.6f - side, by, save_rect.Min.x - pad * 1.6f, by + side);
        if (touch_button("###site", site, true, &held))  // (asks first: the browser can make Android close the game)
            later = []() { push(View::OpenSite, "dialog.cancel"); };
        plate(dl, site, line, held, true);
        github_mark(dl, site.GetCenter(), side * .27f, held ? k.glow : k.ink);
        // (the community's Discord beside it, the same size: the title fits in what is left)
        ImRect chat(site.Min.x - pad - side, by, site.Min.x - pad, by + side);
        if (touch_button("###discord", chat, true, &held))  // (asks first, as the page)
            later = []() { push(View::OpenDiscord, "dialog.cancel"); };
        plate(dl, chat, line, held, true);
        discord_mark(dl, chat.GetCenter(), side * .27f, held ? k.glow : k.ink);
        right = chat.Min.x - pad;
    }
    {  // (the title; the tab's name or the submenu's after it. Where the header's buttons leave less room (a large Menu
       // size on a 4:3 screen), both smaller to fit, down to .6 of their size; narrower still, the name alone, its last
       // words left out if need be: never a word cut in two. The same in the MH4U port)
        const char *title = tr("SETTINGS");
        ImFont *tf = title_font();
        float size = std::floor(f * 1.1f), cy = by + side * .5f, room = right - title_x;
        std::string sub = s.view == View::Main ? tr(page_names[s.page]) : dialog ? "" : view_title();  // (a page: Section › Page)
        auto sized = [](float full, float q) { return q < 1 ? std::floor(full * q) : full; };
        auto name_w = [&](float q) { return font->CalcTextSizeA(sized(f, q), FLT_MAX, 0, sub.c_str()).x; };
        auto both_w = [&](float q) {
            return tf->CalcTextSizeA(sized(size, q), FLT_MAX, 0, title).x + (sub.empty() ? 0 : f * q * 1.4f + name_w(q));
        };
        float q = std::clamp(room / both_w(1), .6f, 1.f);
        while (q > .6f && both_w(q) > room)
            q = std::max(.6f, q - .02f);
        bool alone = !sub.empty() && both_w(q) > room;  // (the name without the title before it)
        if (alone) {
            q = std::clamp(room / name_w(1), .6f, 1.f);
            while (q > .6f && name_w(q) > room)
                q = std::max(.6f, q - .02f);
            std::string cut = whole_words(font, sized(f, q), sub, room);
            if (cut.empty())  // (not even its first word: the title as it was, at its size, clipped at the buttons)
                alone = false, q = 1;
            else
                sub = cut;
        }
        dl->PushClipRect(ImVec2(x0, y0), ImVec2(std::max(title_x, right), y0 + band), true);
        float x = title_x;
        if (!alone) {
            ImVec2 ts = tf->CalcTextSizeA(sized(size, q), FLT_MAX, 0, title);
            shadow_text(dl, tf, sized(size, q), ImVec2(x, cy - ts.y * .5f), k.glow, title);
            x += ts.x + f * q * .7f;
            if (!sub.empty())
                diamond(dl, ImVec2(x, cy), f * q * .18f, k.rule);
            x += f * q * .7f;
        }
        if (!sub.empty()) {
            ImVec2 ss = font->CalcTextSizeA(sized(f, q), FLT_MAX, 0, sub.c_str());
            shadow_text(dl, sized(f, q), ImVec2(x, cy - ss.y * .5f), k.ink, sub.c_str());
        }
        dl->PopClipRect();
    }
    // The body: the sections at the left of a section's pages; a submenu's or a dialog's rows alone; under them, a strip
    // with the last save's outcome, what the restart mark means and, with a controller, its buttons
    float frame = std::max(2.f, f * .14f) * 1.7f;  // (draw_frame's rules at the bottom)
    const bool pad_guides = host_input_real_pad();
    const float guide = std::floor(f * 1.1f), foot = guide + pad * .9f;
    float top = y0 + band + line * 2 + pad, bottom = y1 - frame - pad - foot, left = x0 + pad, end = x1 - pad;
    auto error_text = [&](float y, float x, float w) {  // (s.error, wrapped at w; the height it takes)
        if (s.error.empty())
            return 0.f;
        dl->AddText(font, f, ImVec2(x, y), look.warn, s.error.c_str(), nullptr, w);
        return font->CalcTextSizeA(f, FLT_MAX, w, s.error.c_str()).y + pad * .6f;
    };
    ImRect list_rect;
    if (s.view == View::Main || s.view == View::Page) {
        // The six sections, each a plate with its mark and its name (the one shown lit as the picked row, a notch at
        // its right pointing at the rows), and Credits & Licenses under them, smaller, past a gold diamond between
        // two rules. A section's name too long for the column: smaller, on one line
        float tw = 0;
        for (int i = 0; i < PAGES - 1; i++)
            tw = std::max(tw, ImGui::CalcTextSize(tr(page_names[i])).x);
        tw = std::clamp(tw + f * 3.f, (end - left) * .16f, (end - left) * .3f);  // (a 4:3 screen: up to .3, the names at their size)
        float gap = pad * .5f, credits = std::max(f * 2.f, s.m.row * .62f), ornament = pad * 1.6f;
        float th = std::min((bottom - top - credits - ornament - gap * (PAGES - 2)) / (PAGES - 1), s.m.row * 1.1f);
        ImU32 bright = IM_COL32(255, 248, 232, 255);
        for (int i = 0; i < PAGES; i++) {
            bool small = i == ABOUT_PAGE;
            ImRect r = small ? ImRect(left + tw * .05f, bottom - credits, left + tw * .95f, bottom)
                             : ImRect(left, top + i * (th + gap), left + tw, top + i * (th + gap) + th);
            ImGui::PushID(i);
            if (touch_button("###tab", r, true, &held) && (s.page != i || s.view != View::Main))
                later = [i]() { first_page(i); };
            ImGui::PopID();
            bool active = s.page == i;
            float cy = r.GetCenter().y, h = r.GetHeight();
            if (active) {  // (lit as the picked row, a notch at its right pointing at the rows)
                float n = std::min(h * .18f, pad);
                dl->AddRectFilledMultiColor(r.Min, r.Max, k.bar0, k.bar1, k.bar1, k.bar0);
                dl->AddRect(r.Min, r.Max, fade(k.glow, .9f), 0, 0, line * .7f);
                if (!small)
                    dl->AddTriangleFilled(ImVec2(r.Max.x, cy - n), ImVec2(r.Max.x + pad * .75f, cy), ImVec2(r.Max.x, cy + n), k.glow);
            } else
                plate(dl, r, line * .8f, held, true);
            float mark = small ? f * .95f : f * 1.25f, mx = r.Min.x + mark * .5f + f * .45f;
            section_icon(dl, i, ImVec2(mx, cy), mark, active ? bright : fade(k.rule, .95f));
            const char *name = tr(page_names[i]);
            float tx = mx + mark * .5f + f * .5f, room = r.Max.x - tx - f * .35f, size = small ? std::floor(f * .8f) : f;
            float wide = font->CalcTextSizeA(size, FLT_MAX, 0, name).x;
            float text = wide > room ? std::floor(size * room / wide) : size;  // (a long name: smaller, on one line)
            ImVec2 ts = font->CalcTextSizeA(text, FLT_MAX, 0, name);
            shadow_text(dl, text, ImVec2(tx, cy - ts.y * .5f), active ? bright : k.dim, name);
        }
        {  // (between the sections and Credits & Licenses: a gold diamond between two rules)
            float y = bottom - credits - ornament * .5f, cx = left + tw * .5f;
            dl->AddLine(ImVec2(left + tw * .1f, y), ImVec2(cx - f * .55f, y), fade(k.rule, .5f), std::max(1.f, line * .5f));
            dl->AddLine(ImVec2(cx + f * .55f, y), ImVec2(left + tw * .9f, y), fade(k.rule, .5f), std::max(1.f, line * .5f));
            diamond(dl, ImVec2(cx, y), f * .26f, fade(k.rule, .85f));
            diamond(dl, ImVec2(cx, y), f * .11f, k.band);
        }
        float lx = left + tw + pad * 1.4f;
        float y = top + error_text(top, lx, end - lx);
        list_rect = ImRect(lx, y, end, bottom);
    } else if (s.view == View::TouchButtons || s.view == View::Profiles || s.view == View::ProfileSlot || s.view == View::Chat ||
               s.view == View::Friends) {
        float y = top + error_text(top, left, end - left);
        list_rect = ImRect(left, y, end, bottom);
    } else if (s.view == View::Keyboard) {  // (the text typed so far, the keys under it)
        ImRect field(left, top, end, top + f * 2.3f);
        dl->AddRectFilled(field.Min, field.Max, IM_COL32(14, 10, 8, 235));
        dl->AddRect(field.Min, field.Max, k.rule, 0, 0, line * .7f);
        std::string text = s.keyboard.buffer;
        text.insert(s.keyboard.cursor, "|");
        float room = field.GetWidth() - f * 1.2f;
        float upto = ImGui::CalcTextSize(text.c_str(), text.c_str() + s.keyboard.cursor + 1).x;
        float tx = field.Min.x + f * .6f - std::max(0.f, upto - room);  // (a long text: the part at the cursor shows)
        ImVec2 ts = ImGui::CalcTextSize(text.c_str());
        float ty = field.GetCenter().y - ts.y * .5f;
        dl->PushClipRect(ImVec2(field.Min.x + line, field.Min.y), ImVec2(field.Max.x - line, field.Max.y), true);
        if (s.keyboard.select_all)
            dl->AddRectFilled(ImVec2(tx, ty), ImVec2(tx + ts.x, ty + ts.y), fade(k.glow, .3f));
        dl->AddText(ImVec2(tx, ty), k.ink, text.c_str());
        dl->PopClipRect();
        float y = field.Max.y + pad;
        y += error_text(y, left, end - left);
        list_rect = ImRect(left, y, end, bottom);
    } else if (dialog) {  // (the question, its choices in a column under it)
        float cw = std::min((end - left) * .55f, f * 26), cx = (left + end) * .5f;
        std::string question = view_title();
        float size = std::floor(f * 1.1f), y = top + pad;
        ImVec2 qs = font->CalcTextSizeA(size, FLT_MAX, cw, question.c_str());
        shadow_text(dl, size, ImVec2(cx - qs.x * .5f, y), k.glow, question.c_str(), cw);
        y += qs.y;
        std::string detail = view_detail();
        if (!detail.empty()) {  // (smaller, under the question, as the MH4U port's)
            float ds = std::floor(f * .85f);
            ImVec2 dz = font->CalcTextSizeA(ds, FLT_MAX, cw, detail.c_str());
            y += pad * .6f;
            dl->AddText(font, ds, ImVec2(cx - std::min(cw, dz.x) * .5f, y), k.dim, detail.c_str(), nullptr, cw);
            y += dz.y;
        }
        y += pad * 1.5f;
        y += error_text(y, cx - cw * .5f, cw);
        list_rect = ImRect(cx - cw * .5f, y, cx + cw * .5f, bottom);
    } else {  // (Keybinds, Conflicts: the whole width)
        float y = top + error_text(top, left, end - left);
        list_rect = ImRect(left, y, end, bottom);
    }
    {  // the strip at the foot: the last save's outcome and the restart mark at its left, a controller's buttons at its right
        float fy = y1 - frame - pad * .55f - guide;
        dl->AddLine(ImVec2(left, fy - pad * .4f), ImVec2(end, fy - pad * .4f), fade(k.rule, .25f), std::max(1.f, line * .4f));
        float small = std::floor(f * .8f), x = left + f * .2f, cy = fy + guide * .5f;
        auto say = [&](const char *text, ImU32 ink) {
            ImVec2 ts = font->CalcTextSizeA(small, FLT_MAX, 0, text);
            dl->AddText(font, small, ImVec2(x, cy - ts.y * .5f), ink, text);
            x += ts.x + f;
        };
        if (s.saved_notice && s.error.empty())
            say(saved_text(), k.glow);
        if (std::any_of(rows.begin(), rows.end(), [](const Row &row) { return row.cold; }))  // (only where a row has the *)
            say(tr("* Restart required"), k.dim);
        if (pad_guides && !dialog && s.view != View::Keyboard) {
            struct Item {
                int physical;  // (-1 the d-pad, -2 the shoulders)
                const char *label;
                bool on;
            };
            const bool sections = s.view == View::Main || s.view == View::Page;
            const int confirm = menu_confirm_position(config_live_menu_confirm(), overlay_face_position(0), overlay_face_position(1), 0);
            const int back = menu_confirm_position(config_live_menu_confirm(), overlay_face_position(0), overlay_face_position(1), 1);
            const Item items[] = {{-1, "Move", true},
                                  {confirm, "Confirm", true},
                                  {back, "Back", true},
                                  {overlay_face_position(2), guide_remove() ? "Remove" : "Save", guide_remove() || dirty()},
                                  {overlay_face_position(3), "Help", !s.dropdown.open || !s.dropdown.help.empty()},
                                  {-2, "Sections", sections}};
            float text = std::floor(guide * .78f), gapx = guide * .8f, gx = end;
            for (int i = (int)std::size(items) - 1; i >= 0; i--) {
                const Item &it = items[i];
                if (it.physical == -2 && !sections)
                    continue;
                const char *label = tr(it.label);
                ImVec2 ts = font->CalcTextSizeA(text, FLT_MAX, 0, label);
                gx -= ts.x;
                if (gx < x)
                    break;
                dl->AddText(font, text, ImVec2(gx, cy - ts.y * .5f), it.on ? k.dim : fade(k.dim, .4f), label);
                if (it.physical == -2) {
                    float w1 = guide * 1.5f;
                    gx -= guide * .25f + w1;
                    guide_button(dl, ImVec2(gx, fy), guide, 0, true, true);
                    gx -= guide * .15f + w1;
                    guide_button(dl, ImVec2(gx, fy), guide, 0, true, false);
                } else {
                    gx -= guide * .25f + guide;
                    guide_button(dl, ImVec2(gx, fy), guide, it.physical);
                }
                gx -= gapx;
            }
        }
    }
    // The rows' list
    ImGui::SetCursorScreenPos(list_rect.Min);
    ImGui::BeginChild("##list", ImVec2(list_rect.GetWidth(), std::max(1.f, list_rect.GetHeight())),
                      ImGuiChildFlags_None, ImGuiWindowFlags_NoScrollbar);
    ImGui::SetWindowFontScale(scale);
    auto *list = ImGui::GetCurrentWindow();
    s.list = list->ID;
    if (s.restore_scroll) {
        ImGui::SetScrollY(s.scroll);
        s.restore_scroll = false;
    }
    draw_rows(rows);
    if (s.view == View::Licenses)
        licenses_text(look);
    ImGui::Dummy(ImVec2(1, pad));
    finger_scroll(list);
    scroll_mark(list);
    if (picking)  // (a window of its own, drawn over the menu's: dimmed on its own)
        list->DrawList->AddRectFilled(list->Pos, ImVec2(list->Pos.x + list->Size.x, list->Pos.y + list->Size.y),
                                      IM_COL32(0, 0, 0, 150));
    ImGui::EndChild();
    if (later)
        later();
    commands(before);
    draw_frame(window, look);
    if (picking) {
        dl->PushClipRectFullScreen();
        dl->AddRectFilled(vp->Pos, ImVec2(vp->Pos.x + vp->Size.x, vp->Pos.y + vp->Size.y), IM_COL32(0, 0, 0, 150));
        dl->PopClipRect();
    }
    ImGui::End();
    if (s.dropdown.open && !options.empty())
        touch_picker(options, scale);
    else
        s.dropdown.hovered = false;
    ImGui::PopStyleVar(3);
    ImGui::PopStyleColor(4);
    if (!ImGui::IsMouseDown(ImGuiMouseButton_Left))
        s.swallow = false;  // (the press it was for has let go)
}
// What the other threads read of the menu, as its frame ends
void report(bool *open) {
    is_dirty = *open && (dirty() || pending_text());
    is_confirming = *open && confirmation();
    is_capturing = *open && s.view == View::KeyCapture;
    // (a click on the capture view's buttons is theirs; anywhere else it is the mouse button chosen - a finger's tap
    // is no mouse button)
#ifdef __ANDROID__  // (S14: a phone's mouse, with a keyboard connected: a finger's tap is never a mouse button, overlay.cpp)
    capture_mouse = is_capturing && s.capture_bind >= 0 && !s.pointing && host_input_keyboard_mouse();
#else
    capture_mouse = is_capturing && s.capture_bind >= 0 && !s.pointing && !touch_ui();
#endif
    capture_wheel = is_capturing && s.capture_bind >= 0;  // (the capture view doesn't scroll)
    textinput_menu_keyboard(*open && s.view == View::Keyboard && s.keyboard.phone);  // (its key asked for it: textinput.c)
    if (!*open)
        s.editing = false;
}
// ---------------------------------------------------------------- the credits
// Shown over the game for a few seconds when the app opens (again from Credits & Licenses): who made it and where the
// official one is, so a copy passed around elsewhere still says so
double g_credits_at = -1;
bool g_credits_asked = false;  // (Show the credits: over the menu too)
constexpr double kCreditsShown = 8;
void credits_show() {
    g_credits_at = SDL_GetTicks() / 1000.0;
    g_credits_asked = true;
}
// (only inside the overlay's ImGui frame: before its first one there is no font, and a draw list taken before NewFrame
// is the last frame's, cleared as the frame begins)
void draw_credits() {
    constexpr double kShown = kCreditsShown, kIn = .4, kFade = .9;
    const double now = SDL_GetTicks() / 1000.0;
    if (g_credits_at < 0)
        g_credits_at = now;
    const double t = now - g_credits_at;
    if (t > kShown || thanks_on(now))  // (the thank-you on the screen: never one on the other)
        return;
    const float a = (float)std::clamp(std::min(t / kIn, (kShown - t) / kFade), 0.0, 1.0);
    ImGuiViewport *vp = ImGui::GetMainViewport();
    ImDrawList *dl = ImGui::GetForegroundDrawList();
    const Look k = touch_look();
    const Theme &th = theme();
    ImFont *font = ImGui::GetFont();
    const char *title = app_title();
    std::vector<std::string> lines = {
        std::string(tr("Version")) + " " MHGU_VERSION "  \xC2\xB7  " + tr("by") + " khorne-hub",
        tr("Free, made by fans"),
        std::string(tr("Official download:")) + " github.com/khorne-hub/gu-native",
        tr("Based on MHGURecomp"),
    };
#ifdef MHGU_IOS
    lines.insert(lines.begin() + 1, "iOS fork by Moka Illustra");
#endif
    const char *warns[] = {tr("Only the links khorne-hub gives are official."),
                           tr("Got it elsewhere, paid for it or it has ads? It is not the official one.")};
    // (sized to the screen's height, smaller when it doesn't fit its width)
    float f = std::floor(std::clamp(vp->Size.y * .034f, 12.f, 44.f)), w = 0;
    for (int pass = 0; pass < 2; pass++) {
        w = title_font()->CalcTextSizeA(std::floor(f * 1.5f), FLT_MAX, 0, title).x;
        for (const std::string &l : lines)
            w = std::max(w, font->CalcTextSizeA(f, FLT_MAX, 0, l.c_str()).x);
        for (const char *l : warns)
            w = std::max(w, font->CalcTextSizeA(std::floor(f * .85f), FLT_MAX, 0, l).x);
        const float room = vp->Size.x * .9f - f * 2.6f;
        if (w <= room)
            break;
        f = std::floor(f * room / w);
    }
    const float tsz = std::floor(f * 1.5f), small = std::floor(f * .85f), gap = std::floor(f * .4f), pad = std::floor(f * 1.3f);
    const float line = std::max(1.f, std::floor(f * .09f));
    const float h = tsz + gap * 3 + (float)lines.size() * (f + gap) + gap + small * 2 + gap * .5f;
    const ImVec2 c(vp->Pos.x + vp->Size.x * .5f, vp->Pos.y + vp->Size.y * .5f);
    const ImRect box(ImVec2(std::floor(c.x - w * .5f - pad), std::floor(c.y - h * .5f - pad)),
                     ImVec2(std::floor(c.x + w * .5f + pad), std::floor(c.y + h * .5f + pad)));
    // (the game's window: a wine-dark panel, a bronze edge, a gold rule inside and gold studs on its corners)
    dl->AddRectFilled(ImVec2(box.Min.x + line * 2, box.Min.y + line * 2), ImVec2(box.Max.x + line * 2, box.Max.y + line * 2),
                      fade(IM_COL32(0, 0, 0, 140), a));
    dl->AddRectFilled(box.Min, box.Max, fade(IM_COL32(50, 25, 24, 246), a));
    dl->AddRect(box.Min, box.Max, fade(IM_COL32(112, 76, 34, 255), a), 0, 0, line * 1.6f);
    const float in = line * 3.2f;
    const ImU32 gold = IM_COL32(222, 186, 96, 255);
    dl->AddRect(ImVec2(box.Min.x + in, box.Min.y + in), ImVec2(box.Max.x - in, box.Max.y - in), fade(gold, a * .75f), 0, 0, line * .7f);
    for (ImVec2 p : {box.Min, ImVec2(box.Max.x, box.Min.y), ImVec2(box.Min.x, box.Max.y), box.Max})
        diamond(dl, p, line * 2.6f, fade(gold, a));
    float y = box.Min.y + pad;
    ImVec2 ts = title_font()->CalcTextSizeA(tsz, FLT_MAX, 0, title);
    shadow_text(dl, title_font(), tsz, ImVec2(std::floor(c.x - ts.x * .5f), y), fade(IM_COL32(255, 232, 84, 255), a), title);
    y += tsz + gap * 1.5f;
    { // (a gold rule with a diamond in its middle)
        const float half = std::min(w * .5f, f * 9);
        dl->AddLine(ImVec2(c.x - half, y), ImVec2(c.x - f * .6f, y), fade(gold, a * .6f), line * .7f);
        dl->AddLine(ImVec2(c.x + f * .6f, y), ImVec2(c.x + half, y), fade(gold, a * .6f), line * .7f);
        diamond(dl, ImVec2(c.x, y), f * .3f, fade(gold, a * .9f));
        diamond(dl, ImVec2(c.x, y), f * .13f, fade(k.band, a));
    }
    y += gap * 1.5f;
    for (size_t i = 0; i < lines.size(); i++) {
        ImVec2 ls = font->CalcTextSizeA(f, FLT_MAX, 0, lines[i].c_str());
        shadow_text(dl, f, ImVec2(std::floor(c.x - ls.x * .5f), y),
                    fade(i == lines.size() - 2 ? IM_COL32(236, 212, 44, 255) : IM_COL32(242, 238, 232, 255), a),
                    lines[i].c_str());
        y += f + gap;
    }
    y += gap;
    for (const char *l : warns) {
        ImVec2 ws = font->CalcTextSizeA(small, FLT_MAX, 0, l);
        shadow_text(dl, small, ImVec2(std::floor(c.x - ws.x * .5f), y), fade(IM_COL32(196, 176, 166, 255), a), l);
        y += small + gap * .5f;
    }
    (void)th;
}
// ---------------------------------------------------------------- the thanks
// Once, the first time the game opens ([Application] ThanksShown Off), after the credits: a thank-you to the people who
// made the game and kept it alive, in the credits' look. It stays until the player closes it - Continue, a click (either
// button) or a tap anywhere, A, B, Esc, Back (Android's too), Enter, Space or F (a keyboard's A) - and meanwhile every input
// is its own: overlay.cpp counts it
// as a menu open (settings_panel_modal), so the keyboard, the mouse, the fingers (touch.cpp) and the controller
// (host_input.c) go to the overlay and none to the game, and here (thanks_frame, the first thing settings_panel does) it
// takes the frame's input before the menu or a plugin reads it. The overlay draws frames for it as for the credits
// (settings_panel_credits_up), also with nothing else on the screen. Closed, ThanksShown goes into the file at once.
// Credits & Licenses shows its text and opens it again, over the menu, which it goes back to. MHGU_THANKS=0 keeps it from
// showing by itself (a test run's input would wait for it), =1 shows it at every start; with MHGU_HIDDEN (no window to
// close it in) it doesn't show by itself.
enum class Thanks { Unknown, Wait, Open, Done };
std::atomic<Thanks> g_thanks{Thanks::Unknown};  // (read on the host event thread too: settings_panel_key)
constexpr double THANKS_AFTER_S = .3, THANKS_IN_S = .35, THANKS_OUT_S = .15;
constexpr ImGuiID THANKS_OWNER = 0x7468616e;  // (it holds every key for the rest of its frames: the menu under it gets none)
double g_thanks_at = -1, g_thanks_shut = -1;  // (when it opened, when it closed: its fades)
double g_thanks_arm = 1;  // (for this long after it opens it takes no answer: a press already under way, or buttons mashed
                          // through the logos, is not one)
// What closes it, as it lets go: a press made once it takes answers (so neither half of it reaches anything else). A
// keyboard's A and B too, as a desktop's keybinds have them at first (F, and Space), and the mouse's right button (B)
const ImGuiKey THANKS_KEYS[] = {ImGuiKey_MouseLeft, ImGuiKey_MouseRight, ImGuiKey_GamepadFaceDown, ImGuiKey_GamepadFaceRight,
                                ImGuiKey_Escape,    ImGuiKey_AppBack,    ImGuiKey_Enter,           ImGuiKey_KeypadEnter,
                                ImGuiKey_Space,     ImGuiKey_F};
bool g_thanks_armed[IM_COUNTOF(THANKS_KEYS)];
// The same card tells, once, what playing online means: the hub server the game connects to (the default one, set for
// everyone), and that the server sees the player's IP address (settings_panel_online_ok: runtime/net/ldn.c asks before
// anything reaches a hub server, the menu's Check hub server too). It opens when the credits and the thank-you are gone,
// over the game or the menu, and takes the input the same way. Closed, [Multiplayer] OnlineNoticeShown goes into the file
// and what waited for it goes on (the game's search, which waits under it, finds the internet's hubs; a created hub is
// listed; a check asks). MHGU_ONLINE_NOTICE=0 shows it once more in a test run, =1 never.
enum class Card { Thanks, Online };
std::atomic<Card> g_card{Card::Thanks};  // what the card open (or fading out) is
std::atomic<bool> g_online_asked{false}, g_online_seen{false};
std::mutex g_online_mu;
std::string g_online_server;          // (the server it names: g_online_mu)
std::function<void()> g_online_then;  // (the menu's check, waiting for it: the game's thread)
void thanks_decide() {
    if (g_thanks != Thanks::Unknown)
        return;
    const char *env = getenv("MHGU_THANKS");  // (once: getenv walks the whole environment)
    const bool every = env && *env == '1', never = (env && *env == '0') || getenv("MHGU_HIDDEN");
    g_thanks = every || (!never && !config_editable().thanks_shown) ? Thanks::Wait : Thanks::Done;
    if (g_thanks == Thanks::Wait)
        fprintf(stderr, "[settings] the thank-you shows after the credits (%s)\n", every ? "MHGU_THANKS=1" : "ThanksShown = Off");
}
void thanks_open(double now, bool asked) {
    g_card = Card::Thanks;
    g_thanks = Thanks::Open;
    g_thanks_at = now, g_thanks_shut = -1;
    g_thanks_arm = 1.0;  // (asked for in the menu too: the key that asked for it, held, repeats at about .5 s and would answer)
    memset(g_thanks_armed, 0, sizeof g_thanks_armed);
    g_credits_asked = false;  // (credits asked for a moment before: not under it, nor back over the menu after it)
    fprintf(stderr, "[settings] the thank-you is open%s: every input goes to it until it is closed\n",
            asked ? " (Credits & Licenses)" : "");
}
void thanks_show() { thanks_open(SDL_GetTicks() / 1000.0, true); }
// The online notice closed (or already closed in the file): what waited for it goes on
void online_done() {
    g_online_seen = true;
    g_online_asked = false;
    std::function<void()> then = std::move(g_online_then);
    g_online_then = nullptr;
    if (then)
        then();
}
// [Multiplayer] OnlineNoticeShown into the file as it closes, as ThanksShown (thanks_seen, below)
void online_seen() {
    Config c = config_editable();
    if (!c.online_notice) {
        c.online_notice = 1;
        char error[512];
        if (config_save(&c, error, sizeof error))
            fprintf(stderr, "[settings] OnlineNoticeShown = On: the notice about playing online does not show again\n");
        else
            fprintf(stderr, "[settings] OnlineNoticeShown could not be saved: %s\n", error);
        s.draft.online_notice = s.saved.online_notice = 1;  // (a Save from the menu open under it keeps it)
    }
    online_done();
}
// Asked for: it opens once nothing else is on the screen in its place (the credits, the thank-you)
void online_frame(double now) {
    if (!g_online_asked)
        return;
    if (g_online_seen) {
        online_done();
        return;
    }
    if (g_thanks != Thanks::Done || (g_thanks_shut >= 0 && now - g_thanks_shut < THANKS_OUT_S) || g_credits_at < 0 ||
        now - g_credits_at <= kCreditsShown)
        return;
    g_card = Card::Online;
    g_thanks = Thanks::Open;
    g_thanks_at = now, g_thanks_shut = -1, g_thanks_arm = 1.0;
    memset(g_thanks_armed, 0, sizeof g_thanks_armed);
    std::lock_guard<std::mutex> l(g_online_mu);
    fprintf(stderr, "[settings] the notice about playing online is open (%s): every input goes to it until it is closed\n",
            g_online_server.c_str());
}
// The menu's: fn once the notice was closed (at once if it was), for a server; none (Off): at once
void online_then(const char *server, std::function<void()> fn) {
    if (!*server || settings_panel_online_ok(server)) {
        fn();
        return;
    }
    g_online_then = std::move(fn);
}
bool thanks_fading(double now) { return g_thanks == Thanks::Done && g_thanks_shut >= 0 && now - g_thanks_shut < THANKS_OUT_S; }
// [Application] ThanksShown into the file as it closes, with the settings as saved (those being edited in the menu are
// saved or not later, as the player chooses): no Save needed, the rest of the file as it was
void thanks_seen() {
    Config c = config_editable();
    if (c.thanks_shown)
        return;
    c.thanks_shown = 1;
    char error[512];
    if (!config_save(&c, error, sizeof error)) {
        fprintf(stderr, "[settings] ThanksShown could not be saved: %s\n", error);
        return;
    }
    s.draft.thanks_shown = s.saved.thanks_shown = 1;  // (a Save from the menu open under it keeps it)
    fprintf(stderr, "[settings] ThanksShown = On: the thank-you does not show by itself again\n");
}
// "— khorne-hub". ImGui's own font (a desktop's, without Forge's font) has no em dash and would show '?': there the
// banner draws the dash, and the menu's text has two hyphens
bool has_em_dash() {
    static ImFont *checked;
    static bool has;
    ImFont *font = ImGui::GetFont();
    if (font != checked)
        checked = font, has = font && font->IsGlyphInFont(0x2014);
    return has;
}
const char *thanks_signature() { return has_em_dash() ? "\xE2\x80\x94 khorne-hub" : "-- khorne-hub"; }
// Its answer this frame (t: since it opened); then every input of the frame is its own: each key held for whatever reads it
// after (the menu under it, a plugin's window), nothing under it pointed at
bool thanks_input(double t) {
    // (a click or a tap lets go on the screen: a finger the system took, touch.cpp to_menu, lets go far outside it, and a
    // desktop's mouse can let go outside the window)
    const ImGuiViewport *vp = ImGui::GetMainViewport();
    const bool on_screen = ImRect(vp->Pos, ImVec2(vp->Pos.x + vp->Size.x, vp->Pos.y + vp->Size.y)).Contains(ImGui::GetIO().MousePos);
    bool done = false;
    for (int i = 0; i < IM_COUNTOF(THANKS_KEYS); i++) {
        if (ImGui::IsKeyPressed(THANKS_KEYS[i], false))
            g_thanks_armed[i] = t >= g_thanks_arm;
        const bool mouse = THANKS_KEYS[i] == ImGuiKey_MouseLeft || THANKS_KEYS[i] == ImGuiKey_MouseRight;
        if (ImGui::IsKeyReleased(THANKS_KEYS[i]) && g_thanks_armed[i] && (!mouse || on_screen))
            done = true;
    }
    for (int k = ImGuiKey_NamedKey_BEGIN; k < ImGuiKey_NamedKey_END; k++)
        ImGui::SetKeyOwner((ImGuiKey)k, THANKS_OWNER, ImGuiInputFlags_LockThisFrame);
    ImGuiContext &g = *ImGui::GetCurrentContext();
    g.HoveredWindow = g.HoveredWindowUnderMovingWindow = nullptr;
    g.IO.InputQueueCharacters.resize(0);  // (typed text too: Space would type into the menu's keyboard under it)
    return done;
}
// The thank-you in the credits' look (draw_credits): a wine-dark panel, a bronze edge, a gold rule inside and gold studs
// on its corners, over the screen dimmed; the title, a gold rule, the text centred line by line, the signature at its
// right, Continue under it. Sized to the screen's height as the credits, smaller where it doesn't fit (a 1280x720 window,
// a phone, upright too; a 3440x1440 screen gets the credits' largest text). a: its fade; live: open, not fading out;
// armed: it takes answers (Continue lit, and under the mouse pointer or a finger)
void draw_thanks(float a, bool live, bool armed) {
    ImGuiViewport *vp = ImGui::GetMainViewport();
    ImDrawList *dl = ImGui::GetForegroundDrawList();
    ImFont *font = ImGui::GetFont();
    const ImGuiIO &io = ImGui::GetIO();
    const bool online = g_card == Card::Online;  // (the notice about playing online: no signature)
    std::string said;
    if (online) {
        std::lock_guard<std::mutex> l(g_online_mu);
        said = fmt(ONLINE_TEXT, g_online_server.c_str());
    }
    const char *title = tr(online ? "Playing online" : "Thank you"), *text = online ? said.c_str() : tr(THANKS_TEXT);
    const char *go = tr("Continue"), *name = "khorne-hub";
    const bool glyph = has_em_dash();
    // (the text broken into lines at a width that reads well; all of it smaller where it still doesn't fit)
    float f = std::floor(std::clamp(vp->Size.y * .034f, 12.f, 44.f));
    float tsz = 0, gap = 0, pad = 0, lead = 0, w = 0, h = 0, bw = 0, bh = 0, sw = 0, bar = 0, space = 0;
    std::vector<std::pair<const char *, const char *>> rows;
    auto lines = [&](float wrap, bool keep) {  // (how many lines at that width; keep: into rows)
        int n = 0;
        for (const char *p = text, *end = text + strlen(text); p < end; n++) {
            const char *eol = font->CalcWordWrapPosition(f, p, end, wrap), *e = eol;
            while (e > p && e[-1] == ' ')
                --e;
            if (keep)
                rows.push_back({p, e});
            for (p = eol; p < end && *p == ' ';)
                ++p;
        }
        return n;
    };
    for (int pass = 0; pass < 3; pass++) {
        tsz = std::floor(f * 1.5f), gap = std::floor(f * .4f), pad = std::floor(f * 1.3f), lead = std::floor(f * 1.32f);
        // (balanced: the narrowest width that still takes as many lines, so the last one isn't a word on its own)
        float wrap = std::max(f * 8, std::min(f * 24, vp->Size.x * .9f - pad * 2)), narrow = wrap * .5f;
        const int count = lines(wrap, false);
        for (int i = 0; i < 10; i++) {
            const float mid = (narrow + wrap) * .5f;
            (lines(mid, false) <= count ? wrap : narrow) = mid;
        }
        rows.clear();
        lines(wrap, true);
        w = title_font()->CalcTextSizeA(tsz, FLT_MAX, 0, title).x;
        for (const auto &r : rows)
            w = std::max(w, font->CalcTextSizeA(f, FLT_MAX, 0, r.first, r.second).x);
        bar = std::floor(f * .8f), space = font->CalcTextSizeA(f, FLT_MAX, 0, " ").x;
        sw = online ? 0
             : glyph ? font->CalcTextSizeA(f, FLT_MAX, 0, thanks_signature()).x
                     : bar + space + font->CalcTextSizeA(f, FLT_MAX, 0, name).x;
        bh = std::floor(f * 2.3f);
        bw = std::floor(std::max(f * 8, font->CalcTextSizeA(f, FLT_MAX, 0, go).x + f * 3));
        w = std::max({w, sw, bw});
        h = tsz + gap * 3 + rows.size() * lead + (online ? 0 : gap * .25f + f) + gap * 2.5f + bh;
        const float room_w = vp->Size.x * .96f - pad * 2, room_h = vp->Size.y * .94f - pad * 2;
        if ((w <= room_w && h <= room_h) || f <= 10)
            break;
        f = std::max(10.f, std::floor(f * std::min(room_w / w, room_h / h)));
    }
    const float line = std::max(1.f, std::floor(f * .09f));
    const ImVec2 c(vp->Pos.x + vp->Size.x * .5f, vp->Pos.y + vp->Size.y * .5f);
    const ImRect box(ImVec2(std::floor(c.x - w * .5f - pad), std::floor(c.y - h * .5f - pad)),
                     ImVec2(std::floor(c.x + w * .5f + pad), std::floor(c.y + h * .5f + pad)));
    const ImU32 gold = IM_COL32(222, 186, 96, 255);
    auto text_at = [&](float size, ImVec2 p, ImU32 col, const char *b, const char *e = nullptr) {  // (shadowed, as the credits')
        const float o = std::max(1.f, size * .06f);
        dl->AddText(font, size, ImVec2(p.x + o, p.y + o), fade(IM_COL32(0, 0, 0, 170), ((col >> 24) & 0xff) / 255.f), b, e);
        dl->AddText(font, size, p, col, b, e);
    };
    // (whatever is under it dimmed: the one thing that takes input now)
    dl->AddRectFilled(vp->Pos, ImVec2(vp->Pos.x + vp->Size.x, vp->Pos.y + vp->Size.y), fade(IM_COL32(0, 0, 0, 150), a));
    dl->AddRectFilled(ImVec2(box.Min.x + line * 2, box.Min.y + line * 2), ImVec2(box.Max.x + line * 2, box.Max.y + line * 2),
                      fade(IM_COL32(0, 0, 0, 140), a));
    dl->AddRectFilled(box.Min, box.Max, fade(IM_COL32(50, 25, 24, 246), a));
    dl->AddRect(box.Min, box.Max, fade(IM_COL32(112, 76, 34, 255), a), 0, 0, line * 1.6f);
    const float in = line * 3.2f;
    dl->AddRect(ImVec2(box.Min.x + in, box.Min.y + in), ImVec2(box.Max.x - in, box.Max.y - in), fade(gold, a * .75f), 0, 0,
                line * .7f);
    for (ImVec2 p : {box.Min, ImVec2(box.Max.x, box.Min.y), ImVec2(box.Min.x, box.Max.y), box.Max})
        diamond(dl, p, line * 2.6f, fade(gold, a));
    float y = box.Min.y + pad;
    const ImVec2 ts = title_font()->CalcTextSizeA(tsz, FLT_MAX, 0, title);
    shadow_text(dl, title_font(), tsz, ImVec2(std::floor(c.x - ts.x * .5f), y), fade(IM_COL32(255, 232, 84, 255), a), title);
    y += tsz + gap * 1.5f;
    {  // (the credits' gold rule, a diamond in its middle)
        const float half = std::min(w * .5f, f * 9);
        dl->AddLine(ImVec2(c.x - half, y), ImVec2(c.x - f * .6f, y), fade(gold, a * .6f), line * .7f);
        dl->AddLine(ImVec2(c.x + f * .6f, y), ImVec2(c.x + half, y), fade(gold, a * .6f), line * .7f);
        diamond(dl, ImVec2(c.x, y), f * .3f, fade(gold, a * .9f));
        diamond(dl, ImVec2(c.x, y), f * .13f, fade(IM_COL32(74, 34, 31, 255), a));
    }
    y += gap * 1.5f;
    for (const auto &r : rows) {
        const float lw = font->CalcTextSizeA(f, FLT_MAX, 0, r.first, r.second).x;
        text_at(f, ImVec2(std::floor(c.x - lw * .5f), y), fade(IM_COL32(242, 238, 232, 255), a), r.first, r.second);
        y += lead;
    }
    if (!online) {  // (the signature at the text's right)
        y += gap * .25f;
        const float x = std::floor(c.x + w * .5f - sw);
        if (glyph) {
            text_at(f, ImVec2(x, y), fade(gold, a), thanks_signature());
        } else {  // (the dash drawn at the height of the font's hyphen, as long as an em dash, a stroke thick)
            ImFontBaked *baked = font->GetFontBaked(f);
            const ImFontGlyph *hyphen = baked ? baked->FindGlyphNoFallback('-') : nullptr;
            const float k = baked && baked->Size > 0 ? f / baked->Size : 1, o = std::max(1.f, f * .06f);
            const float mid = hyphen ? y + (hyphen->Y0 + hyphen->Y1) * .5f * k : y + f * .55f;
            const float stroke = std::max(1.f, std::floor(f * .08f + .5f));
            const float y0 = std::floor(mid - stroke * .5f), y1 = y0 + stroke;
            dl->AddRectFilled(ImVec2(x + o, y0 + o), ImVec2(x + bar + o, y1 + o), fade(IM_COL32(0, 0, 0, 170), a));
            dl->AddRectFilled(ImVec2(x, y0), ImVec2(x + bar, y1), fade(gold, a));
            text_at(f, ImVec2(x + bar + space, y), fade(gold, a), name);
        }
        y += f;
    }
    y += gap * 2.5f;
    // Continue: a plate as the menu's and the touch controls' buttons (dark, a bronze edge, a gold rule inside, gold
    // studs), dim until it takes answers, lit under the mouse pointer or a finger
    const ImRect btn(ImVec2(std::floor(c.x - bw * .5f), std::floor(y)), ImVec2(std::floor(c.x + bw * .5f), std::floor(y + bh)));
    const bool over = live && armed && ImGui::IsMousePosValid(&io.MousePos) && btn.Contains(io.MousePos);
    const bool lit = over && (io.MouseSource == ImGuiMouseSource_Mouse || io.MouseDown[0]);
    const float on = armed ? a : a * .45f;
    dl->AddRectFilled(ImVec2(btn.Min.x, btn.Min.y + line), ImVec2(btn.Max.x, btn.Max.y + line), fade(IM_COL32(0, 0, 0, 110), a));
    dl->AddRectFilled(btn.Min, btn.Max, fade(lit ? IM_COL32(92, 62, 22, 255) : IM_COL32(28, 20, 15, 235), a));
    dl->AddRect(btn.Min, btn.Max, fade(IM_COL32(112, 76, 34, 255), on), 0, 0, line);
    const float bi = line * 1.8f;
    dl->AddRect(ImVec2(btn.Min.x + bi, btn.Min.y + bi), ImVec2(btn.Max.x - bi, btn.Max.y - bi), fade(gold, on * .7f), 0, 0,
                std::max(1.f, line * .45f));
    for (ImVec2 p : {btn.Min, ImVec2(btn.Max.x, btn.Min.y), ImVec2(btn.Min.x, btn.Max.y), btn.Max})
        diamond(dl, p, line * 1.5f, fade(gold, on));
    if (lit)
        dl->AddRect(ImVec2(btn.Min.x - line, btn.Min.y - line), ImVec2(btn.Max.x + line, btn.Max.y + line),
                    fade(IM_COL32(255, 214, 92, 255), a * .7f), 0, 0, line);
    const ImVec2 gs = font->CalcTextSizeA(f, FLT_MAX, 0, go);
    text_at(f, ImVec2(std::floor(c.x - gs.x * .5f), std::floor(btn.GetCenter().y - gs.y * .5f)),
            fade(lit ? IM_COL32(255, 214, 92, 255) : IM_COL32(244, 232, 200, 255), on), go);
}
// On the screen: open, or fading out (draw_credits waits for it: never one on the other)
bool thanks_on(double now) { return g_thanks == Thanks::Open || thanks_fading(now); }
// Waiting for the credits too: the overlay draws frames for it (settings_panel_credits_up), also with nothing else on the
// screen
bool thanks_up(double now) {
    thanks_decide();
    return g_thanks == Thanks::Wait || thanks_on(now);
}
// A frame of it, the first thing settings_panel does (only inside the overlay's frame): it opens once the credits of the
// first start are done; while it is open, its answer and the frame's input before anything else reads them; then its
// drawing, also as it fades out
void thanks_frame() {
    const double now = SDL_GetTicks() / 1000.0;
    thanks_decide();
    if (g_thanks == Thanks::Wait && g_credits_at >= 0 && now - g_credits_at > kCreditsShown + THANKS_AFTER_S)
        thanks_open(now, false);
    online_frame(now);
    if (!thanks_on(now))
        return;
    bool live = g_thanks == Thanks::Open;
    const double t = now - g_thanks_at;
    if (live && thanks_input(t)) {  // (closed: input is the game's, or the menu's, from the next frame on)
        g_thanks = Thanks::Done, g_thanks_shut = now, live = false;
        const bool online = g_card == Card::Online;
        fprintf(stderr, "[settings] the %s was closed after %.1f s\n", online ? "notice about playing online" : "thank-you", t);
        if (online)
            online_seen();
        else
            thanks_seen();
    }
    const float a = live ? (float)std::clamp(t / THANKS_IN_S, 0.0, 1.0)
                         : (float)std::clamp(1 - (now - g_thanks_shut) / THANKS_OUT_S, 0.0, 1.0);
    if (a > 0)
        draw_thanks(a, live, live && t >= g_thanks_arm);
}
} // namespace
// The game's thread, after ImGui::Render: the menu's and the dropdown's fading copies (ghost_take) into this frame's
// draw data, faded a little more each frame, under the foreground's notices and credits; dropped once faded out, or if
// the font atlas they were drawn with has since been replaced
void settings_panel_after_render(ImDrawData *dd) {
#ifndef __ANDROID__
    for (ImDrawList *l : ghost_shown)  // (last frame's: the overlay copied them for the render thread already)
        IM_DELETE(l);
    ghost_shown.clear();
    double now = anim_now();
    const ImTextureData *atlas = ImGui::GetIO().Fonts->TexRef._TexData;
    for (size_t i = 0; i < ghosts.size();) {
        Ghost &g = ghosts[i];
        float t = (float)((now - g.at) / ANIM_OUT);
        bool over = t >= 1;
        for (ImDrawList *l : g.lists)
            for (const ImDrawCmd &c : l->CmdBuffer)
                over |= c.ElemCount && c.TexRef._TexData != atlas;  // (compared, never read: it may be gone)
        if (over) {
            for (ImDrawList *l : g.lists)
                IM_DELETE(l);
            ghosts.erase(ghosts.begin() + i);
            continue;
        }
        float a = (1 - t) * (1 - t);
        ImVec2 off(g.slide.x * t, g.slide.y * t);
        for (ImDrawList *l : g.lists) {
            ImDrawList *copy = l->CloneOutput();
            copy->_PopUnusedDrawCmd();
            tween_list(copy, 0, copy->VtxBuffer.Size, a, off, true);
            ghost_shown.push_back(copy);
            // (added as ImDrawData::AddDrawList does, without its checks of a list being written: a copy has no writer)
            dd->CmdLists.push_back(copy);
            dd->CmdListsCount++;
            dd->TotalVtxCount += copy->VtxBuffer.Size;
            dd->TotalIdxCount += copy->IdxBuffer.Size;
        }
        i++;
    }
    if (ghost_shown.empty())
        return;
    for (int i = 0; i + 1 < dd->CmdLists.Size; i++)  // (the foreground's list back to the end)
        if (dd->CmdLists[i]->_OwnerName && !strcmp(dd->CmdLists[i]->_OwnerName, "##Foreground")) {
            ImDrawList *fg = dd->CmdLists[i];
            dd->CmdLists.erase(dd->CmdLists.Data + i);
            dd->CmdLists.push_back(fg);
            break;
        }
#else
    (void)dd;
#endif
}
// Something of the menu is still fading out: the overlay draws its frames until it is gone
bool settings_panel_fading() {
#ifndef __ANDROID__
    return !ghosts.empty() || !ghost_shown.empty();
#else
    return false;
#endif
}
void settings_panel_request_close() { request_exit.store(true); }
extern "C" void settings_panel_request_view(int view) { request_view.store(view); }
void settings_panel_request_back() { request_back.store(true); }
bool settings_panel_dirty() { return is_dirty.load(); }
int settings_panel_theme() { return s.editing ? s.draft.menu_theme : config_editable().menu_theme; }
bool settings_panel_confirming() { return is_confirming.load() || request_exit.load(); }
// (the thank-you over the menu choosing a key: the press is the thank-you's, not a key chosen)
bool settings_panel_key(int scancode) {
    if (!is_capturing.load() || g_thanks == Thanks::Open)
        return false;
    captured_key = scancode;
    return true;
}
bool settings_panel_mouse(int button) {
    if (!capture_mouse.load() || button < 1 || button > SDL_BUTTON_X2 || g_thanks == Thanks::Open)
        return false;
    captured_key = KEY_MOUSE + button;
    return true;
}
bool settings_panel_wheel(int notches) {
    if (!capture_wheel.load() || !notches || g_thanks == Thanks::Open)
        return false;
    captured_key = notches > 0 ? KEY_WHEEL_UP : KEY_WHEEL_DOWN;
    return true;
}
bool settings_panel_modal() { return g_thanks == Thanks::Open; }
// Ownership has to precede NewFrame: native cancel/windowing runs there.
void settings_panel_before_frame(bool open) {
    // (the thank-you, the menu open under it or not: every key, so ImGui's own navigation neither moves nor activates the
    // menu's row under it - that is decided in NewFrame - and the wheel scrolls nothing; thanks_input still reads them, and
    // holds them for the rest of the frame)
    if (g_thanks == Thanks::Open) {
        for (int k = ImGuiKey_NamedKey_BEGIN; k < ImGuiKey_NamedKey_END; k++)
            ImGui::SetKeyOwner((ImGuiKey)k, THANKS_OWNER);
        return;
    }
    if (!open && !request_exit.load())
        return;
    const ImGuiKey keys[] = {ImGuiKey_GamepadFaceRight,
                             ImGuiKey_GamepadFaceLeft,
                             ImGuiKey_GamepadFaceUp,
                             ImGuiKey_GamepadL1,
                             ImGuiKey_GamepadR1,
                             ImGuiKey_GamepadDpadUp,
                             ImGuiKey_GamepadDpadDown,
                             ImGuiKey_GamepadDpadLeft,
                             ImGuiKey_GamepadDpadRight,
                             ImGuiKey_GamepadLStickUp,
                             ImGuiKey_GamepadLStickDown,
                             ImGuiKey_GamepadLStickLeft,
                             ImGuiKey_GamepadLStickRight,
                             ImGuiKey_Escape,
                             ImGuiKey_AppBack,
                             ImGuiKey_UpArrow,
                             ImGuiKey_DownArrow,
                             ImGuiKey_LeftArrow,
                             ImGuiKey_RightArrow,
                             ImGuiKey_Tab,
                             ImGuiKey_Home,
                             ImGuiKey_End};
    for (ImGuiKey key : keys)
        ImGui::SetKeyOwner(key, 0x6d686775, ImGuiInputFlags_LockThisFrame);
    if (s.view == View::Keyboard) {
        ImGui::SetKeyOwner(ImGuiKey_Enter, 0x6d686775, ImGuiInputFlags_LockThisFrame);
        ImGui::SetKeyOwner(ImGuiKey_Space, 0x6d686775, ImGuiInputFlags_LockThisFrame);
    }
}
void settings_panel_idle(void) {
    s.editing = false;
    textinput_menu_keyboard(false);
    is_dirty = false;
    is_confirming = false;
    is_capturing = false;
    capture_mouse = false;
}
bool settings_panel_credits_up(void) {
    // (and the thank-you after them: it waits for them, shows and fades out over frames of its own. Asked for on Credits &
    // Licenses they need no more than their time: g_credits_asked stays set once asked, and kept frames coming for good)
    const double now = SDL_GetTicks() / 1000.0;
    return g_credits_at < 0 || now - g_credits_at <= kCreditsShown || thanks_up(now) || g_online_asked;
}
bool settings_panel_online_ok(const char *server) {
    if (g_online_seen || config_live_online_notice() || !overlay_enabled())
        return true;
    if (server && !g_online_asked) {  // (nullptr: only whether it was closed)
        {
            std::lock_guard<std::mutex> l(g_online_mu);
            g_online_server = server;
        }
        g_online_asked = true;
    }
    return false;
}
void settings_panel(bool *open) {
    thanks_frame();  // (first: while the thank-you is open, nothing after it gets the frame's input)
    if (!*open) {
        settings_panel_idle();
        draw_credits();
        return;
    }
    if (g_credits_asked)
        draw_credits();
    bool opening = !s.editing;
    if (opening) {
        s.draft = s.saved = config_editable();
        s.chat_panel_size_draft = s.chat_panel_size_saved = chat_panel_scale();
#ifndef __ANDROID__  // (not when closing the window opened it on Exit game: the player didn't open it)
        if (!s.saved.menu_hint_seen && !request_exit.load())
            menu_hint_seen();
#endif
        s.editing = true;
        s.view = View::Main;
        s.at.clear();
        s.help_open.clear();
        s.origins.clear();
        s.focus.clear();
        s.focus_request = true;
        s.error.clear();
        s.saved_notice = false;
        s.floating = false;
        s.advanced = false;
        s.dropdown.open = false;
        s.help_row.clear();
        s.drag = {};
        s.swallow = false;
        s.exit_only = false;
        s.opened_at = anim_now(), s.view_at = -1;
#ifndef __ANDROID__
        ghosts_clear();  // (closed and opened again at once: no fading copy over it)
        s.dropdown_drawn = false;
#endif
        quest_keys();
        g_hub_checked.clear();  // (the Multiplayer page checks its server again as it shows)
        s.reopen.clear();
        load_mods();
        load_cheats();
#ifndef __ANDROID__
        load_cheat_files();
#endif
    }
    if (request_exit.exchange(false) && s.view != View::Exit) {
        push(View::Exit, "dialog.cancel");
        s.exit_only = opening;  // (the menu was closed: the window's close button alone opened it)
        if (opening)
            s.view_at = -1;  // (it comes in with the menu)
    }
    // (the phone's keyboard put away with Back: only the keyboard goes, the view and its text stay - its key brings the
    // keyboard back, and another Back leaves the view, as in the MH4U port)
    if (textinput_menu_keyboard_closed() && s.view == View::Keyboard)
        s.keyboard.phone = false;
    switch (request_view.exchange(0)) {  // (a desktop's file dialog answered: runtime/pc_actions.c)
    case SETTINGS_VIEW_IMPORT_SAVE: if (s.view != View::ImportSave) push(View::ImportSave, "dialog.cancel"); break;
    case SETTINGS_VIEW_RESTART:  // (cheats or a mod added: the tabs list them now)
#ifndef __ANDROID__
        refresh_mods();
        load_cheat_files();
#endif
        if (s.view != View::Restart) push(View::Restart, "dialog.cancel");
        break;
    case SETTINGS_VIEW_CHAT:  // (the chat button over the game: runtime/chat_port.cpp)
        if (s.view != View::Chat) {
            first_page(3);  // (Multiplayer: page_ids)
            push(View::Chat, "chat.say");
        }
        break;
    case SETTINGS_VIEW_GAME_TEXT:  // (the touch controls' Keyboard plate, a game's text entry open)
        if (textinput_active() && s.view != View::Keyboard) game_text_keyboard();
        break;
    default: break;
    }
    if (g_close_now) {  // (the game's text entry's view left)
        g_close_now = false;
        if (s.view == View::Main && !dirty()) {
            *open = false;
            return;
        }
    }
    Config before = s.draft;
#ifndef __ANDROID__
    s.touch = s.touch_next;  // (the layout follows what the last press came from, a frame later: the release that
    if (ImGui::IsMouseReleased(ImGuiMouseButton_Left))  // tells went to what it pressed, in the layout it was made on)
        s.touch_next = ImGui::GetIO().MouseSource == ImGuiMouseSource_TouchScreen;
#endif
    if (touch_ui()) {
        touch_panel(open, before);
        report(open);
        return;
    }
    s.list = 0;
    s.input = overlay_last_input();  // (the same for the whole frame: the guides are measured, then drawn)
    ImGuiViewport *vp = ImGui::GetMainViewport();
    float scale = s.draft.menu_scale / 100.f;
    float base = ImGui::GetFontSize();
    float margin = std::min(16.f, vp->WorkSize.x * .025f);
    float width = std::min(vp->WorkSize.x - 2 * margin, base * scale * 56);
    bool sized = s.custom_size.x > 0;
    if (sized) {
        ImVec2 least(std::min(base * scale * 26, vp->WorkSize.x), std::min(base * scale * 14, vp->WorkSize.y));
        s.custom_size.x = std::clamp(s.custom_size.x, least.x, vp->WorkSize.x);
        s.custom_size.y = std::clamp(s.custom_size.y, least.y, vp->WorkSize.y);
        width = s.custom_size.x;
        ImGui::SetNextWindowSize(s.custom_size, ImGuiCond_Always);
    } else {
        ImGui::SetNextWindowSizeConstraints(ImVec2(width, 0), ImVec2(width, vp->WorkSize.y - 2 * margin));
    }
    mouse_drag(vp, width);
    if (s.view == View::Move) {
        float x =
            (direction(ImGuiKey_RightArrow, ImGuiKey_GamepadDpadRight, ImGuiKey_GamepadLStickRight) ? 1 : 0) -
            (direction(ImGuiKey_LeftArrow, ImGuiKey_GamepadDpadLeft, ImGuiKey_GamepadLStickLeft) ? 1 : 0);
        float y =
            (direction(ImGuiKey_DownArrow, ImGuiKey_GamepadDpadDown, ImGuiKey_GamepadLStickDown) ? 1 : 0) -
            (direction(ImGuiKey_UpArrow, ImGuiKey_GamepadDpadUp, ImGuiKey_GamepadLStickUp) ? 1 : 0);
        auto *w = ImGui::FindWindowByName("Settings##main");
        float h = w ? w->Size.y : 200;
        s.move_position.x = std::clamp(s.move_position.x + x * 16, vp->WorkPos.x,
                                       vp->WorkPos.x + std::max(0.f, vp->WorkSize.x - width));
        s.move_position.y = std::clamp(s.move_position.y + y * 16, vp->WorkPos.y,
                                       vp->WorkPos.y + std::max(0.f, vp->WorkSize.y - h));
        s.position_override = true;
    }
    if (s.position_override && s.floating) {
        ImGui::SetNextWindowPos(s.move_position, ImGuiCond_Always);
        s.position_override = false;
    }
    if (!s.floating)
        ImGui::SetNextWindowPos(
            ImVec2(vp->WorkPos.x + (vp->WorkSize.x - width) * .5f, vp->WorkPos.y + margin), ImGuiCond_Always);
    const Theme &look = theme();
    ImGui::PushStyleColor(ImGuiCol_WindowBg, vec(look.panel));
    ImGui::PushStyleColor(ImGuiCol_Text, vec(look.text));
    ImGui::PushStyleColor(ImGuiCol_Border, vec(look.edge));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding,
                        look.bar ? 12.f : look.game ? 0.f : ImGui::GetStyle().WindowRounding);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize,
                        look.bar ? 1.5f : look.game ? 2.f : ImGui::GetStyle().WindowBorderSize);
    ImGui::Begin("Settings##main", nullptr,
                 (sized ? 0 : ImGuiWindowFlags_AlwaysAutoResize) | ImGuiWindowFlags_NoCollapse |
                     ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoMove |
                     ImGuiWindowFlags_NoResize);
    ImGui::SetWindowFontScale(scale);
    auto *window = ImGui::GetCurrentWindow();
    int content_from = window->DrawList->VtxBuffer.Size;  // (after the panel: a view's contents, which come in)
    if (s.restore_scroll) {
        ImGui::SetScrollY(s.scroll);
        s.restore_scroll = false;
    }
    back_keys(open);
    View frame_view = s.view;  // (a view changed after this, by a row, shows from the next frame)
    int guide_items = view_guides();
    bool pinned_guides = guide_items != 0;
    bool clipped_body = false;
    float spacing = ImGui::GetStyle().ItemSpacing.y;
    GuideLayout guides = guide_layout(ImGui::GetContentRegionAvail().x, pinned_guides ? guide_items : GUIDE_ALL);
    // pinned above the guides: the help of the row focused or pointed at, with room for the longest of the tab
    const bool tabs = s.view == View::Main || s.view == View::Page;  // (a section's pages: the tabs over them)
    float help_area = pinned_guides && tabs && s.help_height > 0 ? s.help_height + spacing * 2 : 0;
    s.guide_height = pinned_guides ? guides.height + help_area : 0;
    float guide_top =
        std::max(window->Pos.y + window->Size.y - ImGui::GetStyle().WindowPadding.y - guides.height,
                 window->InnerClipRect.Min.y);
    float help_top = std::max(guide_top - help_area, window->InnerClipRect.Min.y);
    if (pinned_guides)
        ImGui::PushClipRect(
            window->InnerClipRect.Min,
            ImVec2(window->InnerClipRect.Max.x, std::max(window->InnerClipRect.Min.y, help_top - spacing)), true);
    if (tabs) {
        page_keys();
        float avail = ImGui::GetContentRegionAvail().x;
        float fw = ImGui::GetFontSize();
        ImVec2 scrolling_start = ImGui::GetCursorScreenPos();
        ImVec2 tabs_start(scrolling_start.x, window->Pos.y + ImGui::GetStyle().WindowPadding.y);
        ImGui::SetCursorScreenPos(tabs_start);
        float gutter = fw * 2.1f;
        float tabs_width = avail - gutter * 2;
        int columns = tabs_width / fw < 50 ? 4 : PAGES;
        float tabw = (tabs_width - ImGui::GetStyle().ItemSpacing.x * (columns - 1)) / columns;
        float tabh = fw * (columns == PAGES ? 2.7f : 2.1f);
        int lines = (PAGES + columns - 1) / columns;
        float header_height = tabh * lines + ImGui::GetStyle().ItemSpacing.y * (lines - 1);
        auto *header = ImGui::GetWindowDrawList();
        {  // (over the rows scrolled under the tabs; inside the border, with the window's rounded top corners - the
           // right one left to the window where the scrollbar is)
            float border = window->WindowBorderSize;
            bool scrollbar = window->ScrollbarY;
            header->AddRectFilled(
                ImVec2(window->Pos.x + border, window->Pos.y + border),
                ImVec2(scrollbar ? window->InnerRect.Max.x : window->Pos.x + window->Size.x - border,
                       tabs_start.y + header_height + ImGui::GetStyle().ItemSpacing.y),
                look.game ? look.header : ImGui::GetColorU32(ImGuiCol_WindowBg) | IM_COL32_A_MASK, std::max(0.f, window->WindowRounding - border),
                scrollbar ? ImDrawFlags_RoundCornersTopLeft : ImDrawFlags_RoundCornersTop);
        }
        for (int i = 0; i < PAGES; i++) {
            if (i % columns)
                ImGui::SameLine();
            else
                ImGui::SetCursorPosX(tabs_start.x - ImGui::GetWindowPos().x + gutter);
            ImGui::PushID(i);
            ImVec2 p = ImGui::GetCursorScreenPos();
            bool active = s.page == i;
            // (lit lighter under the mouse while the mouse is what moves, as the selected one while pressed)
            ImU32 tab = active ? look.tab_active : look.tab;
            ImGui::PushStyleColor(ImGuiCol_Button, vec(tab));
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered, vec(s.input == USED_MOUSE ? look.row_hover : tab));
            ImGui::PushStyleColor(ImGuiCol_ButtonActive, vec(look.row_focus));
            ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, look.rounding);
            ImGui::PushItemFlag(ImGuiItemFlags_NoNav, true);
            if (ImGui::Button("###tab", ImVec2(tabw, tabh)) && !s.dragged && !s.swallow)
                first_page(i);
            ImGui::PopItemFlag();
            ImGui::PopStyleVar();
            // A label wraps at its spaces; one word wider than the tab is drawn smaller instead of
            // being cut in two
            const char *name = tr(page_names[i]);
            float room = tabw - fw * .5f, size = fw;
            float word = ImGui::CalcTextSize(name).x;
            if (!strchr(name, ' ') && word > room) size = fw * room / word;
            auto label = ImGui::GetFont()->CalcTextSizeA(size, FLT_MAX, room, name);
            // (Gold: the names centred, the other tabs dimmed, the active one underlined in its middle)
            bool named = look.bar || look.game;
            float indent = named ? (tabw - label.x) * .5f : fw * .25f;
            ImGui::GetWindowDrawList()->AddText(ImGui::GetFont(), size,
                                                ImVec2(p.x + indent, p.y + (tabh - label.y) * .5f),
                                                named ? (active ? look.accent_bright : look.text_dim) : look.text,
                                                name, nullptr, room);
            float inset = named ? tabw * .18f : 0;
            if (active)
                ImGui::GetWindowDrawList()->AddRectFilled(ImVec2(p.x + inset, p.y + tabh - 3),
                                                          ImVec2(p.x + tabw - inset, p.y + tabh), look.accent,
                                                          named && !look.game ? 2.f : 0.f);
            ImGui::PopStyleColor(3);
            ImGui::PopID();
        }
        // At the tabs' sides, what changes the tab: the controller's L / R after a controller's press, else the keys Q /
        // E; a click on one changes it too
        for (int side = 0; side < 2; side++) {
            const char *key = side ? "E" : "Q";
            bool pad = s.input == USED_PAD;
            float gw = pad ? fw * 1.5f : SettingsIcons::key_width(fw, key);
            ImVec2 gp(side ? tabs_start.x + avail - gw : tabs_start.x, tabs_start.y + (header_height - fw) * .5f);
            ImGui::SetCursorScreenPos(gp);
            ImGui::PushItemFlag(ImGuiItemFlags_NoNav, true);
            if (ImGui::InvisibleButton(side ? "###next_tab" : "###tab_before", ImVec2(gw, fw)) && !s.dragged && !s.swallow)
                first_page((s.page + (side ? 1 : PAGES - 1)) % PAGES);
            bool lit = ImGui::IsItemActive() || (ImGui::IsItemHovered() && s.input == USED_MOUSE);
            ImGui::PopItemFlag();
            if (pad)
                SettingsIcons::draw(header, gp, fw, s.draft.button_icons, side ? SettingsIcons::Right : SettingsIcons::Left, 0);
            else
                SettingsIcons::key(header, gp, fw, key);
            if (lit)
                header->AddRect(ImVec2(gp.x - 2, gp.y - 2), ImVec2(gp.x + gw + 2, gp.y + fw + 2), look.accent_bright,
                                fw * .25f, 0, 1.5f);
        }
        if (look.bar) {  // (Gold: a rule under the tabs, gold at the sides and fading out in the middle)
            float y = tabs_start.y + header_height + ImGui::GetStyle().ItemSpacing.y * .5f;
            float mid = (window->InnerRect.Min.x + window->InnerRect.Max.x) * .5f;
            ImU32 clear = look.accent & ~IM_COL32_A_MASK;
            header->AddRectFilledMultiColor(ImVec2(tabs_start.x, y), ImVec2(mid, y + 2), look.accent, clear, clear,
                                            look.accent);
            header->AddRectFilledMultiColor(ImVec2(mid, y), ImVec2(tabs_start.x + avail, y + 2), clear, look.accent,
                                            look.accent, clear);
        }
        ImGui::SetCursorScreenPos(
            ImVec2(scrolling_start.x, scrolling_start.y + header_height + ImGui::GetStyle().ItemSpacing.y));
        float body_top = tabs_start.y + header_height + ImGui::GetStyle().ItemSpacing.y;
        s.header_bottom = body_top - window->Pos.y;
        ImGui::PushClipRect(ImVec2(window->ClipRect.Min.x, std::min(body_top, window->ClipRect.Max.y)),
                            window->ClipRect.Max, true);
        clipped_body = true;
        if (s.view == View::Page) {  // (a page one level down: Section › Page over its rows)
            ImGui::PushStyleColor(ImGuiCol_Text, vec(look.accent));
            ImGui::TextUnformatted(page_path(s.at).c_str());
            ImGui::PopStyleColor();
        }
    } else {
        ImGui::TextWrapped("%s", view_title().c_str());
        std::string detail = view_detail();
        if (!detail.empty())
            ImGui::TextWrapped("%s", detail.c_str());
    }
    if (s.view == View::Keyboard) {
        keyboard_keys();
        if (s.view == View::Keyboard) {
            auto text = s.keyboard.buffer;
            text.insert(s.keyboard.cursor, "|");
            ImGui::TextWrapped("%s", text.c_str());
        }
    }
    auto rows = rows_for_view(open);
    reopen_picker(rows);
    picker_help(rows);
    std::vector<Row> options;  // (a dropdown open: the controller moves in it)
    if (s.dropdown.open)
        options = dropdown_rows();
    if (s.view == View::Move)
        focus("move.accept");
    else
        navigate(s.dropdown.open ? options : rows, s.dropdown.open);
    picker_keys(options);
    draw_rows(rows);
    if (s.view == View::Licenses)
        licenses_text(look, pinned_guides ? guides.height + spacing * 2 : 0);
    float help_wrap = window->InnerRect.GetWidth() - 2 * ImGui::GetStyle().WindowPadding.x;
    std::string help;
    if (tabs) {  // (the row moved to, or the one the mouse moved onto)
        static std::string last_focus, last_hovered;
        if (s.focus != last_focus)
            last_focus = s.help_row = s.focus;
        // (or that the mouse, while it is what moves, has just come onto: its first move after the menu opens has no
        // delta, ImGui gets the mouse's events only while the menu is open)
        ImVec2 moved = ImGui::GetIO().MouseDelta;
        if ((moved.x || moved.y || (s.input == USED_MOUSE && s.hovered != last_hovered)) && !s.hovered.empty())
            s.help_row = s.hovered;
        last_hovered = s.hovered;
        const std::string &id = s.dropdown.open ? s.dropdown.row : s.help_row;
        float tallest = 0;
        for (const auto &r : rows) {
            std::string text = help_text(r);
            if (!text.empty())
                tallest = std::max(tallest, ImGui::CalcTextSize(text.c_str(), nullptr, false, help_wrap).y);
            if (r.id == id)
                help = text;
        }
        s.help_height = tallest;
    } else
        s.help_height = 0;
    commands(before);
    if (!s.error.empty()) {
        ImGui::PushStyleColor(ImGuiCol_Text, vec(look.warn));
        ImGui::TextWrapped("%s", s.error.c_str());
        ImGui::PopStyleColor();
    } else if (s.saved_notice)
        ImGui::TextUnformatted(saved_text());
    if (tabs) {
        if (std::any_of(rows.begin(), rows.end(), [](const Row &row) { return row.cold; }))  // (only where a row has the *)
            ImGui::TextUnformatted(tr("* Restart required"));
        // Keep scroll space for the pinned hints so the last action can scroll fully above them.
        ImGui::Dummy(ImVec2(1, guides.height + help_area + ImGui::GetStyle().ItemSpacing.y));
    } else if (pinned_guides)  // (a dialog's or a page's guides: the same room under its rows)
        ImGui::Dummy(ImVec2(1, guides.height + spacing));
    if (clipped_body)
        ImGui::PopClipRect();
    if (pinned_guides)
        ImGui::PopClipRect();
    if (pinned_guides && help_area > 0) {
        auto *draw = window->DrawList;
        float x0 = window->InnerRect.Min.x, x1 = window->InnerRect.Max.x, pad = ImGui::GetStyle().WindowPadding.x;
        draw->AddRectFilled(ImVec2(x0, help_top - spacing), ImVec2(x1, guide_top),
                            ImGui::GetColorU32(ImGuiCol_WindowBg) | IM_COL32_A_MASK);
        draw->AddLine(ImVec2(x0 + pad, help_top), ImVec2(x1 - pad, help_top), look.divider);
        if (!help.empty())
            draw->AddText(ImGui::GetFont(), ImGui::GetFontSize(), ImVec2(x0 + pad, help_top + spacing),
                          look.text_dim, help.c_str(), nullptr, help_wrap);
    }
    if (pinned_guides)
        draw_guides(window, guides, guide_top);
    if (!tabs)
        s.header_bottom = ImGui::GetStyle().WindowPadding.y + ImGui::GetFontSize() * 1.5f;
    int content_to = window->DrawList->VtxBuffer.Size;  // (before the frame's rules and the grip)
    draw_frame(window, look);
    draw_grip(window, look);
    ImGui::End();
    bool dropdown_now = s.dropdown.open && s.dropdown.anchored && !options.empty();
    if (dropdown_now)
        draw_dropdown(options, scale, base);
    else
        s.dropdown.hovered = false;
    ImGui::PopStyleVar(2);
    ImGui::PopStyleColor(3);
#ifndef __ANDROID__
    // Coming in: the menu down into place, fading in; a dialog or a page, its contents over the panel that stays.
    // Going out: the menu (closed this frame) and the dropdown (closed since its last frame) fade from here, as copies
    float f = base * scale, opened = anim_in(s.opened_at), viewed = anim_in(s.view_at);
    if (opened < 1) {
        tween_window(window, opened, ImVec2(0, -(1 - opened) * f * .9f));
    } else if (viewed < 1 && s.view == frame_view) {
        float a = .25f + .75f * viewed;
        ImVec2 off(0, (1 - viewed) * f * .45f);
        tween_list(window->DrawList, content_from, content_to, a, off, false);
        for (ImGuiWindow *c : window->DC.ChildWindows)
            if (c->Active)
                tween_window(c, a, off);
    }
    ImGuiWindow *list = ImGui::FindWindowByName("Settings##dropdown");
    ImVec2 back_in(0, (s.dropdown_up ? 1 : -1) * f * .4f);  // (the dropdown: towards its row)
    if (!*open) {
        ghost_take(window, true, ImVec2(0, -f * .6f));
        if (dropdown_now)
            ghost_take(list, true, back_in);
    } else if (s.dropdown_drawn && !dropdown_now)
        ghost_take(list, false, back_in);
    s.dropdown_drawn = dropdown_now && *open;
    if (!ImGui::IsMouseDown(ImGuiMouseButton_Left))
        s.swallow = false;  // (the press it was for has let go)
#endif
    report(open);
}
