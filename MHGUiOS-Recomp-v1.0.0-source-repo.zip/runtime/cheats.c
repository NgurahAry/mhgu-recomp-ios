// Cheat codes in Atmosphere's format (the one Ryujinx and a modded Switch use): every .txt file in cheats/ (beside
// mods/; MHGU_CHEATS_DIR overrides), in name order; a file whose name starts with '_' is skipped. A file holds any
// number of cheats: "[Name]" starts one, "{Name}" a master code (run before the others), then its code words, 8 hex
// digits each (written together without spaces too, as Atmosphere reads them: 16 digits are two words). Lines starting
// with '#' or "//" are comments. Every cheat found is on, except those listed in cheats/_off.txt (the settings' Cheats
// tab writes it: "<file>\t<cheat name>" per line; master codes are always on).
// A file named by a build id (16 hex digits or more, as Atmosphere and the emulators name them: <build id>.txt) is
// read only when that is the game's (1.4.0's main, FB08F1D20FD1204F): the others are for another version of the game,
// whose addresses are not this one's, and are left out (cheats_left_out: the Cheats tab says so).
// The enabled mods' cheats/ folders (yuzu's and Ryujinx's layout: <mod>/cheats/<build id>.txt) are read too, after
// those, under "<mod>/<file>"; their cheats start off (a mod's list can hold dozens), and _off.txt keeps the ones
// turned on as "+<mod>/<file>\t<cheat name>".
// As Atmosphere's virtual machine, an end of a block (20000000) without a block open is passed over, and an else
// (21000000) without one skips to the next end; such a cheat was left out before. EdiZon's and Breeze's folder marks
// (empty "[--SectionStart:...--]" / "[--SectionEnd:...--]") are no cheats.
// A cheat that only loads since 1.0 (a stray end or else, words written together: 0.1.9.3 left it out, so no _off.txt
// line names it) starts off as a mod's does, and is kept on as "+<file>\t<cheat name>": an update alone runs nothing
// new. A master code of those (or a mod's) is turned on and off like the others too, and runs first while on.
// A cheat turned off while the game runs stops running; the words of the game's code it changed get their original
// values back (so a code-changing cheat is undone), except those another cheat still on changed too, until that one
// is turned off as well. Anything else it wrote stays as it is.
// The codes run on Atmosphere's cheat virtual machine (every code type of its docs/features/cheats.md: written from
// that description), once before the game starts and then once per frame the game presents, from the window loop
// (as Atmosphere runs them beside the game). Memory regions: main is the main module (0x200000), heap, alias and aslr
// the regions GetInfo reports to the game; an address that is not mapped reads as 0 and is not written.
// A write into the game's code: the port runs code compiled ahead of time, which never sees it, so the function
// holding the changed word runs in the interpreter from then on (dispatch_interpret: that function alone, at the
// interpreter's speed); words written into the room after the code (padding up to the read-only data, where cheats
// put new code) are interpreted when the changed code jumps there. A call already running when the code changes
// finishes the old code.
#include <ctype.h>
#include <dirent.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>

#include "hle/input.h"
#include "cheats.h"
#include "modorder.h"
#include "interp.h"
#include "mods.h"
#include "rt.h"

#define NIB(w, i) (((w) >> (28 - 4 * (i))) & 15u)
#define MAX_OPS   1024
#define BUDGET    (1 << 20)  // instructions per cheat per run (a loop that never ends is cut off)

typedef struct {
    uint16_t type;  // 0x0-0xA: the top nybble; 0xC0-0xC4: the top byte; 0xFF0, 0xFF1, 0xFFF
    uint8_t n;      // words
    bool latched;   // (0xC4 without auto-repeat: its keys are still held since it ran)
    int jump;       // a block's begin or else: the op after its else / end; a loop's start: after its end, its end:
                    // after its start
    uint32_t w[5];
} Op;

typedef struct {
    uint32_t addr, word;  // a word of the game's code and its value before any cheat changed it
} Original;

typedef struct {
    char name[96], file[192];
    bool master, from_mod;  // from_mod: read from a mod's cheats/ (off unless turned on)
    bool opt_in;            // off unless "+<file>" in _off.txt: a mod's, or one 0.1.9.3 left out (master codes too)
    Op *ops;
    int nops;
    int on, ran;          // on: wanted (the settings set it, any thread); ran: running (the window loop's)
    int gone;             // its file was removed (cheats_drop_file, any thread): off for good
    bool stopping;        // (run_all: turned off this run)
    uint32_t *words;      // the code words it changed, to put back when it is turned off
    int nwords;
    int nstray;           // ends (and elses) with no block open, passed over as Atmosphere does (logged at load)
} Cheat;

static Cheat *cheats;
static int ncheats;
// Every code word a cheat changed, with its value from before any of them did: two cheats can change the same word,
// and the second one's "before" would be the first one's value.
static Original *orig;
static int norig;
static uint64_t reg[16], saved[16], statics[128];
static uint64_t keys;
static Cheat *cur;  // the one running (for the log, and the code words it changes)

const char *cheats_dir(void) {
    const char *e = getenv("MHGU_CHEATS_DIR");
    return e && *e ? e : "cheats";
}

void cheats_make_dir(void) {
    struct stat st;
    if (stat(cheats_dir(), &st)) mkdir(cheats_dir(), 0755);
}

// ------------------------------------------------------------------ decoding
static bool width_ok(uint32_t t) { return t == 1 || t == 2 || t == 4 || t == 8; }

static uint16_t op_type(uint32_t w) {
    uint32_t t = w >> 28;
    if (t < 0xC) return (uint16_t)t;
    if (t == 0xF && (w >> 24) == 0xFF) return (uint16_t)(w >> 20);
    return (uint16_t)(w >> 24);
}

// The op's word count from its first word (0: not a valid op).
static int op_words(uint32_t w) {
    switch (op_type(w)) {
    case 0x0: case 0x1: return width_ok(NIB(w, 1)) && NIB(w, 2) <= 4 ? (NIB(w, 1) == 8 ? 4 : 3) : 0;
    case 0x2: return NIB(w, 1) <= 1;
    case 0x3: return NIB(w, 1) == 0 ? 2 : NIB(w, 1) == 1;
    case 0x4: return 3;
    case 0x5: return width_ok(NIB(w, 1)) && NIB(w, 2) <= 4 && NIB(w, 4) <= 3 ? 2 : 0;
    case 0x6: return width_ok(NIB(w, 1)) ? 3 : 0;
    case 0x7: return width_ok(NIB(w, 1)) && NIB(w, 4) <= 4 ? 2 : 0;
    case 0x8: return 1;
    case 0x9:
        if (!width_ok(NIB(w, 1)) || NIB(w, 2) > 13 || (NIB(w, 2) >= 10 && NIB(w, 1) < 4)) return 0;
        return NIB(w, 5) == 1 ? (NIB(w, 1) == 8 ? 3 : 2) : NIB(w, 5) == 0;
    case 0xA:
        if (!width_ok(NIB(w, 1)) || NIB(w, 5) > 5) return 0;
        return NIB(w, 5) == 2 || NIB(w, 5) == 4 || NIB(w, 5) == 5 ? 2 : 1;
    case 0xC0:
        if (!width_ok(NIB(w, 2)) || NIB(w, 3) < 1 || NIB(w, 3) > 6 || NIB(w, 5) > 5) return 0;
        if (NIB(w, 5) == 0 || NIB(w, 5) == 2) return 2;
        return NIB(w, 5) == 4 ? (NIB(w, 2) == 8 ? 3 : 2) : 1;
    case 0xC1: return NIB(w, 6) <= 3;
    case 0xC2: return NIB(w, 2) <= 3;
    case 0xC3: return 1;
    case 0xC4: return 3;
    case 0xFF0: case 0xFF1: return 1;
    case 0xFFF:
        if (!width_ok(NIB(w, 3)) || NIB(w, 5) > 4) return 0;
        return NIB(w, 5) == 0 || NIB(w, 5) == 2 ? 2 : 1;
    }
    return 0;
}

static bool cond_ok(const Op *o) {  // (the condition nybble of 0x1)
    return o->type != 0x1 || (NIB(o->w[0], 3) >= 1 && NIB(o->w[0], 3) <= 6 && NIB(o->w[0], 4) <= 1);
}

// Words -> ops, with the blocks and loops matched. NULL (why in *err) if it does not decode.
static const char *decode(Cheat *ch, const uint32_t *w, int n) {
    ch->ops = calloc(MAX_OPS, sizeof(Op));
    int stack[64], depth = 0;
    for (int i = 0; i < n;) {
        int k = op_words(w[i]);
        if (!k) return "an unknown or invalid code";
        if (i + k > n) return "a code is cut short";
        if (ch->nops == MAX_OPS) return "too many codes";
        Op *o = &ch->ops[ch->nops];
        o->type = op_type(w[i]);
        o->n = (uint8_t)k;
        memcpy(o->w, w + i, k * 4);
        o->jump = -1;
        if (!cond_ok(o)) return "an invalid condition";
        bool begin = o->type == 0x1 || o->type == 0x8 || o->type == 0xC0 || o->type == 0xC4 ||
                     (o->type == 0x3 && NIB(o->w[0], 1) == 0);
        bool stray_else = o->type == 0x2 && NIB(o->w[0], 1) == 1 && !depth;
        if (begin || stray_else) {  // (an else with no block open, as Atmosphere runs it: on to the next end)
            if (depth == 64) return "blocks nested too deep";
            stack[depth++] = ch->nops;
            ch->nstray += stray_else;
        } else if (o->type == 0x2 && !depth) {  // an end with no block open: nothing (Atmosphere passes it over)
            ch->nstray++;
        } else if (o->type == 0x2 || o->type == 0x3) {  // else / end / end of loop
            bool loop_end = o->type == 0x3;
            if (!depth) return "an end of loop without its start";
            Op *b = &ch->ops[stack[depth - 1]];
            if ((b->type == 0x3) != loop_end) return "a block and a loop overlap";
            if (loop_end && NIB(b->w[0], 3) != NIB(o->w[0], 3)) return "a loop ends on another register";
            b->jump = ch->nops + 1;
            if (loop_end) o->jump = stack[depth - 1] + 1;
            if (o->type == 0x2 && NIB(o->w[0], 1) == 1) {  // else: the block goes on to its end
                if (b->type == 0x2) return "two elses in one block";
                stack[depth - 1] = ch->nops;
            } else {
                depth--;
            }
        }
        ch->nops++;
        i += k;
    }
    while (depth) ch->ops[stack[--depth]].jump = ch->nops;  // (open at the end: they end with the cheat)
    return NULL;
}

// ------------------------------------------------------------------ loading
// joined: words written together (0.1.9.3 left such a cheat out, as it did one with a stray end or else)
static void add_cheat(const char *file, const char *name, bool master, const uint32_t *w, int n, const char *bad,
                      bool joined) {
    // (EdiZon's and Breeze's lists mark folders with empty cheats, "[--SectionStart:Weapons--]" ... "[--SectionEnd:...--]":
    // no cheat of their own)
    if (!n && !bad && !master && (!strncmp(name, "--SectionStart", 14) || !strncmp(name, "--SectionEnd", 12))) return;
    Cheat ch = {0};
    snprintf(ch.name, sizeof ch.name, "%s", name);
    snprintf(ch.file, sizeof ch.file, "%s", file);
    ch.master = master;
    const char *err = bad ? bad : decode(&ch, w, n);
    if (err) {
        LOG("[cheats] %s: [%s]: %s, the cheat is left out\n", file, name, err);
        free(ch.ops);
        return;
    }
    if (ch.nstray)
        LOG("[cheats] %s: [%s]: %d end(s) of a block with no block open: passed over, as Atmosphere does\n", file, name,
            ch.nstray);
    ch.opt_in = ch.nstray > 0 || joined;
    cheats = realloc(cheats, (ncheats + 1) * sizeof(Cheat));
    cheats[ncheats++] = ch;
}

static void load_file(const char *path, const char *file, bool from_mod) {
    FILE *f = fopen(path, "rb");
    if (!f) return;
    fseek(f, 0, SEEK_END);
    long len = ftell(f);
    fseek(f, 0, SEEK_SET);
    char *s = malloc(len + 1);
    len = (long)fread(s, 1, len, f);
    s[len] = 0;
    fclose(f);
    static uint32_t words[MAX_OPS * 4];
    static char badword[96];
    int n = 0, before = ncheats;
    char name[96] = "";
    bool open = false, master = false, stray = false, joined = false;
    const char *bad = NULL;
    for (char *p = s; *p;) {
        if (isspace((unsigned char)*p)) { p++; continue; }
        if (*p == '#' || (p[0] == '/' && p[1] == '/')) { while (*p && *p != '\n') p++; continue; }
        if (*p == '[' || *p == '{') {
            char close = *p == '[' ? ']' : '}';
            char *e = strchr(p + 1, close);
            if (!e) { LOG("[cheats] %s: a name without its '%c'\n", file, close); break; }
            if (open) add_cheat(file, name, master, words, n, bad, joined);
            snprintf(name, sizeof name, "%.*s", (int)(e - p - 1), p + 1);
            master = *p == '{', open = true, n = 0, bad = NULL, joined = false;
            p = e + 1;
            continue;
        }
        char *e = p;
        while (*e && !isspace((unsigned char)*e)) e++;
        // (8 hex digits a word; Atmosphere reads digits written together 8 at a time, so 16 are two words)
        bool hex = e - p >= 8 && (e - p) % 8 == 0;
        for (char *q = p; hex && q < e; q++) hex = isxdigit((unsigned char)*q);
        if (!open) {
            stray = true;
        } else if (!hex) {
            if (!bad) {
                snprintf(badword, sizeof badword, "something that is not a code word (8 hex digits): \"%.*s\"",
                         (int)(e - p > 24 ? 24 : e - p), p);
                bad = badword;
            }
        } else {
            joined |= e - p > 8;
            for (char *q = p; q < e; q += 8) {
                if (n == (int)(sizeof words / 4)) { bad = "too many codes"; break; }
                char word[9];
                memcpy(word, q, 8), word[8] = 0;
                words[n++] = (uint32_t)strtoul(word, NULL, 16);
            }
        }
        p = e;
    }
    if (open) add_cheat(file, name, master, words, n, bad, joined);
    for (int i = before; i < ncheats; i++) cheats[i].from_mod = from_mod, cheats[i].opt_in |= from_mod;
    if (stray) LOG("[cheats] %s: codes before the first [name] are left out\n", file);
    LOG("[cheats] %s: %d cheat(s)", file, ncheats - before);
    for (int i = before; i < ncheats; i++) LOG("%s%s%s%s", i == before ? ": " : ", ", cheats[i].master ? "{" : "",
                                             cheats[i].name, cheats[i].master ? "}" : "");
    LOG("\n");
    free(s);
}

static int cmp_name(const void *a, const void *b) { return strcasecmp(*(char *const *)a, *(char *const *)b); }

// ------------------------------------------------------------------ memory
static uint64_t region(uint32_t m) {
    switch (m) {
    case 0: return MAIN_BASE;
    case 1: return HEAP_BASE;
    case 2: return ALIAS_BASE;
    case 3: return MAIN_BASE;  // (the address space: GetInfo's ASLR region)
    default: return 0;         // 4: not relative
    }
}

static uint64_t mask(uint32_t t, uint64_t v) { return t == 8 ? v : v & ((1ull << (8 * t)) - 1); }

static uint64_t rd(uint64_t a, uint32_t t) {
    uint64_t v = 0;
    if (kernel_mapped(a, t)) memcpy(&v, G2H((uint32_t)a), t);
    return v;
}

// A changed word of the game's code: the function holding it runs in the interpreter from now on.
static void code_changed(uint32_t a) {
    const Module *m = &g_modules[a >= SDK_BASE];
    if (a >= m->base + m->text_off + m->text_size) {  // after the code (padding up to the read-only data): new code
        interp_add_range(a, a + 4);
        return;
    }
    uint32_t next, entry = dispatch_function_at(a, &next);
    if (!entry) return;
    uint32_t end = next ? next : m->base + m->text_off + m->text_size;
    int r = dispatch_interpret(entry, end);
    if (r > 0) LOG("[cheats] %s: changes the code at %s+%#x: the function at %s+%#x runs in the interpreter now\n",
                   cur->name, m->name, a - m->base, m->name, entry - m->base);
    else if (r < 0) LOG("[cheats] %s: changes the code at %s+%#x, which cannot take effect\n", cur->name, m->name,
                        a - m->base);
}

static void wr(uint64_t a, uint32_t t, uint64_t v) {
    if (!kernel_mapped(a, t)) return;
    uint8_t *p = G2H((uint32_t)a);
    bool code = false;
    for (int i = 0; i < 2 && i < g_nmodules; i++) {
        const Module *m = &g_modules[i];
        if (a < m->base + m->ro_off && a + t > m->base + m->text_off) code = true;
    }
    if (code && cur)  // (each word this cheat writes, and its original the first time any cheat does; also when
                      // another cheat already wrote the same value: this one keeps it changed too)
        for (uint32_t w = (uint32_t)a & ~3u; w < a + t; w += 4) {
            if (!kernel_mapped(w, 4)) continue;
            bool seen = false;
            for (int i = 0; i < cur->nwords && !seen; i++) seen = cur->words[i] == w;
            if (seen) continue;
            cur->words = realloc(cur->words, (cur->nwords + 1) * sizeof *cur->words);
            cur->words[cur->nwords++] = w;
            for (int i = 0; i < norig && !seen; i++) seen = orig[i].addr == w;
            if (seen) continue;
            orig = realloc(orig, (norig + 1) * sizeof *orig);
            orig[norig].addr = w;
            memcpy(&orig[norig++].word, G2H(w), 4);
        }
    if (code && !memcmp(p, &v, t)) return;
    memcpy(p, &v, t);
    if (code)
        for (uint32_t w = (uint32_t)a & ~3u; w < a + t; w += 4) code_changed(w);
}

// ------------------------------------------------------------------ running
static bool compare(uint32_t c, uint64_t a, uint64_t b) {
    switch (c) {
    case 1: return a > b;
    case 2: return a >= b;
    case 3: return a < b;
    case 4: return a <= b;
    case 5: return a == b;
    default: return a != b;
    }
}

static uint64_t arith(uint32_t op, uint32_t t, uint64_t a, uint64_t b) {
    if (op >= 10) {  // floats: T 4 single, 8 double
        if (t == 4) {
            float x, y, r;
            uint32_t xa = (uint32_t)a, xb = (uint32_t)b, out;
            memcpy(&x, &xa, 4), memcpy(&y, &xb, 4);
            r = op == 10 ? x + y : op == 11 ? x - y : op == 12 ? x * y : x / y;
            memcpy(&out, &r, 4);
            return out;
        }
        double x, y, r;
        memcpy(&x, &a, 8), memcpy(&y, &b, 8);
        r = op == 10 ? x + y : op == 11 ? x - y : op == 12 ? x * y : x / y;
        uint64_t out;
        memcpy(&out, &r, 8);
        return out;
    }
    uint64_t r;
    switch (op) {
    case 0: r = a + b; break;
    case 1: r = a - b; break;
    case 2: r = a * b; break;
    case 3: r = b < 64 ? a << b : 0; break;
    case 4: r = b < 64 ? a >> b : 0; break;
    case 5: r = a & b; break;
    case 6: r = a | b; break;
    case 7: r = ~a; break;
    case 8: r = a ^ b; break;
    default: r = a; break;  // 9: move
    }
    return mask(t, r);
}

static uint64_t imm(const Op *o, int i, uint32_t t) {  // a value word (two for width 8: high, low)
    return t == 8 ? (uint64_t)o->w[i] << 32 | o->w[i + 1] : o->w[i];
}

static uint64_t addr40(const Op *o) { return (uint64_t)(o->w[0] & 0xFF) << 32 | o->w[1]; }
static uint64_t addr36(const Op *o) { return (uint64_t)(o->w[0] & 0xF) << 32 | o->w[1]; }

// Each cheat starts with its registers and saved registers at 0 (as Ryujinx runs them, each on its own): a cheat
// that leaves a register set must not move the next one's writes, which add a register to their address (0TMR...:
// R, mostly 0). Static registers are shared: they are how cheats pass values on.
static void run(Cheat *ch) {
    cur = ch;
    memset(reg, 0, sizeof reg);
    memset(saved, 0, sizeof saved);
    int budget = BUDGET;
    for (int i = 0; i < ch->nops && budget--;) {
        Op *o = &ch->ops[i];
        uint32_t w = o->w[0];
        int next = i + 1;
        switch (o->type) {
        case 0x0: {  // store a value: 0TMR00AA AAAAAAAA V
            uint32_t t = NIB(w, 1);
            wr(region(NIB(w, 2)) + addr40(o) + reg[NIB(w, 3)], t, mask(t, imm(o, 2, t)));
            break;
        }
        case 0x1: {  // memory condition: 1TMCXrAA AAAAAAAA V
            uint32_t t = NIB(w, 1);
            uint64_t a = region(NIB(w, 2)) + addr40(o) + (NIB(w, 4) ? reg[NIB(w, 5)] : 0);
            if (!compare(NIB(w, 3), rd(a, t), mask(t, imm(o, 2, t)))) next = o->jump;
            break;
        }
        case 0x2:  // end, or else reached at the end of the taken part: on past the block
            if (NIB(w, 1) == 1) next = o->jump;
            break;
        case 0x3:
            if (NIB(w, 1) == 0) {  // loop start: 300R0000 V
                reg[NIB(w, 3)] = o->w[1];
                if (!o->w[1]) next = o->jump;
            } else if (reg[NIB(w, 3)] && --reg[NIB(w, 3)]) {  // loop end: 310R0000
                next = o->jump;
            }
            break;
        case 0x4:  // load a value: 400R0000 V V
            reg[NIB(w, 3)] = (uint64_t)o->w[1] << 32 | o->w[2];
            break;
        case 0x5: {  // load from memory: 5TMRIS AA AAAAAAAA
            uint32_t t = NIB(w, 1), r = NIB(w, 3), s = NIB(w, 5);
            uint64_t a = addr40(o);
            switch (NIB(w, 4)) {
            case 0: a += region(NIB(w, 2)); break;
            case 1: a += reg[r]; break;
            case 2: a += reg[s]; break;
            default: a += region(NIB(w, 2)) + reg[s]; break;
            }
            reg[r] = rd(a, t);
            break;
        }
        case 0x6: {  // store a value at a register's address: 6T0RIor0 V V
            uint32_t t = NIB(w, 1), r = NIB(w, 3);
            wr(reg[r] + (NIB(w, 5) ? reg[NIB(w, 6)] : 0), t, mask(t, (uint64_t)o->w[1] << 32 | o->w[2]));
            if (NIB(w, 4)) reg[r] += t;
            break;
        }
        case 0x7: {  // legacy arithmetic: 7T0RC000 V
            uint32_t t = NIB(w, 1), r = NIB(w, 3);
            reg[r] = arith(NIB(w, 4), t, reg[r], o->w[1]);
            break;
        }
        case 0x8: {  // keys held: 8kkkkkkk
            uint64_t k = w & 0x0FFFFFFFu;
            if ((keys & k) != k) next = o->jump;
            break;
        }
        case 0x9: {  // arithmetic: 9TCRS0s0 / 9TCRS100 V
            uint32_t t = NIB(w, 1);
            uint64_t b = NIB(w, 5) ? imm(o, 1, t) : reg[NIB(w, 6)];
            reg[NIB(w, 3)] = arith(NIB(w, 2), t, mask(t, reg[NIB(w, 4)]), mask(t, b));
            break;
        }
        case 0xA: {  // store a register: ATSRIOxa (aaaaaaaa)
            uint32_t t = NIB(w, 1), r = NIB(w, 3), x = NIB(w, 6);
            uint64_t a;
            switch (NIB(w, 5)) {
            case 0: a = reg[r]; break;
            case 1: a = reg[r] + reg[x]; break;
            case 2: a = reg[r] + addr36(o); break;
            case 3: a = region(x) + reg[r]; break;
            case 4: a = region(x) + addr36(o); break;
            default: a = region(x) + addr36(o) + reg[r]; break;
            }
            wr(a, t, mask(t, reg[NIB(w, 2)]));
            if (NIB(w, 4)) reg[r] += t;
            break;
        }
        case 0xC0: {  // register condition: C0TcSX..
            uint32_t t = NIB(w, 2), x6 = NIB(w, 6), x7 = NIB(w, 7);
            uint64_t b;
            switch (NIB(w, 5)) {
            case 0: b = rd(region(x6) + addr36(o), t); break;
            case 1: b = rd(region(x6) + reg[x7], t); break;
            case 2: b = rd(reg[x6] + addr36(o), t); break;
            case 3: b = rd(reg[x6] + reg[x7], t); break;
            case 4: b = imm(o, 1, t); break;
            default: b = reg[x6]; break;
            }
            if (!compare(NIB(w, 3), mask(t, reg[NIB(w, 4)]), mask(t, b))) next = o->jump;
            break;
        }
        case 0xC1: {  // save / restore a register: C10D0Sx0
            uint32_t d = NIB(w, 3), s = NIB(w, 5);
            switch (NIB(w, 6)) {
            case 0: reg[d] = saved[s]; break;
            case 1: saved[d] = reg[s]; break;
            case 2: saved[d] = 0; break;
            default: reg[d] = 0; break;
            }
            break;
        }
        case 0xC2:  // the same by a mask: C2x0XXXX
            for (int k = 0; k < 16; k++) {
                if (!(w >> k & 1)) continue;
                switch (NIB(w, 2)) {
                case 0: reg[k] = saved[k]; break;
                case 1: saved[k] = reg[k]; break;
                case 2: saved[k] = 0; break;
                default: reg[k] = 0; break;
                }
            }
            break;
        case 0xC3: {  // static register: C3000XXx (XX 0x00-0x7F read, 0x80-0xFF write)
            uint32_t s = (w >> 4) & 0xFF;
            if (s < 0x80) reg[w & 15] = statics[s];
            else statics[s & 0x7F] = reg[w & 15];
            break;
        }
        case 0xC4: {  // keys held, extended: C4r00000 K K (r 0: once per press)
            uint64_t k = (uint64_t)o->w[1] << 32 | o->w[2];
            bool held = (keys & k) == k, fire = held && (NIB(w, 2) || !o->latched);
            o->latched = held;
            if (!fire) next = o->jump;
            break;
        }
        case 0xFF0: case 0xFF1: {  // pause / resume the game: not done here
            static bool said;
            if (!said) said = true, LOG("[cheats] %s: pausing / resuming the game is not supported\n", ch->name);
            break;
        }
        case 0xFFF: {  // debug log: FFFTIX..
            uint32_t t = NIB(w, 3), x6 = NIB(w, 6), x7 = NIB(w, 7);
            uint64_t v;
            switch (NIB(w, 5)) {
            case 0: v = rd(region(x6) + addr36(o), t); break;
            case 1: v = rd(region(x6) + reg[x7], t); break;
            case 2: v = rd(reg[x6] + addr36(o), t); break;
            case 3: v = rd(reg[x6] + reg[x7], t); break;
            default: v = mask(t, reg[x6]); break;
            }
            LOG("[cheats] %s: log %x: %#llx\n", ch->name, NIB(w, 4), (unsigned long long)v);
            break;
        }
        }
        i = next;
    }
    if (budget < 0) LOG("[cheats] %s: ran too long (a loop that never ends?): stopped for this frame\n", ch->name);
}

// A cheat turned off: the code words it changed get their values from before any cheat changed them back, except
// those a cheat still running changed too (it keeps them as it wants them; the last of them turned off puts them back).
static void undo(Cheat *ch) {
    cur = NULL;  // (putting a word back is not a change to remember)
    int back = 0, kept = 0;
    for (int i = 0; i < ch->nwords; i++) {
        uint32_t w = ch->words[i];
        bool shared = false;
        for (int k = 0; k < ncheats && !shared; k++)
            if (cheats[k].ran)
                for (int j = 0; j < cheats[k].nwords && !shared; j++) shared = cheats[k].words[j] == w;
        if (shared) { kept++; continue; }
        int o = 0;
        while (o < norig && orig[o].addr != w) o++;
        if (o == norig) continue;
        uint8_t *p = G2H(w);
        if (memcmp(p, &orig[o].word, 4)) {
            memcpy(p, &orig[o].word, 4);
            code_changed(w);  // (stays in the interpreter: now with the original code)
            back++;
        }
        orig[o] = orig[--norig];  // (the game's own again)
    }
    if (kept && back)
        LOG("[cheats] %s: off, %d word(s) of code put back, %d kept by cheats still on\n", ch->name, back, kept);
    else if (kept) LOG("[cheats] %s: off, %d word(s) of code kept by cheats still on\n", ch->name, kept);
    else if (back) LOG("[cheats] %s: off, %d word(s) of code put back\n", ch->name, back);
    else LOG("[cheats] %s: off\n", ch->name);
    free(ch->words);
    ch->words = NULL, ch->nwords = 0;
}

// A master code runs whatever the settings say, except one that starts off (opt_in): that one has its switch
static bool always_on(const Cheat *ch) { return ch->master && !ch->opt_in; }

static void run_all(void) {
    for (int i = 0; i < ncheats; i++) {  // (every cheat's new state first: undo asks which ones keep running)
        Cheat *ch = &cheats[i];
        bool on = !__atomic_load_n(&ch->gone, __ATOMIC_ACQUIRE) &&
                  (always_on(ch) || __atomic_load_n(&ch->on, __ATOMIC_ACQUIRE));
        ch->stopping = !on && ch->ran;
        if (on && !ch->ran && g_present_count) LOG("[cheats] %s: on\n", ch->name);
        ch->ran = on;
    }
    for (int i = 0; i < ncheats; i++)
        if (cheats[i].stopping) undo(&cheats[i]);
    for (int pass = 0; pass < 2; pass++)  // master codes first
        for (int i = 0; i < ncheats; i++)
            if (cheats[i].master == !pass && cheats[i].ran) run(&cheats[i]);
}

// ------------------------------------------------------------------ on / off (the settings' Cheats tab)
#define OFF_FILE "_off.txt"  // (a '_' name: not read as cheats)
static void off_path(char *out, size_t n) { snprintf(out, n, "%s/" OFF_FILE, cheats_dir()); }

static void load_off(void) {
    char path[1024], line[256];
    off_path(path, sizeof path);
    FILE *f = fopen(path, "rb");
    if (!f) return;
    while (fgets(line, sizeof line, f)) {
        line[strcspn(line, "\r\n")] = 0;
        char *tab = strchr(line, '\t');
        if (line[0] == '#' || !tab) continue;
        *tab = 0;
        bool on = line[0] == '+';  // ("+<mod>/<file>": a mod's cheat turned on)
        // (0.1.9.3 kept only 63 bytes of a file's name and wrote them so: such a line still names that file's cheat)
        bool cut = !on && strlen(line) == 63;
        for (int i = 0; i < ncheats; i++)
            if ((!strcmp(cheats[i].file, line + on) || (cut && !strncmp(cheats[i].file, line, 63))) &&
                !strcmp(cheats[i].name, tab + 1))
                cheats[i].on = on;
    }
    fclose(f);
}

int cheats_count(void) { return ncheats; }
const char *cheats_name(int i) { return i >= 0 && i < ncheats ? cheats[i].name : ""; }
const char *cheats_file(int i) { return i >= 0 && i < ncheats ? cheats[i].file : ""; }
bool cheats_master(int i) { return i >= 0 && i < ncheats && always_on(&cheats[i]); }
bool cheats_on(int i) {
    return i >= 0 && i < ncheats && !cheats_dropped(i) &&
           (always_on(&cheats[i]) || __atomic_load_n(&cheats[i].on, __ATOMIC_ACQUIRE));
}
bool cheats_dropped(int i) { return i >= 0 && i < ncheats && __atomic_load_n(&cheats[i].gone, __ATOMIC_ACQUIRE); }

void cheats_drop_file(const char *file) {
    for (int i = 0; i < ncheats; i++)
        if (!strcmp(cheats[i].file, file)) {
            __atomic_store_n(&cheats[i].on, 0, __ATOMIC_RELEASE);
            __atomic_store_n(&cheats[i].gone, 1, __ATOMIC_RELEASE);
        }
    LOG("[cheats] %s: removed in the settings, its cheats stop\n", file);
}

#ifndef __ANDROID__
// A cheat file the game didn't load that is in a cheats folder now: one added since the start (a desktop's restart can
// be put off), whose lines here - its cheats, off for the next start - stay
static bool added_since(const char *file) {
    for (int i = 0; i < ncheats; i++)
        if (!strcmp(cheats[i].file, file)) return false;
    char path[1100];
    struct stat st;
    snprintf(path, sizeof path, "%s/%s", cheats_dir(), file);
    if (!stat(path, &st) && S_ISREG(st.st_mode)) return true;
    if (getenv("MHGU_CHEATS_DIR") || !g_game_dir) return false;
    snprintf(path, sizeof path, "%s/cheats/%s", g_game_dir, file);
    return !stat(path, &st) && S_ISREG(st.st_mode);
}
#endif

bool cheats_set(const bool *on, int n, char *err, size_t errsz) {
    char path[1024], tmp[1040];
    off_path(path, sizeof path);
    snprintf(tmp, sizeof tmp, "%s.tmp", path);
    cheats_make_dir();
    FILE *f = fopen(tmp, "wb");
    if (!f) { snprintf(err, errsz, "Could not write %s", path); return false; }
    fputs("# Cheats turned off in the settings (the Cheats tab writes this file): <file><tab><cheat name>\n", f);
    for (int i = 0; i < ncheats && i < n; i++) {
        if (always_on(&cheats[i]) || cheats_dropped(i)) continue;
        if (!on[i] && !cheats[i].opt_in) fprintf(f, "%s\t%s\n", cheats[i].file, cheats[i].name);
        else if (on[i] && cheats[i].opt_in) fprintf(f, "+%s\t%s\n", cheats[i].file, cheats[i].name);  // (off unless listed)
    }
#ifndef __ANDROID__
    char line[512];
    FILE *old = fopen(path, "rb");
    while (old && fgets(line, sizeof line, old)) {
        line[strcspn(line, "\r\n")] = 0;
        char *tab = strchr(line, '\t');
        if (line[0] == '#' || !tab) continue;
        *tab = 0;
        if (added_since(line)) fprintf(f, "%s\t%s\n", line, tab + 1);
    }
    if (old) fclose(old);
#endif
    bool ok = !ferror(f);
    ok = !fclose(f) && ok;
#ifdef _WIN32
    if (ok) remove(path);  // (Windows' rename won't replace a file; this one is small and rewritten whole)
#endif
    if (!ok || rename(tmp, path)) { remove(tmp); snprintf(err, errsz, "Could not write %s", path); return false; }
    for (int i = 0; i < ncheats && i < n; i++)
        __atomic_store_n(&cheats[i].on, on[i] && !cheats_dropped(i) ? 1 : 0, __ATOMIC_RELEASE);
    return true;
}

// ------------------------------------------------------------------ entry points
// Files left out whole (cheats_left_out): those for another version of the game
#define MAX_LEFT 64
static struct { char file[192], id[17]; } left[MAX_LEFT];
static int nleft;

static int hexv(int c) { return isdigit(c) ? c - '0' : isxdigit(c) ? tolower(c) - 'a' + 10 : -1; }

// A file named by a build id ("<16 or more hex digits>.txt", as Atmosphere names them) that is not the game's: true,
// and the first 16 digits of its id in id. A file of another name (comer_rapido.txt) is no build id's: false.
static bool other_version(const char *name, char id[17]) {
    int n = 0;
    while (hexv((unsigned char)name[n]) >= 0) n++;
    if (n < 16 || n > 64 || strcasecmp(name + n, ".txt")) return false;
    if (n == 16 && !strncasecmp(name, "0100770008DD8000", 16)) return false;  // (the game's title id, no build id: loaded as in 0.1.9.3)
    bool same = true;
    for (int i = 0; i < 16; i++) same &= hexv((unsigned char)name[i]) == ((g_main_build_id[i / 2] >> (i & 1 ? 0 : 4)) & 15);
    if (same) return false;
    for (int i = 0; i < 16; i++) id[i] = (char)toupper((unsigned char)name[i]);
    id[16] = 0;
    return true;
}

int cheats_left_out(int i, const char **file, const char **id) {
    if (i >= 0 && i < nleft) {
        if (file) *file = left[i].file;
        if (id) *id = left[i].id;
    }
    return nleft;
}

// The files of one folder, in name order (those of a name already loaded from the other folder are left out). prefix:
// "<mod>/" for a mod's cheats/ (the files' names in the list and in _off.txt), else "".
static void load_dir(const char *dir, const char *prefix) {
    DIR *d = opendir(dir);
    if (!d) return;
    char *names[256];
    int n = 0;
    struct dirent *e;
    while ((e = readdir(d)) && n < 256) {
        size_t l = strlen(e->d_name);
        if (e->d_name[0] != '_' && e->d_name[0] != '.' && l > 4 && !strcasecmp(e->d_name + l - 4, ".txt"))
            names[n++] = strdup(e->d_name);
    }
    closedir(d);
    qsort(names, n, sizeof *names, cmp_name);
    for (int i = 0; i < n; i++) {
        char file[192], path[1300], id[17];
        snprintf(file, sizeof file, "%s%s", prefix, names[i]);
        bool seen = false;
        for (int k = 0; k < ncheats && !seen; k++) seen = !strcmp(cheats[k].file, file);
        for (int k = 0; k < nleft && !seen; k++) seen = !strcmp(left[k].file, file);
        snprintf(path, sizeof path, "%s/%s", dir, names[i]);
        if (seen) {
            LOG("[cheats] %s: one of that name was read already, from the other cheats folder: left out\n", path);
        } else if (other_version(names[i], id)) {
            LOG("[cheats] %s: for the game of build id %s, not this one's 1.4.0 (FB08F1D20FD1204F): another version, "
                "whose addresses are not these; left out\n", file, id);
            if (nleft < MAX_LEFT) {
                snprintf(left[nleft].file, sizeof left[nleft].file, "%s", file);
                snprintf(left[nleft].id, sizeof left[nleft].id, "%s", id);
                nleft++;
            }
        } else {
            load_file(path, file, *prefix != 0);
        }
        free(names[i]);
    }
}

// The cheats/ folder of each mod that is on (found up to three levels down, as its romfs: yuzu's
// load/<title>/<mod>/cheats, Ryujinx's mods/contents/<title>/<mod>/cheats)
static void load_mod_dirs(void) {
    ModEntry all[MODS_MAX];
    int n = mods_installed(all, MODS_MAX);
    for (int i = 0; i < n; i++) {
        if (!all[i].on) continue;
        char mod[1100], dir[1100], prefix[160];
        snprintf(mod, sizeof mod, "%s/%s", mods_dir(), all[i].name);
        if (!mods_find_dir(mod, "cheats", 3, dir, sizeof dir)) continue;
        snprintf(prefix, sizeof prefix, "%.150s/", all[i].name);
        load_dir(dir, prefix);
    }
}

void cheats_init(void) {
    // the app's folder (the bundled ones, and the settings' list of those off), then the game folder's cheats/: where a
    // player can put them on a phone, whose app folder (Android/data) a file manager can't open
    load_dir(cheats_dir(), "");
    extern const char *g_game_dir;  // (main.c)
    if (!getenv("MHGU_CHEATS_DIR") && g_game_dir) {
        char other[1024];
        snprintf(other, sizeof other, "%s/cheats", g_game_dir);
        load_dir(other, "");
    }
    load_mod_dirs();
    for (int i = 0; i < ncheats; i++) cheats[i].on = !cheats[i].opt_in;
    load_off();
    for (int i = 0; i < ncheats; i++)
        if (!always_on(&cheats[i]) && !cheats[i].on)
            LOG(cheats[i].opt_in ? "[cheats] %s: off until turned on in the settings (a mod's, or one 0.1.9.3 left out)\n"
                                 : "[cheats] %s: off (turned off in the settings)\n",
                cheats[i].name);
    if (ncheats) run_all();  // (before the game starts: changes to its code are in place from the start)
}

void cheats_frame(void) {
    static uint64_t last;
    if (!ncheats || g_present_count == last) return;
    last = g_present_count;
    uint64_t b;
    int32_t s[4];
    input_get(&b, s);
    enum { T = 16384 };  // (stick directions: half way)
    b &= 0xFFFF;
    if (s[0] < -T) b |= 1u << 16;
    if (s[1] > T) b |= 1u << 17;
    if (s[0] > T) b |= 1u << 18;
    if (s[1] < -T) b |= 1u << 19;
    if (s[2] < -T) b |= 1u << 20;
    if (s[3] > T) b |= 1u << 21;
    if (s[2] > T) b |= 1u << 22;
    if (s[3] < -T) b |= 1u << 23;
    keys = b;
    run_all();
}
